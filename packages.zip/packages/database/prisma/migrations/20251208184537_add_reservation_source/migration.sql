-- AlterTable
ALTER TABLE "HotelReservation" ADD COLUMN     "source" TEXT DEFAULT 'Direct';
