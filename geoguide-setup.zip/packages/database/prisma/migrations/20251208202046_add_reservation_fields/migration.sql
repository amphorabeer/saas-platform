-- AlterTable
ALTER TABLE "HotelReservation" ADD COLUMN     "companyAddress" TEXT,
ADD COLUMN     "companyBank" TEXT,
ADD COLUMN     "companyBankAccount" TEXT,
ADD COLUMN     "companyName" TEXT,
ADD COLUMN     "companyTaxId" TEXT,
ADD COLUMN     "guestCountry" TEXT;
