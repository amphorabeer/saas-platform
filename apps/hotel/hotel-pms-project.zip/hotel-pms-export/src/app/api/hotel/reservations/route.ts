import { NextRequest, NextResponse } from 'next/server'
import { getReservations, addReservation, updateReservation, saveReservations } from '../../../../lib/dataStore'

export async function GET() {
  try {
    const reservations = await getReservations()
    return NextResponse.json(reservations)
  } catch (error: any) {
    console.error('Error loading reservations:', error)
    return NextResponse.json({ error: 'Failed to load reservations', details: error.message }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const newReservation = await addReservation(data)
    return NextResponse.json(newReservation)
  } catch (error: any) {
    console.error('Error creating reservation:', error)
    return NextResponse.json({ error: 'Failed to create reservation', details: error.message }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, ...updates } = await request.json()
    
    if (!id) {
      return NextResponse.json({ error: 'Reservation ID required' }, { status: 400 })
    }
    
    const updatedReservation = await updateReservation(id, updates)
    return NextResponse.json(updatedReservation)
  } catch (error: any) {
    console.error('Error updating reservation:', error)
    return NextResponse.json({ error: 'Failed to update reservation', details: error.message }, { status: 500 })
  }
}

export async function DELETE() {
  try {
    await saveReservations([])
    return NextResponse.json({ message: 'All reservations deleted', count: 0 })
  } catch (error: any) {
    console.error('Error deleting reservations:', error)
    return NextResponse.json({ error: 'Failed to delete reservations', details: error.message }, { status: 500 })
  }
}

