'use client'

import { useState, useEffect } from 'react'
import moment from 'moment'
import { ActivityLogger } from '../lib/activityLogger'

interface Room {
  id: string
  roomNumber: string
  floor: number
  status: string
  basePrice: number
  roomType?: string
}

interface CheckInModalProps {
  room?: Room
  rooms?: Room[]
  initialCheckIn?: string
  onClose: () => void
  onSubmit: (data: any) => void
}

export default function CheckInModal({ room, rooms = [], initialCheckIn, onClose, onSubmit }: CheckInModalProps) {
  const [formData, setFormData] = useState({
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    roomId: room?.id || '',
    roomNumber: room?.roomNumber || '',
    checkIn: initialCheckIn || new Date().toISOString().split('T')[0],
    checkOut: '',
    adults: 1,
    children: 0,
    totalAmount: room?.basePrice || 150,
    notes: ''
  })

  // Update formData when room or initialCheckIn changes
  useEffect(() => {
    if (room) {
      setFormData(prev => ({
        ...prev,
        roomId: room.id,
        roomNumber: room.roomNumber,
        totalAmount: room.basePrice || prev.totalAmount
      }))
    }
    if (initialCheckIn) {
      setFormData(prev => ({
        ...prev,
        checkIn: initialCheckIn
      }))
    }
  }, [room, initialCheckIn])

  const selectedRoom = room || rooms.find(r => r.id === formData.roomId)

  const calculateNights = () => {
    if (formData.checkIn && formData.checkOut) {
      const start = new Date(formData.checkIn)
      const end = new Date(formData.checkOut)
      const nights = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))
      return nights > 0 ? nights : 1
    }
    return 1
  }

  const calculateTotal = () => {
    const nights = calculateNights()
    const basePrice = selectedRoom?.basePrice || 150
    return nights * basePrice
  }

  useEffect(() => {
    if (formData.checkIn && formData.checkOut && selectedRoom) {
      setFormData(prev => ({ ...prev, totalAmount: calculateTotal() }))
    }
  }, [formData.checkIn, formData.checkOut, formData.roomId, selectedRoom])

  // Generate unique reservation number
  const generateReservationNumber = () => {
    return Math.floor(10000 + Math.random() * 90000).toString() // 10000-99999
  }
  
  // Get minimum booking date based on last closed audit
  const getMinimumBookingDate = () => {
    // Get last closed audit date
    const lastAuditDate = localStorage.getItem('lastAuditDate')
    
    if (lastAuditDate) {
      // Can't book before last closed day
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        return moment(lastClosed).add(1, 'day').format('YYYY-MM-DD')
      } catch {
        // If parsing fails, use today
        return moment().format('YYYY-MM-DD')
      }
    }
    
    // If no audit yet, use today
    return moment().format('YYYY-MM-DD')
  }
  
  const handleSubmit = () => {
    if (!formData.guestName || !formData.checkOut) return
    
    const reservation = {
      ...formData,
      totalAmount: calculateTotal(),
      status: 'CONFIRMED',
      nights: calculateNights(),
      reservationNumber: generateReservationNumber()
    }
    
    ActivityLogger.log('RESERVATION_CREATE', {
      guest: formData.guestName,
      room: formData.roomNumber,
      checkIn: formData.checkIn,
      checkOut: formData.checkOut,
      amount: formData.totalAmount,
      reservationNumber: reservation.reservationNumber
    })
    
    onSubmit(reservation)
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-start mb-4">
          <h2 className="text-xl font-bold">
            ახალი ჯავშანი - ოთახი {room?.roomNumber || formData.roomNumber || 'აირჩიეთ'}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-2xl leading-none">✕</button>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">სტუმრის სახელი *</label>
            <input
              type="text"
              className="w-full border rounded px-3 py-2"
              value={formData.guestName}
              onChange={(e) => setFormData({...formData, guestName: e.target.value})}
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">ელ-ფოსტა</label>
            <input
              type="email"
              className="w-full border rounded px-3 py-2"
              value={formData.guestEmail}
              onChange={(e) => setFormData({...formData, guestEmail: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">ტელეფონი</label>
            <input
              type="tel"
              className="w-full border rounded px-3 py-2"
              value={formData.guestPhone}
              onChange={(e) => setFormData({...formData, guestPhone: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">ოთახი</label>
            {room ? (
              <input
                type="text"
                className="w-full border rounded px-3 py-2 bg-gray-100"
                value={room.roomNumber}
                disabled
              />
            ) : (
              <select
                className="w-full border rounded px-3 py-2"
                value={formData.roomId}
                onChange={(e) => {
                  const selected = rooms.find(r => r.id === e.target.value)
                  setFormData({
                    ...formData,
                    roomId: e.target.value,
                    roomNumber: selected?.roomNumber || ''
                  })
                }}
                required
              >
                <option value="">აირჩიეთ ნომერი</option>
                {rooms.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.roomNumber} - ₾{r.basePrice}
                  </option>
                ))}
              </select>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Check In *</label>
            <input
              type="date"
              min={getMinimumBookingDate()}
              className="w-full border rounded px-3 py-2"
              value={formData.checkIn}
              onChange={(e) => setFormData({...formData, checkIn: e.target.value})}
              required
            />
            <span className="text-xs text-gray-500 mt-1 block">
              მინიმუმ: {moment(getMinimumBookingDate()).format('DD/MM/YYYY')}
            </span>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Check Out *</label>
            <input
              type="date"
              min={formData.checkIn || getMinimumBookingDate()}
              className="w-full border rounded px-3 py-2"
              value={formData.checkOut}
              onChange={(e) => setFormData({...formData, checkOut: e.target.value})}
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">ზრდასრულები</label>
            <input
              type="number"
              className="w-full border rounded px-3 py-2"
              value={formData.adults}
              onChange={(e) => setFormData({...formData, adults: parseInt(e.target.value) || 1})}
              min="1"
              max="4"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">ბავშვები</label>
            <input
              type="number"
              className="w-full border rounded px-3 py-2"
              value={formData.children}
              onChange={(e) => setFormData({...formData, children: parseInt(e.target.value) || 0})}
              min="0"
              max="3"
            />
          </div>
          
          <div className="col-span-2">
            <label className="block text-sm font-medium mb-1">შენიშვნები</label>
            <textarea
              className="w-full border rounded px-3 py-2"
              rows={3}
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="დამატებითი ინფორმაცია..."
            />
          </div>
        </div>
        
        {/* Price Summary */}
        <div className="mt-4 p-4 bg-gray-50 rounded">
          <div className="flex justify-between text-sm">
            <span>ღამეების რაოდენობა:</span>
            <span>{calculateNights()}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>ფასი ღამეზე:</span>
            <span>₾{selectedRoom?.basePrice || 150}</span>
          </div>
          <div className="flex justify-between font-bold mt-2 pt-2 border-t">
            <span>სულ თანხა:</span>
            <span>₾{calculateTotal()}</span>
          </div>
        </div>
        
        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 border rounded hover:bg-gray-50"
          >
            გაუქმება
          </button>
          <button
            onClick={handleSubmit}
            disabled={!formData.guestName || !formData.checkOut || (!room && !formData.roomId)}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            დაჯავშნა
          </button>
        </div>
      </div>
    </div>
  )
}


