'use client'

import React, { useState, useEffect } from 'react'
import moment from 'moment'
import { PostingService } from '../services/PostingService'
import { PackagePostingService } from '../services/PackagePostingService'
import { FolioAutoCloseService } from '../services/FolioAutoCloseService'
import { FinancialReportsService } from '../services/FinancialReportsService'
import NightAuditPostingSummary from './NightAuditPostingSummary'

export default function NightAuditModule() {
  const [currentStep, setCurrentStep] = useState(0)
  const [isAuditRunning, setIsAuditRunning] = useState(false)
  const [showPreChecks, setShowPreChecks] = useState(true)
  const [auditLog, setAuditLog] = useState<string[]>([])
  const [selectedDate, setSelectedDate] = useState(moment().subtract(1, 'day').format('YYYY-MM-DD'))
  const [auditHistory, setAuditHistory] = useState<any[]>([])
  const [showUserWarning, setShowUserWarning] = useState(false)
  const [countdown, setCountdown] = useState(30)
  const [showReportDetails, setShowReportDetails] = useState<any>(null)
  const [realStats, setRealStats] = useState({
    pendingCheckIns: [] as any[],
    pendingCheckOuts: [] as any[],
    dirtyRooms: [] as any[],
    unmarkedArrivals: [] as any[],
    totalRevenue: 0,
    occupiedRooms: 0,
    totalRooms: 15
  })
  
  // Load real calendar data
  useEffect(() => {
    // Only load data if audit is not running (prevent reload during audit)
    if (!isAuditRunning) {
      loadRealData()
      loadAuditHistory()
    }
  }, [selectedDate, isAuditRunning])
  
  const loadRealData = async () => {
    try {
      // Fetch reservations from API (same source as Calendar)
      const resReservations = await fetch('/api/hotel/reservations')
      const reservations = resReservations.ok ? await resReservations.json() : []
      
      // Fetch rooms from API
      const resRooms = await fetch('/api/hotel/rooms')
      const rooms = resRooms.ok ? await resRooms.json() : []
      
      // Get REAL pending check-ins for selected date
      const pendingCheckIns = reservations.filter((r: any) => {
        const checkInDate = moment(r.checkIn).format('YYYY-MM-DD')
        return checkInDate === selectedDate && 
               (r.status === 'CONFIRMED' || r.status === 'PENDING')
      })
      
      // Get unmarked arrivals (CONFIRMED without actualCheckIn) - CRITICAL for NO-SHOW validation
      const unmarkedArrivals = reservations.filter((r: any) => 
        moment(r.checkIn).format('YYYY-MM-DD') === selectedDate &&
        r.status === 'CONFIRMED' &&
        !r.actualCheckIn
      )
      
      // Get REAL pending check-outs for selected date
      const pendingCheckOuts = reservations.filter((r: any) => {
        const checkOutDate = moment(r.checkOut).format('YYYY-MM-DD')
        return checkOutDate === selectedDate && 
               r.status === 'CHECKED_IN'
      })
      
      // Get REAL occupied rooms for selected date
      const occupiedRooms = reservations.filter((r: any) => {
        const checkIn = moment(r.checkIn)
        const checkOut = moment(r.checkOut)
        const selected = moment(selectedDate)
        return r.status === 'CHECKED_IN' && 
               checkIn.isSameOrBefore(selected, 'day') && 
               checkOut.isAfter(selected, 'day')
      }).length
      
      // Calculate REAL revenue for selected date
      const todayRevenue = reservations
        .filter((r: any) => {
          const checkIn = moment(r.checkIn).format('YYYY-MM-DD')
          return checkIn === selectedDate && r.status !== 'CANCELLED'
        })
        .reduce((sum: number, r: any) => sum + (r.totalAmount || 0), 0)
      
      // Get dirty rooms
      const dirtyRooms = rooms.filter((r: any) => 
        r.status === 'DIRTY' || r.status === 'dirty' || r.status === 'Dirty' || r.status === 'cleaning'
      )
      
      setRealStats({
        pendingCheckIns,
        pendingCheckOuts,
        dirtyRooms,
        unmarkedArrivals,
        totalRevenue: todayRevenue,
        occupiedRooms,
        totalRooms: rooms.length || 15
      })
    } catch (error) {
      console.error('Failed to load real data:', error)
      // Fallback to empty data
      setRealStats({
        pendingCheckIns: [],
        pendingCheckOuts: [],
        dirtyRooms: [],
        unmarkedArrivals: [],
        totalRevenue: 0,
        occupiedRooms: 0,
        totalRooms: 15
      })
    }
  }
  
  const calculateRealStatistics = async (date: string) => {
    try {
      const reservations = await fetch('/api/hotel/reservations').then(r => r.json())
      const rooms = await fetch('/api/hotel/rooms').then(r => r.json())
      const totalRooms = rooms.length || 15
      
      // Count actual check-ins for that date
      const checkIns = reservations.filter((r: any) => 
        moment(r.actualCheckIn || r.checkIn).format('YYYY-MM-DD') === date &&
        r.status === 'CHECKED_IN'
      ).length
      
      // Count actual check-outs for that date
      const checkOuts = reservations.filter((r: any) => 
        moment(r.checkOut).format('YYYY-MM-DD') === date &&
        (r.status === 'CHECKED_OUT' || r.autoCheckOut)
      ).length
      
      // Count NO-SHOWS for that date
      const noShows = reservations.filter((r: any) => 
        moment(r.checkIn).format('YYYY-MM-DD') === date &&
        r.status === 'NO_SHOW'
      ).length
      
      // Calculate revenue (only from actual check-ins, excluding NO-SHOWS and CANCELLED)
      const revenue = reservations
        .filter((r: any) => 
          moment(r.actualCheckIn || r.checkIn).format('YYYY-MM-DD') === date &&
          r.status !== 'NO_SHOW' && 
          r.status !== 'CANCELLED'
        )
        .reduce((sum: number, r: any) => sum + (r.totalAmount || 0), 0)
      
      return {
        checkIns,
        checkOuts,
        noShows,
        revenue,
        occupancy: totalRooms > 0 ? Math.round((checkIns / totalRooms) * 100) : 0
      }
    } catch (error) {
      console.error('Error calculating real statistics:', error)
      return {
        checkIns: 0,
        checkOuts: 0,
        noShows: 0,
        revenue: 0,
        occupancy: 0
      }
    }
  }
  
  const loadAuditHistory = async () => {
    const history = JSON.parse(localStorage.getItem('nightAudits') || '[]')
    
    // Recalculate statistics for each audit date from actual reservations
    const enrichedHistory = await Promise.all(
      history.map(async (audit: any) => {
        // Calculate real statistics for this audit date
        const realStats = await calculateRealStatistics(audit.date)
        
        return {
          ...audit,
          checkIns: realStats.checkIns,
          checkOuts: realStats.checkOuts,
          revenue: realStats.revenue,
          occupancy: realStats.occupancy,
          noShows: realStats.noShows,
          // Keep original stats as fallback
          originalStats: audit.stats || {
            totalCheckIns: audit.checkIns || 0,
            totalCheckOuts: audit.checkOuts || 0,
            totalRevenue: audit.revenue || 0,
            occupancyRate: audit.occupancy || 0
          }
        }
      })
    )
    
    setAuditHistory(enrichedHistory.slice(-10).reverse())
  }
  
  // Pre-checks with STRICT validation
  const runPreChecks = () => {
    const checks: Array<{ passed: boolean; message: string; canOverride: boolean; critical?: boolean; details?: string[] }> = []
    
    // 0. PREVENT RUNNING ON SAME DATE TWICE (CRITICAL - CHECK FIRST)
    const alreadyDone = auditHistory.find((a: any) => 
      a.date === selectedDate && 
      a.status === 'completed' &&
      !a.reversed
    )
    
    if (alreadyDone) {
      const completedTime = alreadyDone.completedAt 
        ? moment(alreadyDone.completedAt).format('HH:mm')
        : alreadyDone.closedAt
        ? moment(alreadyDone.closedAt).format('HH:mm')
        : 'უცნობი დრო'
      
      checks.push({
        passed: false,
        critical: true,
        canOverride: false,
        message: `🚫 ${selectedDate} უკვე დახურულია ${completedTime}-ზე`,
        details: [
          `დახურულია: ${moment(alreadyDone.date).format('DD/MM/YYYY')}`,
          `დრო: ${completedTime}`,
          `მომხმარებელი: ${alreadyDone.user || alreadyDone.closedBy || 'უცნობი'}`,
          `სტატუსი: ${alreadyDone.status || 'completed'}`
        ]
      })
      return checks // Stop here - no need to check other validations
    }
    
    // 1. CHECK PENDING CHECK-OUTS (CRITICAL)
    if (realStats.pendingCheckOuts.length > 0) {
      checks.push({
        passed: false,
        critical: true,
        canOverride: false,
        message: `❌ ${realStats.pendingCheckOuts.length} დაუსრულებელი Check-out - უნდა დასრულდეს!`,
        details: realStats.pendingCheckOuts.map((r: any) => `${r.guestName} - Room ${r.roomNumber || r.roomId}`)
      })
    } else {
      checks.push({
        passed: true,
        message: '✅ ყველა Check-out დასრულებულია',
        canOverride: false
      })
    }
    
    // 2. CHECK PENDING CHECK-INS (MUST BE PROCESSED)
    if (realStats.unmarkedArrivals.length > 0) {
      checks.push({
        passed: false,
        critical: true,
        canOverride: false,
        message: `❌ ${realStats.unmarkedArrivals.length} დაუსრულებელი Check-in - გააკეთეთ Check-in ან NO-SHOW!`,
        details: realStats.unmarkedArrivals.map((r: any) => `${r.guestName} - Room ${r.roomNumber || r.roomId}`)
      })
    } else {
      checks.push({
        passed: true,
        message: '✅ ყველა Check-in დამუშავებულია (Check-in ან NO-SHOW)',
        canOverride: false
      })
    }
    
    // 3. CHECK SEQUENTIAL CLOSING (NO GAPS)
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        const daysBetween = moment(selectedDate).diff(moment(lastClosed), 'days')
        
        if (daysBetween > 1) {
          checks.push({
            passed: false,
            critical: true,
            canOverride: false,
            message: `❌ დღის გამოტოვება! ჯერ დახურეთ ${moment(lastClosed).add(1, 'day').format('YYYY-MM-DD')}`,
          })
        } else if (daysBetween === 1) {
          checks.push({
            passed: true,
            message: '✅ Sequential closing შემოწმებულია',
            canOverride: false
          })
        } else if (daysBetween === 0) {
          // This case is already handled by the "already done" check at the beginning
          // No need to add duplicate check here
        }
      } catch (error) {
        console.error('Error parsing lastAuditDate:', error)
      }
    } else {
      // No previous audit - this is the first one
      checks.push({
        passed: true,
        message: '✅ Sequential closing შემოწმებულია (პირველი დახურვა)',
        canOverride: false
      })
    }
    
    // 4. CONTINUING GUESTS (INFO ONLY - NOT BLOCKING)
    if (realStats.occupiedRooms > 0) {
      checks.push({
        passed: true, // Not blocking
        critical: false,
        canOverride: true,
        message: `ℹ️ ${realStats.occupiedRooms} სტუმარი რჩება (Continuing) - OK`,
      })
    }
    
    // 6. Check dirty rooms (non-critical)
    if (realStats.dirtyRooms.length > 0) {
      checks.push({
        passed: false,
        message: `🧹 ${realStats.dirtyRooms.length} ოთახი დასუფთავებაში: ${realStats.dirtyRooms.map((r: any) => r.roomNumber || r.number || r.id).join(', ')}`,
        canOverride: true
      })
    } else {
      checks.push({
        passed: true,
        message: '✅ ყველა ოთახი სუფთაა',
        canOverride: false
      })
    }
    
    // Show detailed status
    const criticalFails = checks.filter(c => c.critical && !c.passed)
    if (criticalFails.length === 0) {
      checks.push({
        passed: true,
        message: '✅ ყველა ვალიდაცია გავლილია - შეგიძლიათ დახუროთ დღე',
        canOverride: false
      })
    }
    
    return checks
  }
  
  // Block Start if critical validations fail
  const canStartAudit = () => {
    const criticalFails = runPreChecks().filter(c => c.critical && !c.passed)
    return criticalFails.length === 0
  }
  
  const startNightAudit = async () => {
    // CRITICAL: Check localStorage directly (not just state) to prevent duplicates
    const historyFromStorage = typeof window !== 'undefined' 
      ? JSON.parse(localStorage.getItem('nightAudits') || '[]')
      : []
    
    const existingAudit = historyFromStorage.find((a: any) => 
      a.date === selectedDate && 
      a.status === 'completed' &&
      !a.reversed
    )
    
    if (existingAudit) {
      const completedTime = existingAudit.completedAt 
        ? moment(existingAudit.completedAt).format('HH:mm')
        : existingAudit.closedAt
        ? moment(existingAudit.closedAt).format('HH:mm')
        : 'უცნობი დრო'
      
      alert(`❌ ეს დღე უკვე დახურულია ${completedTime}-ზე!\n\n` +
            `თარიღი: ${moment(selectedDate).format('DD/MM/YYYY')}\n` +
            `მომხმარებელი: ${existingAudit.user || existingAudit.closedBy || 'უცნობი'}\n\n` +
            `აირჩიეთ სხვა თარიღი.`)
      
      // Reload history to sync state
      await loadAuditHistory()
      return
    }
    
    // Also check if audit is currently running
    if (isAuditRunning) {
      alert('⚠️ Night Audit უკვე მიმდინარეობს! გთხოვთ დაელოდოთ დასრულებას.')
      return
    }
    
    setShowUserWarning(true)
    let timeLeft = 30
    setCountdown(timeLeft)
    
    const countdownInterval = setInterval(() => {
      timeLeft--
      setCountdown(timeLeft)
      
      if (timeLeft <= 0) {
        clearInterval(countdownInterval)
        setShowUserWarning(false)
        startActualAudit()
      }
    }, 1000)
  }
  
  const skipCountdown = () => {
    setShowUserWarning(false)
    startActualAudit()
  }
  
  const startActualAudit = async () => {
    // FINAL CHECK: Verify audit hasn't been completed while countdown was running
    const historyFromStorage = typeof window !== 'undefined' 
      ? JSON.parse(localStorage.getItem('nightAudits') || '[]')
      : []
    
    const existingAudit = historyFromStorage.find((a: any) => 
      a.date === selectedDate && 
      a.status === 'completed' &&
      !a.reversed
    )
    
    if (existingAudit) {
      setIsAuditRunning(false)
      setShowUserWarning(false)
      setShowPreChecks(true)
      await loadAuditHistory()
      
      alert(`❌ Night Audit უკვე დასრულებულია ამ დღისთვის!\n\n` +
            `თარიღი: ${moment(selectedDate).format('DD/MM/YYYY')}\n` +
            `დასრულების დრო: ${existingAudit.completedAt ? moment(existingAudit.completedAt).format('HH:mm') : 'უცნობი'}\n\n` +
            `აირჩიეთ სხვა თარიღი.`)
      return
    }
    
    setIsAuditRunning(true)
    setShowPreChecks(false)
    addToLog(`🌙 Night Audit დაიწყო - ${selectedDate}`)
    
    const auditResult: any = {
      date: selectedDate,
      startTime: moment().format(),
      checkIns: 0,
      checkOuts: 0,
      noShows: 0,
      revenue: 0,
      occupancy: 0
    }
    
    // Process each step
    for (let i = 0; i < 15; i++) {
      await processStep(i, auditResult)
    }
    
    completeAudit(auditResult)
  }
  
  const processStep = async (stepIndex: number, auditResult: any) => {
    setCurrentStep(stepIndex)
    addToLog(`⏳ ${getStepName(stepIndex)}`)
    
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    try {
      switch(stepIndex) {
        case 0: // Block users
          addToLog('🔒 სისტემა დაბლოკილია')
          localStorage.setItem('systemLocked', 'true')
          localStorage.setItem('lockedBy', 'Night Audit')
          break
          
        case 1: // Time check
          if (!isValidAuditTime() && selectedDate === moment().format('YYYY-MM-DD')) {
            addToLog('⚠️ Override: დროის შემოწმება')
          } else {
            addToLog('✓ დროის შემოწმება გავიდა')
          }
          break
          
        case 2: // Process check-ins
          auditResult.noShows = await processRealCheckIns()
          break
          
        case 3: // Process check-outs
          auditResult.checkOuts = await processRealCheckOuts()
          break
          
        case 4: // Update room statuses
          await updateRoomStatusesInCalendar()
          break
          
        case 5: // Financial calculations
          auditResult.revenue = await calculateRealRevenue()
          break
          
        case 6: // Room Charge Posting
          const postingResult = await PostingService.postRoomCharges(selectedDate)
          
          auditResult.roomChargesPosted = postingResult.posted
          auditResult.roomChargeTotal = postingResult.totalAmount
          auditResult.roomChargeFailed = postingResult.failed
          auditResult.roomChargeSkipped = postingResult.skipped
          auditResult.postingDetails = postingResult.details
          
          addToLog(`💰 Room Charges Posted: ${postingResult.posted}`)
          addToLog(`   Total Amount: ₾${postingResult.totalAmount.toFixed(2)}`)
          
          if (postingResult.failed > 0) {
            addToLog(`⚠️ Failed Postings: ${postingResult.failed}`)
          }
          if (postingResult.skipped > 0) {
            addToLog(`ℹ️ Skipped (already posted): ${postingResult.skipped}`)
          }
          
          // Show details for successful postings
          postingResult.details.forEach((detail: any) => {
            if (detail.success) {
              addToLog(`  ✓ ${detail.room} - ${detail.guest}: ₾${detail.amount.toFixed(2)}`)
            } else if (detail.skipped) {
              addToLog(`  ⊘ ${detail.room} - ${detail.guest}: Already posted`)
            } else {
              addToLog(`  ✗ ${detail.room} - ${detail.guest}: Failed - ${detail.error || 'Unknown error'}`)
            }
          })
          break
          
        case 7: // Package Posting
          const packageResult = await PackagePostingService.postPackageCharges(selectedDate)
          
          auditResult.packagesPosted = packageResult.posted
          auditResult.packageTotal = packageResult.totalAmount
          auditResult.packageFailed = packageResult.failed
          auditResult.packageSkipped = packageResult.skipped
          auditResult.packageDetails = packageResult.details
          
          addToLog(`📦 Packages Posted: ${packageResult.posted}`)
          addToLog(`   Total Amount: ₾${packageResult.totalAmount.toFixed(2)}`)
          
          if (packageResult.failed > 0) {
            addToLog(`⚠️ Failed Postings: ${packageResult.failed}`)
          }
          if (packageResult.skipped > 0) {
            addToLog(`ℹ️ Skipped (already posted): ${packageResult.skipped}`)
          }
          
          // Show details for successful postings
          packageResult.details.forEach((detail: any) => {
            if (detail.success) {
              addToLog(`  ✓ ${detail.room} - ${detail.package}: ₾${detail.totalAmount.toFixed(2)}`)
              detail.components?.forEach((comp: any) => {
                addToLog(`    • ${comp.component}: ₾${comp.amount.toFixed(2)}`)
              })
            } else if (detail.skipped) {
              addToLog(`  ⊘ ${detail.room} - ${detail.guest}: Already posted`)
            } else {
              addToLog(`  ✗ ${detail.room} - ${detail.guest}: Failed - ${detail.error || 'Unknown error'}`)
            }
          })
          break
          
        case 8: // Auto-close folios
          const closeResult = await FolioAutoCloseService.autoCloseFolios(selectedDate)
          
          auditResult.foliosClosed = closeResult.closed
          auditResult.foliosClosedDetails = closeResult.details
          
          addToLog(`📁 Folios Auto-Closed: ${closeResult.closed}`)
          if (closeResult.closed > 0) {
            closeResult.details.forEach((detail: any) => {
              addToLog(`  ✓ ${detail.folioNumber} - ${detail.guest}: ${detail.reason}`)
            })
          }
          if (closeResult.skipped > 0) {
            addToLog(`  ⊘ Skipped: ${closeResult.skipped}`)
          }
          if (closeResult.errors > 0) {
            addToLog(`  ✗ Errors: ${closeResult.errors}`)
          }
          break
          
        case 9: // Financial reconciliation
          const revenueReport = await FinancialReportsService.generateDailyRevenueReport(selectedDate)
          const managerReport = await FinancialReportsService.generateManagerReport(selectedDate)
          
          auditResult.financialSummary = {
            revenue: revenueReport.revenue.total,
            taxes: revenueReport.taxes.total,
            payments: revenueReport.payments.total,
            outstanding: managerReport.financial.outstandingBalances
          }
          
          addToLog(`💼 Financial Summary:`)
          addToLog(`  Revenue: ₾${revenueReport.revenue.total.toFixed(2)}`)
          addToLog(`  Taxes: ₾${revenueReport.taxes.total.toFixed(2)}`)
          addToLog(`  Payments: ₾${revenueReport.payments.total.toFixed(2)}`)
          addToLog(`  Outstanding: ₾${managerReport.financial.outstandingBalances.toFixed(2)}`)
          addToLog(`  ADR: ₾${managerReport.kpis.adr}`)
          addToLog(`  RevPAR: ₾${managerReport.kpis.revpar}`)
          addToLog(`  Occupancy: ${managerReport.kpis.occupancyRate}`)
          break
          
        case 10: // Statistics
          auditResult.occupancy = await calculateOccupancy()
          break
          
        case 11: // PDF Reports
          generateReports()
          addToLog('✓ PDF რეპორტები შექმნილია')
          break
          
        case 12: // Email
          sendEmails()
          addToLog('✓ Email რეპორტები გაგზავნილია')
          break
          
        case 13: // Backup
          createBackup()
          addToLog('✓ Backup შექმნილია')
          break
          
        case 14: // Change business day
          if (selectedDate === moment().subtract(1, 'day').format('YYYY-MM-DD')) {
            changeBusinessDay()
          } else {
            addToLog('⚠️ Business Day change skipped (testing mode)')
          }
          break
      }
      
      addToLog(`✅ ${getStepName(stepIndex)} - დასრულდა`)
    } catch (error) {
      addToLog(`❌ Error: ${getStepName(stepIndex)} - ${(error as Error).message}`)
    }
  }
  
  const getStepName = (index: number) => {
    const steps = [
      'მომხმარებლების ბლოკირება',
      'დროის შემოწმება',
      'Check-in პროცესი',
      'Check-out პროცესი',
      'ოთახების განახლება',
      'ფინანსური გამოთვლები',
      '💰 Room Charge Posting',
      '📦 Package Posting',
      '📁 Auto-Close Folios',
      '💼 Financial Reconciliation',
      'სტატისტიკა',
      'PDF რეპორტები',
      'Email გაგზავნა',
      'Backup შექმნა',
      'Business Day ცვლილება'
    ]
    return steps[index] || `Step ${index + 1}`
  }
  
  // Check current time validity
  const isValidAuditTime = () => {
    const hour = moment().hour()
    return (hour >= 20 || hour <= 6)
  }
  
  // Calculate NO-SHOW charge (first night)
  const calculateNoShowCharge = (reservation: any) => {
    const nights = moment(reservation.checkOut).diff(moment(reservation.checkIn), 'days')
    if (nights > 0) {
      return reservation.totalAmount / nights
    }
    return reservation.totalAmount
  }
  
  // Detect NO-SHOWS for a specific date
  const detectNoShows = (date: string, reservations: any[]) => {
    return reservations.filter((r: any) => {
      const checkInDate = moment(r.checkIn).format('YYYY-MM-DD')
      return checkInDate === date && 
             r.status === 'CONFIRMED' &&
             !r.actualCheckIn
    })
  }
  
  // REAL data processing with calendar integration
  const processRealCheckIns = async () => {
    try {
      const res = await fetch('/api/hotel/reservations')
      const reservations = res.ok ? await res.json() : []
      
      // Detect NO-SHOWS for selected date
      const expectedArrivals = detectNoShows(selectedDate, reservations)
      let noShows = 0
      
      if (expectedArrivals.length > 0) {
        const totalCharge = expectedArrivals.reduce((sum: number, r: any) => 
          sum + calculateNoShowCharge(r), 0
        )
        
        addToLog(`🔍 Detected ${expectedArrivals.length} NO-SHOWS for ${selectedDate}`)
        addToLog(`💰 Total charge: ₾${totalCharge.toFixed(2)}`)
        
        // Process each NO-SHOW
        const updatePromises = expectedArrivals.map(async (r: any) => {
          const charge = calculateNoShowCharge(r)
          
          try {
            await fetch('/api/hotel/reservations', {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                id: r.id,
                status: 'NO_SHOW',
                noShowDate: selectedDate,
                noShowCharge: charge,
                markedAsNoShowAt: moment().format(),
                noShowReason: 'Auto-detected during Night Audit'
              })
            })
            
            // Update room status to VACANT
            if (r.roomId) {
              await fetch('/api/hotel/rooms/status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  roomId: r.roomId,
                  status: 'VACANT'
                })
              })
            }
            
            noShows++
            addToLog(`❌ No-Show: ${r.guestName} - Room ${r.roomNumber || r.roomId} (₾${charge.toFixed(2)})`)
          } catch (error) {
            console.error(`Failed to process NO-SHOW for ${r.id}:`, error)
            addToLog(`❌ Error processing NO-SHOW: ${r.guestName}`)
          }
        })
        
        await Promise.all(updatePromises)
      } else {
        addToLog('✅ No NO-SHOWS detected for this date')
      }
      
      return noShows
    } catch (error) {
      console.error('Error processing check-ins:', error)
      addToLog(`❌ Error: ${(error as Error).message}`)
      return 0
    }
  }
  
  const processRealCheckOuts = async () => {
    try {
      const res = await fetch('/api/hotel/reservations')
      const reservations = res.ok ? await res.json() : []
      let checkOuts = 0
      
      const updatePromises = reservations
        .filter((r: any) => 
          moment(r.checkOut).format('YYYY-MM-DD') === selectedDate && 
          r.status === 'CHECKED_IN'
        )
        .map(async (r: any) => {
          checkOuts++
          addToLog(`📤 Auto Check-out: ${r.guestName} - Room ${r.roomNumber || r.roomId}`)
          
          // Update via API
          await fetch('/api/hotel/reservations', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              id: r.id,
              status: 'CHECKED_OUT',
              autoCheckOut: true,
              checkedOutAt: moment().format()
            })
          })
        })
      
      await Promise.all(updatePromises)
      return checkOuts
    } catch (error) {
      console.error('Error processing check-outs:', error)
      return 0
    }
  }
  
  const updateRoomStatusesInCalendar = async () => {
    try {
      const resRooms = await fetch('/api/hotel/rooms')
      const rooms = resRooms.ok ? await resRooms.json() : []
      
      const resReservations = await fetch('/api/hotel/reservations')
      const reservations = resReservations.ok ? await resReservations.json() : []
      
      let updated = 0
      
      const updatePromises = rooms.map(async (room: any) => {
        // Check if room has active reservation
        const hasReservation = reservations.find((r: any) => 
          (r.roomId === room.id || r.roomNumber === room.roomNumber) && 
          r.status === 'CHECKED_IN'
        )
        
        let newStatus = room.status
        
        if (hasReservation) {
          if (room.status !== 'OCCUPIED') {
            newStatus = 'OCCUPIED'
            updated++
          }
        } else if (room.status === 'DIRTY' || room.status === 'dirty' || room.status === 'Dirty') {
          newStatus = 'VACANT'
          updated++
        } else if (room.status === 'OCCUPIED' && !hasReservation) {
          newStatus = 'VACANT'
          updated++
        }
        
        // Update via API if status changed
        if (newStatus !== room.status) {
          await fetch('/api/hotel/rooms/status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              roomId: room.id,
              status: newStatus
            })
          })
        }
      })
      
      await Promise.all(updatePromises)
      addToLog(`🏨 ${updated} ოთახის სტატუსი განახლდა`)
    } catch (error) {
      console.error('Error updating room statuses:', error)
      addToLog(`❌ Error updating room statuses: ${(error as Error).message}`)
    }
  }
  
  const calculateRealRevenue = async () => {
    try {
      const res = await fetch('/api/hotel/reservations')
      const reservations = res.ok ? await res.json() : []
      const revenue = reservations
        .filter((r: any) => {
          const checkIn = moment(r.checkIn).format('YYYY-MM-DD')
          return checkIn === selectedDate && r.status !== 'CANCELLED' && r.status !== 'NO_SHOW'
        })
        .reduce((sum: number, r: any) => sum + (r.totalAmount || 0), 0)
      
      addToLog(`💰 დღიური შემოსავალი: ₾${revenue}`)
      return revenue
    } catch (error) {
      console.error('Error calculating revenue:', error)
      return 0
    }
  }
  
  const calculateOccupancy = async () => {
    const occupancy = realStats.totalRooms > 0 
      ? Math.round((realStats.occupiedRooms / realStats.totalRooms) * 100) 
      : 0
    addToLog(`📊 Occupancy: ${occupancy}% (${realStats.occupiedRooms}/${realStats.totalRooms})`)
    return occupancy
  }
  
  const generateReports = () => {
    const report = {
      date: selectedDate,
      time: moment().format('HH:mm:ss'),
      generated: true
    }
    localStorage.setItem('nightAuditReport', JSON.stringify(report))
  }
  
  const sendEmails = () => {
    const emailQueue = JSON.parse(localStorage.getItem('emailQueue') || '[]')
    emailQueue.push({
      to: ['manager@hotel.com', 'owner@hotel.com'],
      sent: moment().format(),
      status: 'queued',
      subject: `Night Audit Report - ${selectedDate}`
    })
    localStorage.setItem('emailQueue', JSON.stringify(emailQueue))
  }
  
  const createBackup = async () => {
    try {
      const resReservations = await fetch('/api/hotel/reservations')
      const reservations = resReservations.ok ? await resReservations.json() : []
      
      const resRooms = await fetch('/api/hotel/rooms')
      const rooms = resRooms.ok ? await resRooms.json() : []
      
      const audits = JSON.parse(localStorage.getItem('nightAudits') || '[]')
      
      const backup = {
        timestamp: moment().format(),
        reservations,
        rooms,
        audits
      }
      localStorage.setItem(`backup_${selectedDate}`, JSON.stringify(backup))
    } catch (error) {
      console.error('Error creating backup:', error)
    }
  }
  
  const changeBusinessDay = () => {
    const nextDay = moment(selectedDate).add(1, 'day').format('YYYY-MM-DD')
    localStorage.setItem('currentBusinessDate', nextDay)
    localStorage.setItem('lastAuditDate', JSON.stringify(selectedDate))
    addToLog(`📅 Business Day: ${selectedDate} → ${nextDay}`)
  }
  
  const completeAudit = async (auditResult: any) => {
    // CRITICAL: Final check before completing - prevent race conditions
    const historyBeforeSave = JSON.parse(localStorage.getItem('nightAudits') || '[]')
    const alreadyExists = historyBeforeSave.find((h: any) => 
      h.date === auditResult.date && 
      h.status === 'completed' &&
      !h.reversed
    )
    
    if (alreadyExists) {
      // Audit was already completed (possibly by another instance/tab)
      setIsAuditRunning(false)
      setShowPreChecks(true)
      await loadAuditHistory()
      
      addToLog('⚠️ Night Audit უკვე დასრულებულია ამ დღისთვის - გაუქმებულია')
      alert(`❌ Night Audit უკვე დასრულებულია!\n\n` +
            `თარიღი: ${moment(auditResult.date).format('DD/MM/YYYY')}\n` +
            `დასრულების დრო: ${alreadyExists.completedAt ? moment(alreadyExists.completedAt).format('HH:mm') : 'უცნობი'}\n\n` +
            `ეს შეიძლება მოხდეს, თუ audit-ი გაეშვა სხვა ტაბში ან სხვა მომხმარებლის მიერ.`)
      return
    }
    
    auditResult.completedAt = moment().format()
    auditResult.closedAt = moment().format()
    auditResult.user = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem('currentUser') || '{}').name || 'Admin' : 'Admin'
    auditResult.closedBy = auditResult.user
    auditResult.status = 'completed'
    
    // Unlock system
    localStorage.removeItem('systemLocked')
    localStorage.removeItem('lockedBy')
    localStorage.removeItem('lockedAt')
    addToLog('🔓 სისტემა განბლოკილია')
    
    // Save to history - use atomic operation to prevent duplicates
    const history = JSON.parse(localStorage.getItem('nightAudits') || '[]')
    
    // Final duplicate check before saving
    const exists = history.find((h: any) => 
      h.date === auditResult.date && 
      h.status === 'completed' &&
      !h.reversed
    )
    
    if (!exists) {
      history.push({
        id: Date.now(),
        ...auditResult,
        stats: {
          totalCheckIns: auditResult.noShows || 0,
          totalCheckOuts: auditResult.checkOuts || 0,
          totalRevenue: auditResult.revenue || 0,
          occupancyRate: auditResult.occupancy || 0,
          roomChargesPosted: auditResult.roomChargesPosted || 0,
          roomChargeTotal: auditResult.roomChargeTotal || 0
        },
        postingResults: auditResult.postingDetails || [],
        roomChargesPosted: auditResult.roomChargesPosted || 0,
        roomChargeTotal: auditResult.roomChargeTotal || 0,
        roomChargeFailed: auditResult.roomChargeFailed || 0,
        roomChargeSkipped: auditResult.roomChargeSkipped || 0
      })
      localStorage.setItem('nightAudits', JSON.stringify(history))
      addToLog('✅ Night Audit შენახულია history-ში')
    } else {
      // If duplicate detected, log warning but don't save
      setIsAuditRunning(false)
      setShowPreChecks(true)
      await loadAuditHistory()
      
      addToLog('⚠️ Audit already exists for this date - skipping duplicate')
      console.warn('Duplicate audit detected for date:', auditResult.date)
      alert('⚠️ Night Audit უკვე არსებობს ამ დღისთვის!')
      return
    }
    
    // Set audit date properly (always update, even if duplicate)
    localStorage.setItem('lastAuditDate', JSON.stringify(auditResult.date))
    localStorage.setItem('lastNightAuditDate', auditResult.date)
    localStorage.setItem('currentBusinessDate', moment(auditResult.date).add(1, 'day').format('YYYY-MM-DD'))
    
    addToLog('✅ Night Audit დასრულდა')
    
    // IMPORTANT: Update history FIRST before changing selectedDate
    // This ensures the duplicate check works correctly
    await loadAuditHistory()
    
    // Now safely update selectedDate (this will trigger useEffect, but history is already updated)
    const nextDate = moment(auditResult.date).add(1, 'day').format('YYYY-MM-DD')
    
    // Reset form to prevent re-run
    setIsAuditRunning(false)
    setShowPreChecks(true)
    setAuditLog([])
    setCurrentStep(0) // Reset step counter
    
    // Set selectedDate AFTER history is loaded and audit is stopped
    // This prevents race condition where useEffect might trigger before history is updated
    setTimeout(() => {
      setSelectedDate(nextDate)
      
      // Show success message
      setTimeout(() => {
        alert('✅ Night Audit დასრულდა წარმატებით!')
      }, 500)
    }, 500)
  }
  
  const addToLog = (message: string) => {
    setAuditLog(prev => [...prev, `[${moment().format('HH:mm:ss')}] ${message}`])
  }
  
  // Show report details modal
  const ReportDetailsModal = ({ report, onClose }: any) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <h3 className="text-xl font-bold mb-4">📊 Night Audit Report - {report.date}</h3>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-gray-50 p-4 rounded">
            <div className="text-sm text-gray-600">დასრულდა</div>
            <div className="font-bold">{moment(report.completedAt || report.closedAt).format('HH:mm:ss')}</div>
          </div>
          <div className="bg-gray-50 p-4 rounded">
            <div className="text-sm text-gray-600">მომხმარებელი</div>
            <div className="font-bold">{report.user || report.closedBy || 'System'}</div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-blue-50 p-4 rounded">
            <div className="text-sm text-gray-600">Check-ins / No-Shows</div>
            <div className="text-2xl font-bold text-blue-600">{report.noShows || 0}</div>
          </div>
          <div className="bg-green-50 p-4 rounded">
            <div className="text-sm text-gray-600">Check-outs</div>
            <div className="text-2xl font-bold text-green-600">{report.checkOuts || 0}</div>
          </div>
          <div className="bg-purple-50 p-4 rounded">
            <div className="text-sm text-gray-600">შემოსავალი</div>
            <div className="text-2xl font-bold text-purple-600">₾{report.revenue || 0}</div>
          </div>
          <div className="bg-yellow-50 p-4 rounded">
            <div className="text-sm text-gray-600">Occupancy</div>
            <div className="text-2xl font-bold text-yellow-600">{report.occupancy || 0}%</div>
          </div>
        </div>
        
        {/* Room Charge Posting Summary */}
        {report.postingResults && report.postingResults.length > 0 && (
          <div className="mt-6">
            <NightAuditPostingSummary
              date={report.date}
              postingResults={{
                posted: report.roomChargesPosted || 0,
                failed: report.roomChargeFailed || 0,
                skipped: report.roomChargeSkipped || 0,
                totalAmount: report.roomChargeTotal || 0,
                details: report.postingResults || []
              }}
            />
          </div>
        )}
        
        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={() => {
              // Generate PDF report
              alert('PDF რეპორტი იქმნება...')
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            📑 PDF
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
          >
            დახურვა
          </button>
        </div>
      </div>
    </div>
  )
  
  const currentBusinessDate = typeof window !== 'undefined' 
    ? localStorage.getItem('currentBusinessDate') || moment().format('YYYY-MM-DD')
    : moment().format('YYYY-MM-DD')
  
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      {/* User Warning Modal */}
      {showUserWarning && (
        <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-2xl p-8 max-w-lg">
            <div className="text-center">
              <div className="text-6xl mb-4">⚠️</div>
              <h2 className="text-2xl font-bold text-red-600 mb-4">
                Night Audit იწყება!
              </h2>
              <div className="text-5xl font-bold text-red-600 mb-4">{countdown}</div>
              <p className="mb-4">სისტემა დაიბლოკება {countdown} წამში</p>
              <button
                onClick={skipCountdown}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Skip (Test Mode)
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Report Details Modal */}
      {showReportDetails && (
        <ReportDetailsModal 
          report={showReportDetails} 
          onClose={() => setShowReportDetails(null)} 
        />
      )}
      
      {/* Header */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">🌙 Night Audit System v2</h1>
            <p className="text-gray-600 mt-2">
              Business Date: {currentBusinessDate}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <div>
              <label className="text-sm text-gray-600">Select Date:</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                max={moment().format('YYYY-MM-DD')}
                className="ml-2 px-3 py-1 border rounded"
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Pre-checks */}
      {showPreChecks && !isAuditRunning && (
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">📋 Pre-Audit Checklist - {selectedDate}</h2>
          
          {/* Real stats display */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div className="bg-blue-50 p-3 rounded">
              <div className="text-xs text-gray-600">Pending Check-ins</div>
              <div className="text-xl font-bold">{realStats.pendingCheckIns.length}</div>
            </div>
            <div className="bg-orange-50 p-3 rounded">
              <div className="text-xs text-gray-600">Pending Check-outs</div>
              <div className="text-xl font-bold">{realStats.pendingCheckOuts.length}</div>
            </div>
            <div className="bg-yellow-50 p-3 rounded">
              <div className="text-xs text-gray-600">Dirty Rooms</div>
              <div className="text-xl font-bold">{realStats.dirtyRooms.length}</div>
            </div>
            <div className="bg-green-50 p-3 rounded">
              <div className="text-xs text-gray-600">Today Revenue</div>
              <div className="text-xl font-bold">₾{realStats.totalRevenue}</div>
            </div>
          </div>
          
          <div className="space-y-2">
            {runPreChecks().map((check, i) => (
              <div 
                key={i} 
                className={`
                  p-4 rounded-lg mb-2 flex items-start gap-3
                  ${check.critical && !check.passed ? 'bg-red-50 border-2 border-red-500' :
                    check.passed ? 'bg-green-50 border border-green-200' : 'bg-yellow-50 border border-yellow-200'}
                `}
              >
                <div className="flex-1">
                  <div className={`font-medium ${
                    check.critical && !check.passed ? 'text-red-700' :
                    check.passed ? 'text-green-700' : 'text-yellow-700'
                  }`}>
                    {check.message}
                  </div>
                  {check.details && check.details.length > 0 && (
                    <ul className="text-sm mt-2 text-gray-600 list-disc pl-5 space-y-1">
                      {check.details.map((d, j) => (
                        <li key={j}>• {d}</li>
                      ))}
                    </ul>
                  )}
                </div>
                {check.critical && !check.passed && (
                  <span className="px-2 py-1 bg-red-500 text-white rounded text-xs font-bold whitespace-nowrap">
                    BLOCKING
                  </span>
                )}
                {!check.passed && check.canOverride && !check.critical && (
                  <span className="px-2 py-1 bg-yellow-500 text-white rounded text-xs whitespace-nowrap">
                    Override OK
                  </span>
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-6 flex gap-4">
            <button
              onClick={startNightAudit}
              disabled={!canStartAudit()}
              className={`
                px-6 py-3 rounded-lg font-medium transition-colors
                ${canStartAudit() 
                  ? 'bg-blue-600 text-white hover:bg-blue-700' 
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'}
              `}
            >
              {canStartAudit() ? '✅ Start Night Audit' : '❌ Fix Issues First'}
            </button>
            <button 
              onClick={() => {
                setShowPreChecks(true)
                setAuditLog([])
                setIsAuditRunning(false)
              }}
              className="px-6 py-3 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      
      {/* Progress */}
      {isAuditRunning && (
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">⚙️ Audit Progress</h2>
          <div className="mb-6">
            <div className="flex justify-between mb-2">
              <span>Progress</span>
              <span>{Math.round(((currentStep + 1) / 15) * 100)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4">
              <div 
                className="bg-blue-600 h-4 rounded-full transition-all duration-500"
                style={{ width: `${((currentStep + 1) / 15) * 100}%` }}
              />
            </div>
          </div>
          
          {/* Step list */}
          <div className="space-y-2">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].map((stepIndex) => (
              <div 
                key={stepIndex}
                className={`p-3 rounded-lg border ${
                  currentStep > stepIndex ? 'bg-green-50 border-green-300' :
                  currentStep === stepIndex ? 'bg-blue-50 border-blue-500 animate-pulse' :
                  'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  {currentStep > stepIndex && <span className="text-green-600">✅</span>}
                  {currentStep === stepIndex && <span className="animate-spin">⏳</span>}
                  {currentStep < stepIndex && <span className="text-gray-400">⏸️</span>}
                  <span className="text-sm">{getStepName(stepIndex)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Audit Log */}
      {auditLog.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-bold mb-4">📜 Audit Log</h2>
          <div className="bg-black text-green-400 p-4 rounded font-mono text-sm max-h-64 overflow-y-auto">
            {auditLog.map((log, i) => (
              <div key={i} className="mb-1">{log}</div>
            ))}
          </div>
        </div>
      )}
      
      {/* History with enhanced display */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold mb-4">📅 წინა დახურვები</h2>
        {auditHistory.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="p-2 text-left">თარიღი</th>
                  <th className="p-2 text-center">Check-in/Out</th>
                  <th className="p-2 text-right">შემოსავალი</th>
                  <th className="p-2 text-center">Occupancy</th>
                  <th className="p-2 text-center">სტატუსი</th>
                  <th className="p-2 text-center">რეპორტი</th>
                </tr>
              </thead>
              <tbody>
                {auditHistory.map((audit: any, i: number) => (
                  <tr key={i} className="border-t hover:bg-gray-50">
                    <td className="p-2">{moment(audit.date).format('DD/MM/YYYY')}</td>
                    <td className="p-2 text-center">
                      <span className="text-blue-600">{audit.noShows || 0}</span> / 
                      <span className="text-green-600"> {audit.checkOuts || 0}</span>
                    </td>
                    <td className="p-2 text-right font-bold">₾{audit.revenue || 0}</td>
                    <td className="p-2 text-center">{audit.occupancy || 0}%</td>
                    <td className="p-2 text-center">
                      <span className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">
                        {audit.status || 'completed'}
                      </span>
                    </td>
                    <td className="p-2 text-center">
                      <button
                        onClick={() => setShowReportDetails(audit)}
                        className="text-blue-600 hover:text-blue-800 text-sm"
                      >
                        👁️ View
                      </button>
                      {audit.roomChargesPosted > 0 && (
                        <span className="ml-2 text-xs text-green-600" title={`${audit.roomChargesPosted} room charges posted`}>
                          💰
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-gray-500">ჯერ არ არის დახურვები</p>
        )}
      </div>
    </div>
  )
}
