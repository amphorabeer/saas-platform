'use client'

import { useState, useEffect } from 'react'
import moment from 'moment'

interface FolioItem {
  id: string
  date: string
  description: string
  quantity: number
  rate: number
  amount: number
  type: 'room' | 'tax' | 'service' | 'payment' | 'adjustment'
}

interface Folio {
  folioNumber: string
  reservationId: string
  guestName: string
  roomNumber: string
  checkIn: string
  checkOut: string
  items: FolioItem[]
  subtotal: number
  taxes: number
  total: number
  paid: number
  balance: number
  status: 'open' | 'closed'
  createdAt: string
  closedAt?: string
}

export default function FolioSystem() {
  const [folios, setFolios] = useState<Folio[]>([])
  const [pendingFolios, setPendingFolios] = useState<Folio[]>([])
  
  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem('hotelFolios') || '[]')
    setFolios(saved)
    
    // Get pending folios for checkout
    const pending = saved.filter((f: Folio) => f.status === 'open')
    setPendingFolios(pending)
  }, [])
  
  // Generate folio for reservation
  const generateFolio = (reservation: any): Folio => {
    const nights = moment(reservation.checkOut).diff(moment(reservation.checkIn), 'days')
    const roomRate = reservation.totalAmount / nights
    
    const items: FolioItem[] = []
    
    // Add room charges
    for (let i = 0; i < nights; i++) {
      const date = moment(reservation.checkIn).add(i, 'days')
      items.push({
        id: `room-${i}`,
        date: date.format('YYYY-MM-DD'),
        description: `Room ${reservation.roomNumber} - ${reservation.roomType || 'Standard'}`,
        quantity: 1,
        rate: roomRate,
        amount: roomRate,
        type: 'room'
      })
    }
    
    // Calculate taxes (18% VAT + 1% City Tax)
    const subtotal = roomRate * nights
    const vat = subtotal * 0.18
    const cityTax = subtotal * 0.01
    
    items.push({
      id: 'vat',
      date: moment().format('YYYY-MM-DD'),
      description: 'VAT (18%)',
      quantity: 1,
      rate: vat,
      amount: vat,
      type: 'tax'
    })
    
    items.push({
      id: 'city-tax',
      date: moment().format('YYYY-MM-DD'),
      description: 'City Tax (1%)',
      quantity: 1,
      rate: cityTax,
      amount: cityTax,
      type: 'tax'
    })
    
    // Add payments if any
    if (reservation.payments) {
      reservation.payments.forEach((payment: any, idx: number) => {
        items.push({
          id: `payment-${idx}`,
          date: payment.date,
          description: `Payment - ${payment.method}`,
          quantity: 1,
          rate: -payment.amount,
          amount: -payment.amount,
          type: 'payment'
        })
      })
    }
    
    const total = subtotal + vat + cityTax
    const paid = reservation.payments?.reduce((sum: number, p: any) => sum + p.amount, 0) || 0
    
    return {
      folioNumber: `F${Date.now().toString().slice(-8)}`,
      reservationId: reservation.id,
      guestName: reservation.guestName,
      roomNumber: reservation.roomNumber || reservation.roomId || 'N/A',
      checkIn: reservation.checkIn,
      checkOut: reservation.checkOut,
      items,
      subtotal,
      taxes: vat + cityTax,
      total,
      paid,
      balance: total - paid,
      status: 'open',
      createdAt: new Date().toISOString()
    }
  }
  
  // Close folio
  const closeFolio = (folioNumber: string) => {
    const updated = folios.map(f => 
      f.folioNumber === folioNumber 
        ? { ...f, status: 'closed' as const, closedAt: new Date().toISOString() }
        : f
    )
    setFolios(updated)
    localStorage.setItem('hotelFolios', JSON.stringify(updated))
    
    // Update pending list
    const pending = updated.filter((f: Folio) => f.status === 'open')
    setPendingFolios(pending)
  }
  
  // Print/Export folio
  const printFolio = (folio: Folio) => {
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Folio ${folio.folioNumber}</title>
        <style>
          body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; }
          .info { display: flex; justify-content: space-between; margin-bottom: 20px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
          th { background: #f5f5f5; }
          .totals { margin-top: 20px; text-align: right; }
          .total-row { display: flex; justify-content: space-between; max-width: 300px; margin-left: auto; padding: 5px 0; }
          .balance { font-size: 1.2em; font-weight: bold; border-top: 2px solid #333; padding-top: 10px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Hotel Tbilisi</h1>
          <p>FOLIO #${folio.folioNumber}</p>
        </div>
        
        <div class="info">
          <div>
            <p><strong>Guest:</strong> ${folio.guestName}</p>
            <p><strong>Room:</strong> ${folio.roomNumber}</p>
          </div>
          <div>
            <p><strong>Check In:</strong> ${moment(folio.checkIn).format('DD/MM/YYYY')}</p>
            <p><strong>Check Out:</strong> ${moment(folio.checkOut).format('DD/MM/YYYY')}</p>
          </div>
        </div>
        
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Description</th>
              <th>Qty</th>
              <th>Rate</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            ${folio.items.map(item => `
              <tr>
                <td>${moment(item.date).format('DD/MM')}</td>
                <td>${item.description}</td>
                <td>${item.quantity}</td>
                <td>₾${Math.abs(item.rate).toFixed(2)}</td>
                <td>${item.amount < 0 ? '-' : ''}₾${Math.abs(item.amount).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="totals">
          <div class="total-row">
            <span>Subtotal:</span>
            <span>₾${folio.subtotal.toFixed(2)}</span>
          </div>
          <div class="total-row">
            <span>Taxes:</span>
            <span>₾${folio.taxes.toFixed(2)}</span>
          </div>
          <div class="total-row">
            <span>Total:</span>
            <span>₾${folio.total.toFixed(2)}</span>
          </div>
          <div class="total-row">
            <span>Paid:</span>
            <span>₾${folio.paid.toFixed(2)}</span>
          </div>
          <div class="total-row balance">
            <span>Balance Due:</span>
            <span>₾${folio.balance.toFixed(2)}</span>
          </div>
        </div>
      </body>
      </html>
    `
    
    const printWindow = window.open('', '', 'height=800,width=600')
    if (printWindow) {
      printWindow.document.write(html)
      printWindow.document.close()
      printWindow.print()
    }
  }
  
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-bold mb-4">📄 Pending Folios</h3>
        
        {pendingFolios.length > 0 ? (
          <div className="space-y-3">
            {pendingFolios.map(folio => (
              <div key={folio.folioNumber} className="border rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-bold">{folio.folioNumber}</p>
                    <p className="text-sm">{folio.guestName} - Room {folio.roomNumber}</p>
                    <p className="text-sm text-gray-500">
                      {moment(folio.checkIn).format('DD/MM')} - {moment(folio.checkOut).format('DD/MM')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold">₾{folio.balance.toFixed(2)}</p>
                    <p className="text-sm text-gray-500">Balance Due</p>
                  </div>
                </div>
                
                <div className="flex gap-2 mt-3">
                  <button
                    onClick={() => printFolio(folio)}
                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                  >
                    Print
                  </button>
                  <button
                    onClick={() => closeFolio(folio.folioNumber)}
                    className="px-3 py-1 bg-green-600 text-white text-sm rounded hover:bg-green-700"
                  >
                    Close Folio
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-500">No pending folios</p>
        )}
      </div>
    </div>
  )
}

