'use client'

import React, { useState, useMemo, useRef, useEffect } from 'react'
import moment from 'moment'
import PaymentModal from './PaymentModal'
import EnhancedPaymentModal from './EnhancedPaymentModal'
import EditReservationModal from './EditReservationModal'
import CheckOutModal from './CheckOutModal'
import FolioViewModal from './FolioViewModal'
import ExtraChargesPanel from './ExtraChargesPanel'
import PaymentHistory from './PaymentHistory'
import Invoice from './Invoice'
import { ActivityLogger } from '../lib/activityLogger'

interface RoomCalendarProps {
  rooms: any[]
  reservations: any[]
  onSlotClick?: (roomId: string, date: Date, room: any) => void
  onReservationUpdate?: (id: string, updates: any) => Promise<void>
  onReservationDelete?: (id: string) => Promise<void>
  loadReservations?: () => void
}

export default function RoomCalendar({ 
  rooms, 
  reservations, 
  onSlotClick,
  onReservationUpdate,
  onReservationDelete,
  loadReservations
}: RoomCalendarProps) {
  // Start with current date (November 2025)
  const [currentDate, setCurrentDate] = useState(() => {
    // Use actual current date
    return new Date()
  })
  const [view, setView] = useState<'week' | 'month'>('week')
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; items?: Array<{ label: string; action: () => void }> } | null>(null)
  const [selectedReservation, setSelectedReservation] = useState<any>(null)
  const [showDetails, setShowDetails] = useState(false)
  const [showPayment, setShowPayment] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [viewOnlyReservation, setViewOnlyReservation] = useState<any>(null)
  const [showViewOnlyModal, setShowViewOnlyModal] = useState(false)
  const [showNoShowModal, setShowNoShowModal] = useState<any>(null)
  const [showCheckOutModal, setShowCheckOutModal] = useState(false)
  const [showFolioModal, setShowFolioModal] = useState(false)
  const [showExtraChargesModal, setShowExtraChargesModal] = useState(false)
  const [blockedDates, setBlockedDates] = useState<any>({})
  const [maintenanceRooms, setMaintenanceRooms] = useState<string[]>([])
  const menuRef = useRef<HTMLDivElement>(null)
  
  // Load blocked dates from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('blockedDates')
    if (saved) {
      try {
        setBlockedDates(JSON.parse(saved))
      } catch (e) {
        console.error('Failed to load blocked dates:', e)
      }
    }
  }, [])
  
  // Load maintenance rooms from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('maintenanceRooms')
    if (saved) {
      try {
        setMaintenanceRooms(JSON.parse(saved))
      } catch (e) {
        console.error('Failed to load maintenance rooms:', e)
      }
    }
  }, [])
  
  // Get business day (last closed audit + 1)
  const getBusinessDay = () => {
    // Check both lastAuditDate and lastNightAuditDate (prefer lastNightAuditDate)
    const lastNightAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    // Prefer lastNightAuditDate (more accurate)
    let lastClosed: string | null = null
    
    if (lastNightAuditDate) {
      lastClosed = lastNightAuditDate
    } else if (lastAuditDate) {
      try {
        lastClosed = JSON.parse(lastAuditDate)
      } catch {
        lastClosed = lastAuditDate
      }
    }
    
    if (!lastClosed) {
      // No audit yet - Business Day is today
      return moment().format('YYYY-MM-DD')
    }
    
    // Business Day is the day after last audit
    const businessDay = moment(lastClosed).add(1, 'day')
    return businessDay.format('YYYY-MM-DD')
  }
  
  // Check if date can be booked
  const canBookOnDate = (date: Date | string) => {
    const dateStr = typeof date === 'string' ? date : moment(date).format('YYYY-MM-DD')
    // Check both lastAuditDate and lastNightAuditDate (prefer lastNightAuditDate)
    const lastNightAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    // Prefer lastNightAuditDate (more accurate)
    let lastClosed: string | null = null
    
    if (lastNightAuditDate) {
      // lastNightAuditDate is stored as plain string (YYYY-MM-DD)
      lastClosed = lastNightAuditDate
    } else if (lastAuditDate) {
      // lastAuditDate is stored as JSON stringified
      try {
        lastClosed = JSON.parse(lastAuditDate)
      } catch {
        // If parsing fails, try as plain string
        lastClosed = lastAuditDate
      }
    }
    
    if (!lastClosed) {
      // No audit yet - can book from today
      return moment(dateStr).isSameOrAfter(TODAY, 'day')
    }
    
    // Business day is the day after last audit
    const businessDay = moment(lastClosed).add(1, 'day')
    
    // Can book from business day onwards
    return moment(dateStr).isSameOrAfter(businessDay, 'day')
  }
  
  // Alias for backward compatibility
  const isDateBookable = canBookOnDate
  
  // Get current actual date (November 26, 2025)
  const TODAY = moment() // Current date (dynamic)
  
  // Get today's date without time
  const today = useMemo(() => {
    const date = new Date()
    date.setHours(0, 0, 0, 0)
    return date
  }, [])
  
  // Generate dates for view
  const dates = useMemo(() => {
    const result: Date[] = []
    const startDate = new Date(currentDate)
    
    if (view === 'week') {
      // Get start of week (Monday)
      const day = startDate.getDay()
      const diff = startDate.getDate() - day + (day === 0 ? -6 : 1)
      startDate.setDate(diff)
      
      for (let i = 0; i < 7; i++) {
        const date = new Date(startDate)
        date.setDate(startDate.getDate() + i)
        result.push(date)
      }
    } else {
      // Month view - show 30 days
      for (let i = 0; i < 30; i++) {
        const date = new Date(startDate)
        date.setDate(startDate.getDate() + i)
        result.push(date)
      }
    }
    
    return result
  }, [currentDate, view])
  
  // Check if room is available on specific date
  const isRoomAvailable = (roomId: string, date: Date): boolean => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    
    // Check if any reservation exists for this room on this date
    const hasReservation = reservations.some(res => {
      const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
      const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
      
      return res.roomId === roomId && 
             dateStr >= checkIn && 
             dateStr < checkOut &&
             res.status !== 'CANCELLED'
    })
    
    return !hasReservation
  }
  
  // Check if date is valid for new reservation
  const isValidReservationDate = (date: Date): boolean => {
    // Use business day logic instead of "today"
    // If date is bookable (after business day), it's valid
    return canBookOnDate(date)
  }
  
  // Check if date is a closed day (before or on last audit date, or in the past if no audit)
  const isClosedDay = (date: Date | string): boolean => {
    const dateStr = typeof date === 'string' ? date : moment(date).format('YYYY-MM-DD')
    // Check both lastAuditDate and lastNightAuditDate (prefer lastNightAuditDate)
    const lastNightAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    // Prefer lastNightAuditDate (more accurate)
    let lastClosed: string | null = null
    
    if (lastNightAuditDate) {
      // lastNightAuditDate is stored as plain string (YYYY-MM-DD)
      lastClosed = lastNightAuditDate
    } else if (lastAuditDate) {
      // lastAuditDate is stored as JSON stringified
      try {
        lastClosed = JSON.parse(lastAuditDate)
      } catch {
        // If parsing fails, try as plain string
        lastClosed = lastAuditDate
      }
    }
    
    if (!lastClosed) {
      // No audit yet - only past dates (before today) are closed
      return moment(dateStr).isBefore(TODAY, 'day')
    }
    
    // Only dates on or before last audit are closed
    return moment(dateStr).isSameOrBefore(lastClosed, 'day')
  }
  
  // Check if room is in maintenance
  const isRoomInMaintenance = (roomId: string) => {
    return maintenanceRooms.includes(roomId)
  }
  
  // Visual indication for closed days
  const getCellStyle = (room: any, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${room.id}_${dateStr}`
    // Check both lastAuditDate and lastNightAuditDate (prefer lastNightAuditDate)
    const lastNightAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    // Prefer lastNightAuditDate (more accurate)
    let lastClosed: string | null = null
    
    if (lastNightAuditDate) {
      lastClosed = lastNightAuditDate
    } else if (lastAuditDate) {
      try {
        lastClosed = JSON.parse(lastAuditDate)
      } catch {
        lastClosed = lastAuditDate
      }
    }
    
    if (lastClosed) {
      // Days before and including last audit are closed
      if (moment(dateStr).isSameOrBefore(lastClosed, 'day')) {
        return 'bg-gray-100 cursor-not-allowed opacity-50'
      }
    } else {
      // No audit yet - only past dates (before today) are closed
      if (moment(dateStr).isBefore(TODAY, 'day')) {
        return 'bg-gray-100 cursor-not-allowed opacity-50'
      }
    }
    
    // If room is in maintenance - all dates red
    if (room.status === 'MAINTENANCE') {
      return 'bg-red-100 cursor-not-allowed'
    }
    
    // If specific date is blocked
    if (blockedDates[key]) {
      return 'bg-red-100 cursor-not-allowed'
    }
    
    // Check for reservation
    const reservation = getReservation(room.id, date)
    if (reservation) {
      return getStatusColor(reservation.status)
    }
    
    // Future dates or business days
    return 'bg-white hover:bg-blue-50 cursor-pointer'
  }
  
  // Get cell className for background cells
  const getCellClassName = (date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    // Check both lastAuditDate and lastNightAuditDate (prefer lastNightAuditDate)
    const lastNightAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    // Prefer lastNightAuditDate (more accurate)
    let lastClosed: string | null = null
    
    if (lastNightAuditDate) {
      lastClosed = lastNightAuditDate
    } else if (lastAuditDate) {
      try {
        lastClosed = JSON.parse(lastAuditDate)
      } catch {
        lastClosed = lastAuditDate
      }
    }
    
    if (lastClosed) {
      // Days before and including last audit are closed
      if (moment(dateStr).isSameOrBefore(lastClosed, 'day')) {
        return 'bg-gray-100 cursor-not-allowed opacity-50'
      }
    } else {
      // No audit yet - only past dates (before today) are closed
      if (moment(dateStr).isBefore(TODAY, 'day')) {
        return 'bg-gray-100 cursor-not-allowed opacity-50'
      }
    }
    
    // Future dates or business days
    return 'hover:bg-blue-50 cursor-pointer'
  }
  
  // Handle empty slot click
  const handleSlotClick = (roomId: string, date: Date) => {
    console.log('Clicking on date:', date) // Debug log
    
    const room = rooms.find(r => r.id === roomId)
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    
    // Check both lastAuditDate and lastNightAuditDate (prefer lastNightAuditDate)
    const lastNightAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    let canBook = true
    let blockReason = ''
    
    // Prefer lastNightAuditDate (more accurate)
    let lastClosed: string | null = null
    
    if (lastNightAuditDate) {
      lastClosed = lastNightAuditDate
    } else if (lastAuditDate) {
      try {
        lastClosed = JSON.parse(lastAuditDate)
      } catch {
        lastClosed = lastAuditDate
      }
    }
    
    // Check if date is after business day
    if (lastClosed) {
      // Can't book on or before last closed date
      if (moment(dateStr).isSameOrBefore(lastClosed, 'day')) {
        canBook = false
        blockReason = `დახურული დღე (Night Audit: ${moment(lastClosed).format('DD/MM/YYYY')})`
      }
    }
    
    // Check for existing reservation
    const hasReservation = reservations.some((r: any) => 
      r.roomId === roomId && 
      moment(dateStr).isBetween(moment(r.checkIn), moment(r.checkOut), 'day', '[)') &&
      r.status !== 'CANCELLED' &&
      r.status !== 'NO_SHOW'
    )
    
    if (hasReservation) {
      canBook = false
      blockReason = 'უკვე დაკავებულია'
    }
    
    console.log('Can book:', canBook, 'Reason:', blockReason) // Debug
    
    if (!canBook) {
      if (blockReason) {
        alert(`❌ ${blockReason}`)
      }
      return
    }
    
    // Prevent booking if maintenance or blocked
    if (isRoomInMaintenance(roomId)) {
      alert('❌ ეს ოთახი რემონტშია და დაბლოკილია!')
      return
    }
    
    if (room?.status === 'MAINTENANCE') {
      alert('❌ ეს ოთახი რემონტშია და დაბლოკილია!')
      return
    }
    
    if (blockedDates[key]) {
      alert('❌ ეს თარიღი დაბლოკილია!')
      return
    }
    
    // Validation
    if (!isValidReservationDate(date)) {
      alert('❌ ვერ შექმნით ჯავშანს ამ თარიღზე!')
      return
    }
    
    if (!isRoomAvailable(roomId, date)) {
      alert('❌ ოთახი დაკავებულია ამ თარიღზე!')
      return
    }
    
    // Date is valid - open modal
    console.log('Opening modal for:', dateStr) // Debug
    
    // Make sure onSlotClick is called
    if (onSlotClick) {
      onSlotClick(roomId, date, room)
    } else {
      console.error('onSlotClick function not provided!')
    }
  }
  
  // Close context menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setContextMenu(null)
      }
    }
    
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setContextMenu(null)
      }
    }
    
    if (contextMenu) {
      document.addEventListener('mousedown', handleClickOutside)
      document.addEventListener('keydown', handleEscKey)
      return () => {
        document.removeEventListener('mousedown', handleClickOutside)
        document.removeEventListener('keydown', handleEscKey)
      }
    }
  }, [contextMenu])
  
  // Get reservation for room/date
  const getReservation = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    
    return reservations.find(res => {
      const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
      const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
      
      return res.roomId === roomId && 
             dateStr >= checkIn && 
             dateStr < checkOut
    })
  }
  
  // Block/unblock functions
  const blockDate = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    const newBlocked = { ...blockedDates, [key]: true }
    setBlockedDates(newBlocked)
    localStorage.setItem('blockedDates', JSON.stringify(newBlocked))
    setContextMenu(null)
  }
  
  const unblockDate = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    const newBlocked = { ...blockedDates }
    delete newBlocked[key]
    setBlockedDates(newBlocked)
    localStorage.setItem('blockedDates', JSON.stringify(newBlocked))
    setContextMenu(null)
  }
  
  // Handle right-click on reservation
  const handleRightClick = (e: React.MouseEvent, reservation: any) => {
    e.preventDefault()
    e.stopPropagation()
    setSelectedReservation(reservation)
    
    // Adjust position if menu would go off screen
    let x = e.clientX
    let y = e.clientY
    
    if (typeof window !== 'undefined') {
      if (x + 200 > window.innerWidth) {
        x = window.innerWidth - 220
      }
      if (y + 300 > window.innerHeight) {
        y = window.innerHeight - 320
      }
    }
    
    setContextMenu({ x, y })
  }
  
  // Handle right-click on empty cell
  const handleEmptyCellRightClick = (e: React.MouseEvent, roomId: string, date: Date) => {
    e.preventDefault()
    e.stopPropagation()
    
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    const isBlocked = blockedDates[key]
    
    const menu = [
      {
        label: isBlocked ? '✅ განბლოკვა' : '🚫 დაბლოკვა',
        action: () => isBlocked ? unblockDate(roomId, date) : blockDate(roomId, date)
      }
    ]
    
    // Adjust position if menu would go off screen
    let x = e.clientX
    let y = e.clientY
    
    if (typeof window !== 'undefined') {
      if (x + 200 > window.innerWidth) {
        x = window.innerWidth - 220
      }
      if (y + 100 > window.innerHeight) {
        y = window.innerHeight - 120
      }
    }
    
    setContextMenu({ x, y, items: menu })
  }
  
  // Handle double-click on reservation
  const handleDoubleClick = (reservation: any) => {
    setSelectedReservation(reservation)
    setShowDetails(true)
  }
  
  // Context menu actions
  // Check if reservation can be edited (not on closed date)
  // Get relevant date for an action
  const getRelevantDate = (action: string, reservation: any): string => {
    switch (action) {
      case 'check-in':
      case 'no-show':
        return moment(reservation.checkIn).format('YYYY-MM-DD')
      case 'check-out':
        return moment(reservation.checkOut).format('YYYY-MM-DD')
      case 'edit':
      case 'cancel':
      case 'new-reservation':
        return moment(reservation.checkIn).format('YYYY-MM-DD')
      default:
        return moment(reservation.checkIn).format('YYYY-MM-DD')
    }
  }

  // Check if action is allowed on closed dates
  const getAllowedActionsForClosedDate = (action: string, reservation: any): boolean => {
    if (!reservation) return false
    
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    if (!lastAuditDate) return true // No audit date means all dates are editable
    
    // Check-out და Payment ALWAYS allowed (even on closed dates)
    const alwaysAllowedActions = ['check-out', 'payment', 'view-details']
    if (alwaysAllowedActions.includes(action)) {
      return true
    }
    
    // Block other actions on closed dates
    const relevantDate = getRelevantDate(action, reservation)
    if (moment(relevantDate).isSameOrBefore(lastAuditDate)) {
      return false
    }
    
    return true
  }

  // Legacy function for backward compatibility
  const canEditReservation = (reservation: any, action: string = 'edit'): boolean => {
    if (!reservation) return false
    
    // Map old action names to new ones
    const actionMap: { [key: string]: string } = {
      'Check-in': 'check-in',
      'Check-out': 'check-out',
      'NO-SHOW მონიშვნა': 'no-show',
      'გაუქმება': 'cancel',
      'რედაქტირება': 'edit',
      'წაშლა': 'cancel'
    }
    
    const mappedAction = actionMap[action] || action.toLowerCase()
    return getAllowedActionsForClosedDate(mappedAction, reservation)
  }
  
  // Unified action handler
  const handleReservationAction = (action: string, reservation: any): boolean => {
    // Check if action is allowed
    if (!getAllowedActionsForClosedDate(action, reservation)) {
      const blockedActions: { [key: string]: string } = {
        'check-in': '❌ Check-in აღარ შეიძლება დახურულ დღეზე',
        'edit': '❌ რედაქტირება აღარ შეიძლება დახურულ დღეზე',
        'cancel': '❌ გაუქმება აღარ შეიძლება დახურულ დღეზე',
        'no-show': '❌ NO-SHOW მარკირება აღარ შეიძლება დახურულ დღეზე',
        'new-reservation': '❌ ახალი ჯავშანი აღარ შეიძლება დახურულ დღეზე'
      }
      
      const message = blockedActions[action] || `❌ ${action} აღარ შეიძლება დახურულ დღეზე`
      alert(message)
      return false
    }
    
    // Process allowed actions
    switch (action) {
      case 'check-in':
        handleCheckIn()
        break
      case 'check-out':
        handleCheckOut()
        break
      case 'payment':
        setShowPayment(true)
        setContextMenu(null)
        break
      case 'view-details':
        setShowDetails(true)
        setContextMenu(null)
        break
      case 'edit':
        setShowEditModal(true)
        setContextMenu(null)
        break
      case 'cancel':
        handleCancel()
        break
      case 'no-show':
        handleMarkAsNoShow()
        break
      default:
        console.warn('Unknown action:', action)
        return false
    }
    
    return true
  }
  
  // Create folio on check-in
  const createFolioOnCheckIn = async (reservation: any) => {
    if (typeof window === 'undefined') return
    
    const folios = JSON.parse(localStorage.getItem('hotelFolios') || '[]')
    const existingFolio = folios.find((f: any) => f.reservationId === reservation.id)
    
    if (!existingFolio) {
      const newFolio = {
        id: `FOLIO-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        folioNumber: `F${moment().format('YYMMDD')}-${reservation.roomNumber || reservation.roomId || Math.floor(Math.random() * 1000)}`,
        reservationId: reservation.id,
        guestName: reservation.guestName,
        roomNumber: reservation.roomNumber || reservation.roomId,
        balance: 0,
        creditLimit: 5000,
        paymentMethod: 'cash',
        status: 'open',
        openDate: moment().format('YYYY-MM-DD'),
        transactions: []
      }
      
      folios.push(newFolio)
      localStorage.setItem('hotelFolios', JSON.stringify(folios))
      
      ActivityLogger.log('FOLIO_CREATED_ON_CHECKIN', {
        folioNumber: newFolio.folioNumber,
        guest: newFolio.guestName,
        reservationId: reservation.id
      })
    }
  }

  const handleCheckIn = async () => {
    if (!selectedReservation || !onReservationUpdate) return
    
    if (!canEditReservation(selectedReservation, 'Check-in')) {
      setContextMenu(null)
      setSelectedReservation(null)
      return
    }
    
    const now = new Date()
    const checkInDate = new Date(selectedReservation.checkIn)
    
    // Check-in rules
    if (now < checkInDate) {
      if (!confirm('⚠️ Check-in თარიღი ჯერ არ დამდგარა. გსურთ ადრე Check-in?')) {
        return
      }
    }
    
    try {
      // Create folio before check-in
      await createFolioOnCheckIn(selectedReservation)
      
      await onReservationUpdate(selectedReservation.id, {
        status: 'CHECKED_IN',
        actualCheckIn: now.toISOString()
      })
      
      // Update room status to OCCUPIED
      await fetch('/api/hotel/rooms/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: selectedReservation.roomId,
          status: 'OCCUPIED'
        })
      })
      
      ActivityLogger.log('CHECK_IN', {
        guest: selectedReservation.guestName,
        room: selectedReservation.roomNumber,
        reservationId: selectedReservation.id
      })
      
      alert('✅ Check-in წარმატებით დასრულდა!')
    } catch (error) {
      console.error('Failed to check in:', error)
      alert('შეცდომა Check-in-ისას')
    }
    
    setContextMenu(null)
    setSelectedReservation(null)
  }
  
  const handleCheckOut = async () => {
    if (!selectedReservation) return
    
    if (!canEditReservation(selectedReservation, 'Check-out')) {
      setContextMenu(null)
      setSelectedReservation(null)
      return
    }
    
    // Check if checkout date is closed (blocked by Night Audit)
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
    const checkOutDateStr = moment(selectedReservation.checkOut).format('YYYY-MM-DD')
    
    // If checkout date is closed, show special message
    if (lastAuditDate && moment(checkOutDateStr).isSameOrBefore(lastAuditDate)) {
      // Check if Night Audit processed this
      const auditHistory = typeof window !== 'undefined' 
        ? JSON.parse(localStorage.getItem('nightAudits') || '[]')
        : []
      const auditForDate = auditHistory.find((a: any) => a.date === checkOutDateStr && a.status === 'completed')
      
      if (auditForDate && selectedReservation.status === 'CHECKED_IN') {
        alert(`⚠️ ${checkOutDateStr} უკვე დახურულია Night Audit-ით!\n\n` +
              `სტუმარი: ${selectedReservation.guestName}\n` +
              `ოთახი: ${selectedReservation.roomNumber}\n` +
              `სტატუსი: Late Check-out\n\n` +
              `გადახდა: დამატებითი ღამე დარიცხულია`)
        setContextMenu(null)
        setSelectedReservation(null)
        return
      }
      
      alert(`❌ ${checkOutDateStr} დახურულია! Check-out აღარ შეიძლება.`)
      setContextMenu(null)
      setSelectedReservation(null)
      return
    }
    
    // Show check-out modal with folio
    setContextMenu(null)
    setShowCheckOutModal(true)
  }
  
  // Calculate charge based on policy
  const calculateCharge = (chargePolicy: string, reservation: any, customCharge?: number) => {
    const nights = moment(reservation.checkOut).diff(moment(reservation.checkIn), 'days')
    const perNight = nights > 0 ? reservation.totalAmount / nights : reservation.totalAmount
    
    switch (chargePolicy) {
      case 'first':
        return perNight
      case 'full':
        return reservation.totalAmount
      case 'none':
        return 0
      case 'custom':
        return customCharge || 0
      default:
        return perNight
    }
  }
  
  // Mark reservation as NO-SHOW - opens modal
  const handleMarkAsNoShow = () => {
    if (!selectedReservation) return
    
    if (!canEditReservation(selectedReservation, 'NO-SHOW მონიშვნა')) {
      setContextMenu(null)
      setSelectedReservation(null)
      return
    }
    
    setShowNoShowModal(selectedReservation)
    setContextMenu(null)
  }
  
  // Get active reservations (exclude NO-SHOW and CANCELLED for calendar display)
  const getActiveReservations = (reservations: any[]) => {
    return reservations.filter((r: any) => 
      r.status !== 'NO_SHOW' && 
      r.status !== 'CANCELLED'
    )
  }
  
  // Alias for calendar reservations filtering
  const getCalendarReservations = (reservations: any[]) => {
    return getActiveReservations(reservations)
  }
  
  // Process NO-SHOW confirmation from modal
  const processNoShow = async (reservation: any, chargePolicy: string, reason: string, sendNotification: boolean, freeRoom: boolean, customCharge?: number) => {
    if (!onReservationUpdate) return
    
    const charge = calculateCharge(chargePolicy, reservation, customCharge)
    const currentUser = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem('currentUser') || '{"name":"System"}') : { name: 'System' }
    
    try {
      // Check if room can be released (check for conflicts with other reservations)
      if (freeRoom && reservation.roomId) {
        const sameRoomReservations = reservations.filter((r: any) => 
          (r.roomId === reservation.roomId || r.roomNumber === reservation.roomNumber) &&
          r.id !== reservation.id &&
          r.status !== 'NO_SHOW' &&
          r.status !== 'CANCELLED'
        )
        
        const hasConflict = sameRoomReservations.some((r: any) => {
          const checkIn = moment(r.checkIn)
          const checkOut = moment(r.checkOut)
          const resCheckIn = moment(reservation.checkIn)
          const resCheckOut = moment(reservation.checkOut)
          // Check if there's an overlap
          return checkIn.isBefore(resCheckOut, 'day') && checkOut.isAfter(resCheckIn, 'day')
        })
        
        if (hasConflict) {
          alert('❌ ოთახი დაკავებულია ამ თარიღზე! ჯერ გადაიყვანეთ სხვა სტუმარი.')
          setShowNoShowModal(null)
          setSelectedReservation(null)
          return
        }
      }
      
      // Update reservation with NO-SHOW status - keeps it in system
      const updatedReservation = {
        ...reservation,
        status: 'NO_SHOW',
        noShowDate: moment().format(),
        noShowCharge: charge,
        noShowReason: reason || 'Guest did not arrive',
        markedAsNoShowAt: moment().format(),
        noShowMarkedBy: currentUser.name || 'System',
        roomReleased: freeRoom, // Room becomes available
        visible: true // Still visible in reservations list
      }
      
      await onReservationUpdate(reservation.id, updatedReservation)
      
      // Update room status to VACANT immediately if requested
      if (freeRoom && reservation.roomId) {
        await fetch('/api/hotel/rooms/status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            roomId: reservation.roomId,
            status: 'VACANT'
          })
        })
      }
      
      ActivityLogger.log('NO_SHOW', {
        guest: reservation.guestName,
        room: reservation.roomNumber,
        reservationId: reservation.id,
        charge: charge,
        policy: chargePolicy,
        reason: reason,
        markedBy: currentUser.name
      })
      
      // TODO: Send notification if requested
      if (sendNotification) {
        console.log('Notification would be sent to:', reservation.guestEmail)
      }
      
      if (loadReservations) {
        loadReservations()
      }
      
      setShowNoShowModal(null)
      setSelectedReservation(null)
      
      alert(`✅ ${reservation.guestName} - NO-SHOW\n` +
            `Charge: ₾${charge.toFixed(2)}\n` +
            (freeRoom ? `✅ ოთახი ${reservation.roomNumber} გათავისუფლდა` : ''))
      
    } catch (error) {
      console.error('Error marking as NO-SHOW:', error)
      alert('❌ NO-SHOW მარკირებისას შეცდომა მოხდა')
    } finally {
      setContextMenu(null)
    }
  }
  
  const handleCancel = async () => {
    if (!selectedReservation) return
    
    if (!canEditReservation(selectedReservation, 'გაუქმება')) {
      setContextMenu(null)
      setSelectedReservation(null)
      return
    }
    
    if (!confirm('ნამდვილად გსურთ ჯავშნის გაუქმება?')) return
    
    // Delete reservation completely
    if (onReservationDelete) {
      try {
        await onReservationDelete(selectedReservation.id)
        
        ActivityLogger.log('RESERVATION_CANCEL', {
          guest: selectedReservation.guestName,
          room: selectedReservation.roomNumber,
          reservationId: selectedReservation.id
        })
        
        alert('❌ ჯავშანი წაიშალა')
        if (loadReservations) {
          loadReservations()
        }
      } catch (error) {
        console.error('Failed to delete reservation:', error)
        alert('შეცდომა ჯავშნის წაშლისას')
      }
    } else {
      // Fallback to update status if delete not available
      if (onReservationUpdate) {
        try {
          await onReservationUpdate(selectedReservation.id, {
            status: 'CANCELLED',
            cancelledAt: new Date().toISOString()
          })
          
          // Update room status to VACANT
          await fetch('/api/hotel/rooms', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              roomId: selectedReservation.roomId,
              status: 'VACANT'
            })
          })
          
          alert('❌ ჯავშანი გაუქმებულია')
          if (loadReservations) {
            loadReservations()
          }
        } catch (error) {
          console.error('Failed to cancel reservation:', error)
          alert('შეცდომა ჯავშნის გაუქმებისას')
        }
      }
    }
    
    setContextMenu(null)
    setSelectedReservation(null)
  }
  
  // Get status color
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'CONFIRMED': return 'bg-green-500'
      case 'CHECKED_IN': return 'bg-blue-500'
      case 'CHECKED_OUT': return 'bg-gray-400'
      case 'CANCELLED': return 'bg-red-400 opacity-50'
      case 'PENDING': return 'bg-yellow-500'
      case 'NO_SHOW': return 'bg-orange-500 opacity-75'
      default: return 'bg-gray-500'
    }
  }
  
  // Check if date is in the past
  // Check if date is in the past relative to business day, not actual today
  const isPastDate = (date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        const businessDay = moment(lastClosed).add(1, 'day')
        // Only dates before business day are considered "past" for booking purposes
        return moment(dateStr).isBefore(businessDay, 'day')
      } catch {
        // If parsing fails, compare with fixed TODAY
        return moment(dateStr).isBefore(TODAY, 'day')
      }
    }
    
    // If no audit, compare with fixed TODAY
    return moment(dateStr).isBefore(TODAY, 'day')
  }
  
  // Get reservations for room and date
  const getReservationsForRoomAndDate = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    // Return only active reservations (exclude NO-SHOW and CANCELLED)
    return getActiveReservations(
      reservations.filter(res => {
        const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
        const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
        return res.roomId === roomId && 
               dateStr >= checkIn && 
               dateStr < checkOut
      })
    )
  }
  
  // Get reservation style based on status
  const getReservationStyle = (reservation: any) => {
    if (reservation.status === 'NO_SHOW') {
      return {
        background: 'repeating-linear-gradient(45deg, #fee2e2, #fee2e2 10px, #fca5a5 10px, #fca5a5 20px)',
        opacity: 0.6,
        textDecoration: 'line-through'
      }
    }
    
    // Default styles for other statuses
    const statusColors: any = {
      'CONFIRMED': { background: '#3b82f6' }, // bg-blue-500
      'CHECKED_IN': { background: '#10b981' }, // bg-green-500
      'CHECKED_OUT': { background: '#9ca3af' }, // bg-gray-400
      'CANCELLED': { background: '#fca5a5', opacity: 0.5 } // bg-red-300 opacity-50
    }
    
    return statusColors[reservation.status] || { background: '#3b82f6' }
  }
  
  // Render reservation as continuous bar
  const renderReservationBar = (reservation: any, room: any, dateStrings: string[]) => {
    const checkIn = moment(reservation.checkIn)
    const checkOut = moment(reservation.checkOut)
    const firstDate = moment(dateStrings[0])
    const lastDate = moment(dateStrings[dateStrings.length - 1])
    
    // Skip if reservation is outside visible dates
    if (checkOut.isBefore(firstDate, 'day') || checkIn.isAfter(lastDate, 'day')) {
      return null
    }
    
    // Calculate start and end positions
    const startIndex = Math.max(0, checkIn.diff(firstDate, 'days'))
    const endIndex = Math.min(dateStrings.length - 1, checkOut.diff(firstDate, 'days') - 1)
    const spanLength = endIndex - startIndex + 1
    
    if (spanLength <= 0) return null
    
    const nights = checkOut.diff(checkIn, 'days')
    const isNoShow = reservation.status === 'NO_SHOW'
    const reservationStyle = getReservationStyle(reservation)
    
    // Load folio for this reservation (synchronous check)
    let folio: any = null
    let roomChargePosted = false
    
    if (typeof window !== 'undefined') {
      const folios = JSON.parse(localStorage.getItem('hotelFolios') || '[]')
      folio = folios.find((f: any) => f.reservationId === reservation.id)
      
      // Check if room charge posted for today
      if (folio) {
        const today = moment().format('YYYY-MM-DD')
        roomChargePosted = folio.transactions.some((t: any) => 
          t.nightAuditDate === today && 
          t.category === 'room' &&
          t.type === 'charge'
        )
      }
    }
    
    return (
      <div
        key={reservation.id}
        className={`absolute text-white 
                    rounded-lg px-2 py-1 text-xs font-medium
                    hover:shadow-lg transition-shadow cursor-pointer z-10
                    flex items-center justify-center relative
                    ${isNoShow ? 'reservation-no-show' : ''}`}
        style={{
          left: `${(startIndex * 100) / dateStrings.length}%`,
          width: `${(spanLength * 100) / dateStrings.length}%`,
          top: '50%',
          transform: 'translateY(-50%)',
          minWidth: '60px',
          ...reservationStyle
        }}
        onClick={(e) => {
          e.stopPropagation()
          setSelectedReservation(reservation)
          setShowDetails(true)
        }}
        onContextMenu={(e) => {
          e.preventDefault()
          e.stopPropagation()
          handleRightClick(e, reservation)
        }}
        onDoubleClick={(e) => {
          e.stopPropagation()
          handleDoubleClick(reservation)
        }}
        title={`${reservation.guestName} - ${nights} ღამე${isNoShow ? ' (NO-SHOW)' : ''}${folio ? ` | Balance: ₾${folio.balance.toFixed(2)}` : ''}`}
      >
        <div 
          className={`truncate text-center ${isNoShow ? 'line-through' : ''}`}
          style={isNoShow ? { textDecoration: 'line-through' } : {}}
        >
          {reservation.guestName}
          {spanLength > 1 && (
            <span className="ml-1 opacity-75">({nights}დღე)</span>
          )}
          {isNoShow && (
            <span className="ml-1 text-xs opacity-90">❌ NO-SHOW</span>
          )}
        </div>
        
        {/* Folio Balance Indicator */}
        {folio && folio.balance !== 0 && (
          <div className={`absolute top-1 right-1 text-xs px-1 rounded font-bold ${
            folio.balance > 0 ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'
          }`}>
            ₾{Math.abs(folio.balance).toFixed(0)}
          </div>
        )}
        
        {/* Room Charge Posted Indicator */}
        {roomChargePosted && (
          <div className="absolute bottom-1 right-1" title="Room charge posted today">
            <span className="text-green-300 text-xs font-bold">✓</span>
          </div>
        )}
      </div>
    )
  }
  
  // Handle reservation click
  const handleReservationClick = (reservation: any) => {
    // Check if reservation date is in closed period
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        
        // If check-in or any day of reservation is on/before closed date
        if (moment(reservation.checkIn).isSameOrBefore(lastClosed, 'day')) {
          // Show details only - no editing
          setViewOnlyReservation(reservation)
          setShowViewOnlyModal(true)
          return
        }
      } catch (error) {
        console.error('Error parsing lastAuditDate:', error)
      }
    }
    
    // Normal edit for future reservations
    setSelectedReservation(reservation)
    setShowDetails(true)
  }
  
  // Check if room should be OCCUPIED today
  const getRoomCurrentStatus = (room: any) => {
    // If room is in maintenance (from localStorage), return MAINTENANCE
    if (isRoomInMaintenance(room.id)) {
      return 'MAINTENANCE'
    }
    
    // If room status is MAINTENANCE, return MAINTENANCE
    if (room.status === 'MAINTENANCE') {
      return 'MAINTENANCE'
    }
    
    const todayStr = moment().format('YYYY-MM-DD')
    
    // Check if any CHECKED_IN reservation exists for today
    const hasCheckedInGuest = reservations.some(res => {
      const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
      const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
      
      return res.roomId === room.id && 
             res.status === 'CHECKED_IN' &&
             todayStr >= checkIn && 
             todayStr < checkOut
    })
    
    if (hasCheckedInGuest) return 'OCCUPIED'
    
    // Check if room is in cleaning
    if (room.status === 'CLEANING') return 'CLEANING'
    
    // Otherwise vacant
    return 'VACANT'
  }
  
  return (
    <>
      {/* NO-SHOW Reservation Styles */}
      <style dangerouslySetInnerHTML={{__html: `
        .reservation-no-show {
          background: repeating-linear-gradient(
            45deg,
            #fee2e2,
            #fee2e2 10px,
            #fca5a5 10px,
            #fca5a5 20px
          ) !important;
          opacity: 0.7;
        }
        .reservation-no-show .line-through {
          text-decoration: line-through;
        }
      `}} />
      
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Header with controls */}
      <div className="bg-gray-50 border-b p-4 flex justify-between items-center">
        <div className="flex gap-2">
          <button 
            onClick={() => {
              const newDate = new Date(currentDate)
              newDate.setDate(currentDate.getDate() - (view === 'week' ? 7 : 30))
              setCurrentDate(newDate)
            }}
            className="px-3 py-1 border rounded hover:bg-white transition"
          >
            ← წინა
          </button>
          <button 
            onClick={() => setCurrentDate(new Date())}
            className="px-3 py-1 border rounded bg-blue-500 text-white hover:bg-blue-600 transition"
          >
            დღეს
          </button>
          <button 
            onClick={() => {
              const newDate = new Date(currentDate)
              newDate.setDate(currentDate.getDate() + (view === 'week' ? 7 : 30))
              setCurrentDate(newDate)
            }}
            className="px-3 py-1 border rounded hover:bg-white transition"
          >
            შემდეგი →
          </button>
        </div>
        
        <h2 className="text-lg font-bold text-gray-800">
          {moment(currentDate).format('MMMM YYYY')}
        </h2>
        
        <div className="flex gap-2">
          <button
            onClick={() => setView('week')}
            className={`px-3 py-1 border rounded transition ${
              view === 'week' 
                ? 'bg-blue-500 text-white border-blue-500' 
                : 'hover:bg-white'
            }`}
          >
            კვირა
          </button>
          <button
            onClick={() => setView('month')}
            className={`px-3 py-1 border rounded transition ${
              view === 'month' 
                ? 'bg-blue-500 text-white border-blue-500' 
                : 'hover:bg-white'
            }`}
          >
            თვე
          </button>
        </div>
      </div>
      
      {/* Business Day Indicator */}
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-2 mb-2">
        <div className="flex items-center justify-between">
          <span className="text-sm text-yellow-700">
            📅 Business Day: {moment(getBusinessDay()).format('DD/MM/YYYY')}
            {typeof window !== 'undefined' && (() => {
              const lastNightAuditDate = localStorage.getItem('lastNightAuditDate')
              const lastAuditDate = localStorage.getItem('lastAuditDate')
              
              if (lastNightAuditDate) {
                return (
                  <span className="ml-2 text-xs">
                    (ბოლო დახურვა: {moment(lastNightAuditDate).format('DD/MM/YYYY')})
                  </span>
                )
              } else if (lastAuditDate) {
                try {
                  const lastClosed = JSON.parse(lastAuditDate)
                  return (
                    <span className="ml-2 text-xs">
                      (ბოლო დახურვა: {moment(lastClosed).format('DD/MM/YYYY')})
                    </span>
                  )
                } catch {
                  return null
                }
              } else {
                return (
                  <span className="ml-2 text-xs text-green-600">
                    (Night Audit არ არის გაკეთებული - ყველა მომავალი დღე ღიაა)
                  </span>
                )
              }
            })()}
          </span>
          <div className="flex gap-2">
            {/* Debug button - shows localStorage values */}
            <button
              onClick={() => {
                const lastNightAuditDate = localStorage.getItem('lastNightAuditDate')
                const lastAuditDate = localStorage.getItem('lastAuditDate')
                const currentBusinessDate = localStorage.getItem('currentBusinessDate')
                const businessDay = getBusinessDay()
                const today = moment().format('YYYY-MM-DD')
                
                alert(`🔍 Debug Info:\n\n` +
                      `lastNightAuditDate: ${lastNightAuditDate || 'null'}\n` +
                      `lastAuditDate: ${lastAuditDate || 'null'}\n` +
                      `currentBusinessDate: ${currentBusinessDate || 'null'}\n` +
                      `Calculated Business Day: ${businessDay}\n` +
                      `Today: ${today}\n\n` +
                      `თუ Night Audit არ არის გაკეთებული, ყველა მნიშვნელობა უნდა იყოს null.`)
              }}
              className="text-xs text-gray-500 hover:text-gray-700 underline"
              title="Show debug info"
            >
              🔍
            </button>
            {/* Clear audit dates button - only show if dates exist */}
            {typeof window !== 'undefined' && (localStorage.getItem('lastNightAuditDate') || localStorage.getItem('lastAuditDate')) && (
              <button
                onClick={() => {
                  if (confirm('ნამდვილად გსურთ Night Audit თარიღების წაშლა?\n\nეს გაასუფთავებს localStorage-ს და კალენდარი გახდება ღია ყველა მომავალი დღისთვის.')) {
                    localStorage.removeItem('lastNightAuditDate')
                    localStorage.removeItem('lastAuditDate')
                    localStorage.removeItem('currentBusinessDate')
                    // Reload page to apply changes
                    window.location.reload()
                  }
                }}
                className="text-xs text-red-500 hover:text-red-700 underline"
                title="Clear Night Audit dates"
              >
                🗑️ წაშლა
              </button>
            )}
          </div>
        </div>
      </div>
      
      {/* Instructions */}
      <div className="bg-blue-50 p-2 text-sm text-center border-b">
        💡 დააკლიკეთ ცარიელ უჯრას ახალი ჯავშნისთვის | მარჯვენა კლიკი = მენიუ | ორმაგი კლიკი = დეტალები
      </div>
      
      {/* Calendar Grid */}
      <div 
        className="overflow-auto room-calendar-grid" 
        style={{ 
          maxHeight: 'calc(100vh - 350px)',
          minHeight: '400px'
        }}
      >
        <table className="w-full border-collapse">
          <thead className="sticky top-0 z-20 bg-white">
            <tr>
              <th className="border bg-gray-100 p-2 text-left sticky left-0 z-30 min-w-[120px] sticky-room-header">
                ოთახები
              </th>
              {dates.map((date, i) => {
                const isToday = moment(date).format('YYYY-MM-DD') === moment(today).format('YYYY-MM-DD')
                const isPast = isPastDate(date)
                
                return (
                  <th 
                    key={i} 
                    className={`border p-2 min-w-[100px] text-center ${
                      isToday ? 'bg-blue-100' : 
                      isPast ? 'bg-gray-100' : 
                      'bg-gray-50'
                    }`}
                  >
                    <div className="text-xs text-gray-500">
                      {moment(date).format('ddd')}
                    </div>
                    <div className={`font-bold ${isToday ? 'text-blue-600' : ''}`}>
                      {moment(date).format('DD')}
                    </div>
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {rooms.map((room) => {
              const dateStrings = dates.map(d => moment(d).format('YYYY-MM-DD'))
              // Filter out NO-SHOW and CANCELLED reservations from calendar grid
              const roomReservations = getActiveReservations(
                reservations.filter((res: any) => res.roomId === room.id)
              )
              
              return (
                <tr key={room.id} className="hover:bg-gray-50 transition h-16">
                  <td className="border-r border-gray-200 bg-gray-50 p-3 sticky left-0 z-10 font-medium sticky-room-header" style={{ minWidth: '150px' }}>
                    <div>
                      <div className="font-medium">{room.roomNumber}</div>
                      <div className="text-xs text-gray-500">{room.roomType || 'Standard'}</div>
                      {(() => {
                        const displayStatus = getRoomCurrentStatus(room)
                        return (
                          <div className={`text-xs mt-1 px-1 py-0.5 rounded inline-block ${
                            displayStatus === 'OCCUPIED' ? 'bg-red-100 text-red-800' :
                            displayStatus === 'VACANT' ? 'bg-green-100 text-green-800' :
                            displayStatus === 'CLEANING' ? 'bg-yellow-100 text-yellow-800' :
                            displayStatus === 'MAINTENANCE' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {displayStatus}
                          </div>
                        )
                      })()}
                    </div>
                  </td>
                  
                  {/* Single cell for entire period with reservation bars */}
                  <td colSpan={dates.length} className="relative h-16 border-b border-r">
                    {/* Background cells for clicking */}
                    <div className="absolute inset-0 flex">
                      {dates.map((date, idx) => {
                        const isPast = isPastDate(date)
                        const dateStr = moment(date).format('YYYY-MM-DD')
                        const blockedKey = `${room.id}_${dateStr}`
                        const isBlocked = blockedDates[blockedKey] || isRoomInMaintenance(room.id) || room.status === 'MAINTENANCE'
                        const hasReservation = getReservationsForRoomAndDate(room.id, date).length > 0
                        const isClosed = !canBookOnDate(date)
                        
                        return (
                          <div
                            key={idx}
                            className={`flex-1 border-r border-gray-200 ${
                              isClosed
                                ? 'bg-gray-100 cursor-not-allowed opacity-50'
                                : isBlocked 
                                ? 'bg-red-100 cursor-not-allowed' 
                                : hasReservation
                                ? 'cursor-pointer'
                                : getCellClassName(date)
                            }`}
                            onClick={(e) => {
                              e.stopPropagation()
                              const dateStr = moment(date).format('YYYY-MM-DD')
                              console.log('Cell clicked:', dateStr) // Debug
                              
                              // Check if date is closed (before or on last audit)
                              const isClosed = isClosedDay(date)
                              
                              if (canBookOnDate(date) && !isClosed) {
                                const hasReservation = getReservationsForRoomAndDate(room.id, date).length > 0
                                if (!hasReservation && !isBlocked) {
                                  console.log('Calling handleSlotClick for:', dateStr) // Debug
                                  handleSlotClick(room.id, date)
                                } else {
                                  console.log('Click blocked:', { hasReservation, isBlocked, isClosed }) // Debug
                                }
                              } else {
                                console.log('Date not bookable or closed:', dateStr, { canBook: canBookOnDate(date), isClosed }) // Debug
                              }
                            }}
                            onContextMenu={(e) => {
                              const isClosed = isClosedDay(date)
                              if (!isClosed && !hasReservation && canBookOnDate(date)) {
                                handleEmptyCellRightClick(e, room.id, date)
                              }
                            }}
                          >
                            {/* Show blocked indicator */}
                            {isBlocked && !hasReservation && !isClosed && (
                              <div className="h-full flex items-center justify-center">
                                <span className="text-red-500 text-xs font-bold">BLOCKED</span>
                              </div>
                            )}
                            {/* Show closed indicator */}
                            {isClosed && !hasReservation && (
                              <div className="h-full flex items-center justify-center">
                                <span className="text-gray-400 text-xs">დახურული</span>
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                    
                    {/* Render continuous reservation bars */}
                    {roomReservations.map((res: any) => renderReservationBar(res, room, dateStrings))}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      
      {/* Context Menu */}
      {contextMenu && (
        <div
          ref={menuRef}
          className="fixed bg-white rounded-lg shadow-xl border border-gray-200 py-1 z-50 min-w-[200px]"
          style={{ left: contextMenu.x, top: contextMenu.y }}
        >
          {contextMenu.items ? (
            // Empty cell context menu (block/unblock)
            contextMenu.items.map((item, idx) => (
              <button
                key={idx}
                onClick={item.action}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm transition"
              >
                <span>{item.label}</span>
              </button>
            ))
          ) : selectedReservation ? (() => {
            // Check closed dates for this reservation
            const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
            const checkInDate = moment(selectedReservation.checkIn).format('YYYY-MM-DD')
            const checkOutDate = moment(selectedReservation.checkOut).format('YYYY-MM-DD')
            
            const isCheckInClosed = lastAuditDate && moment(checkInDate).isSameOrBefore(lastAuditDate)
            const isCheckOutClosed = lastAuditDate && moment(checkOutDate).isSameOrBefore(lastAuditDate)
            
            return (
              // Reservation context menu
              <>
                <div className="px-3 py-2 border-b border-gray-200">
                  <div className="font-semibold text-sm">{selectedReservation?.guestName}</div>
                  <div className="text-xs text-gray-500">Room {selectedReservation?.roomNumber}</div>
                  <div className="text-xs text-gray-400 mt-1">
                    {selectedReservation?.status === 'CONFIRMED' && '📅 დადასტურებული'}
                    {selectedReservation?.status === 'CHECKED_IN' && '✅ Check In გაკეთებულია'}
                    {selectedReservation?.status === 'CHECKED_OUT' && '🚪 Check Out გაკეთებულია'}
                    {selectedReservation?.status === 'CANCELLED' && '❌ გაუქმებული'}
                    {selectedReservation?.status === 'NO_SHOW' && '❌ NO-SHOW'}
                  </div>
                  {(isCheckInClosed || isCheckOutClosed) && (
                    <div className="text-xs text-orange-600 mt-1 font-medium">
                      ⚠️ {isCheckInClosed ? 'Check-in' : 'Check-out'} date closed
                    </div>
                  )}
                </div>
                
                {/* View Details - ALWAYS ALLOWED */}
                <button
                  onClick={() => handleReservationAction('view-details', selectedReservation)}
                  className="w-full px-3 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm transition"
                >
                  <span>👁️</span> ნახვა დეტალები <span className="text-green-600 text-xs">✓</span>
                </button>
                
                {/* Check-in - BLOCKED on closed dates */}
                {selectedReservation?.status === 'CONFIRMED' && (
                  <button
                    onClick={() => handleReservationAction('check-in', selectedReservation)}
                    disabled={!!isCheckInClosed}
                    className={`w-full px-3 py-2 text-left flex items-center gap-2 text-sm transition ${
                      isCheckInClosed 
                        ? 'opacity-50 cursor-not-allowed text-gray-400' 
                        : 'hover:bg-green-50 text-green-600'
                    }`}
                  >
                    <span>{isCheckInClosed ? '🔒' : '✅'}</span> 
                    Check In {isCheckInClosed && <span className="text-xs">(დახურული)</span>}
                  </button>
                )}
                
                {/* Check-out - ALWAYS ALLOWED */}
                {selectedReservation?.status === 'CHECKED_IN' && (
                  <button
                    onClick={() => handleReservationAction('check-out', selectedReservation)}
                    className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2 text-sm text-blue-600 transition font-medium"
                  >
                    <span>🚪</span> Check Out <span className="text-green-600 text-xs">✓</span>
                  </button>
                )}
                
                {/* Payment - ALWAYS ALLOWED */}
                <button
                  onClick={() => handleReservationAction('payment', selectedReservation)}
                  className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2 text-sm text-blue-700 transition"
                >
                  <span>💳</span> გადახდა <span className="text-green-600 text-xs">✓</span>
                </button>
                
                <div className="border-t border-gray-200 my-1"></div>
                
                {/* View Folio - For CHECKED_IN or CONFIRMED */}
                {(selectedReservation?.status === 'CHECKED_IN' || selectedReservation?.status === 'CONFIRMED') && (
                  <button
                    onClick={() => {
                      setShowFolioModal(true)
                      setContextMenu(null)
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-purple-50 flex items-center gap-2 text-sm text-purple-700 transition"
                  >
                    <span>💰</span> View Folio
                  </button>
                )}
                
                {/* Post Charges - For CHECKED_IN only */}
                {selectedReservation?.status === 'CHECKED_IN' && (
                  <button
                    onClick={() => {
                      setShowExtraChargesModal(true)
                      setContextMenu(null)
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2 text-sm text-blue-700 transition"
                  >
                    <span>➕</span> Post Charges
                  </button>
                )}
                
                <div className="border-t border-gray-200 my-1"></div>
                
                {/* Edit - BLOCKED on closed dates */}
                <button
                  onClick={() => handleReservationAction('edit', selectedReservation)}
                  disabled={!!isCheckInClosed}
                  className={`w-full px-3 py-2 text-left flex items-center gap-2 text-sm transition ${
                    isCheckInClosed 
                      ? 'opacity-50 cursor-not-allowed text-gray-400' 
                      : 'hover:bg-gray-100'
                  }`}
                >
                  <span>{isCheckInClosed ? '🔒' : '✏️'}</span> 
                  რედაქტირება {isCheckInClosed && <span className="text-xs">(დახურული)</span>}
                </button>
                
                {/* Mark as NO-SHOW - BLOCKED on closed dates */}
                {selectedReservation?.status === 'CONFIRMED' && 
                 moment(selectedReservation.checkIn).isSameOrBefore(moment(), 'day') && (
                  <button
                    onClick={() => handleReservationAction('no-show', selectedReservation)}
                    disabled={!!isCheckInClosed}
                    className={`w-full px-3 py-2 text-left flex items-center gap-2 text-sm transition ${
                      isCheckInClosed 
                        ? 'opacity-50 cursor-not-allowed text-gray-400' 
                        : 'hover:bg-red-50 text-red-600'
                    }`}
                  >
                    <span>{isCheckInClosed ? '🔒' : '❌'}</span> 
                    Mark as NO-SHOW {isCheckInClosed && <span className="text-xs">(დახურული)</span>}
                  </button>
                )}
                
                {/* Cancel - BLOCKED on closed dates */}
                {selectedReservation?.status !== 'CHECKED_OUT' && 
                 selectedReservation?.status !== 'CANCELLED' && 
                 selectedReservation?.status !== 'NO_SHOW' && (
                  <button
                    onClick={() => handleReservationAction('cancel', selectedReservation)}
                    disabled={!!isCheckInClosed}
                    className={`w-full px-3 py-2 text-left flex items-center gap-2 text-sm transition ${
                      isCheckInClosed 
                        ? 'opacity-50 cursor-not-allowed text-gray-400' 
                        : 'hover:bg-red-50 text-red-600'
                    }`}
                  >
                    <span>{isCheckInClosed ? '🔒' : '🗑️'}</span> 
                    გაუქმება {isCheckInClosed && <span className="text-xs">(დახურული)</span>}
                  </button>
                )}
              </>
            )
          })() : null}
        </div>
      )}
      
      {/* View Only Modal for Closed Day Reservations */}
      {showViewOnlyModal && viewOnlyReservation && (
        <ViewOnlyReservationModal
          reservation={viewOnlyReservation}
          onClose={() => {
            setShowViewOnlyModal(false)
            setViewOnlyReservation(null)
          }}
        />
      )}
      
      {/* Reservation Details Modal */}
      {showDetails && selectedReservation && (
        <ReservationDetails
          reservation={selectedReservation}
          onClose={() => {
            setShowDetails(false)
            setSelectedReservation(null)
          }}
          onPayment={() => {
            setShowDetails(false)
            setShowPayment(true)
          }}
        />
      )}
      
      {/* Enhanced Payment Modal */}
      {showPayment && selectedReservation && (
        <EnhancedPaymentModal
          reservation={selectedReservation}
          onClose={() => {
            setShowPayment(false)
            setSelectedReservation(null)
          }}
          onSuccess={async (result: any) => {
            setShowPayment(false)
            setSelectedReservation(null)
            
            // Refresh if needed
            if (loadReservations) {
              loadReservations()
            }
            
            // Show success message
            if (result.folio) {
              alert(`✅ Payment processed! New balance: ₾${result.folio.balance.toFixed(2)}`)
            } else {
              alert('✅ Payment processed successfully!')
            }
          }}
        />
      )}
      
      {/* Legacy Payment Modal (kept for other uses) */}
      {false && showPayment && selectedReservation && (
        <PaymentModal
          reservation={selectedReservation}
          onClose={() => {
            setShowPayment(false)
            setSelectedReservation(null)
          }}
          onPayment={async (payment: any) => {
            // Check if processing payment on a closed date
            const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastNightAuditDate') : null
            const checkOutDate = moment(selectedReservation.checkOut).format('YYYY-MM-DD')
            const isClosedDate = lastAuditDate && moment(checkOutDate).isSameOrBefore(lastAuditDate)
            
            // Create payment record with metadata
            const paymentRecord = {
              reservationId: selectedReservation.id,
              amount: payment.paidAmount,
              method: payment.payments?.map((p: any) => p.method).join(', ') || payment.method,
              date: moment().format(), // Today's date
              processedOn: moment().format('YYYY-MM-DD'), // Processing date
              forDate: checkOutDate, // Original reservation date
              note: isClosedDate ? 'Payment processed after Night Audit' : '',
              isPostAudit: isClosedDate,
              payments: payment.payments || [],
              timestamp: new Date().toISOString()
            }
            
            // Save payment record to localStorage (for audit trail)
            if (typeof window !== 'undefined') {
              const paymentHistory = JSON.parse(localStorage.getItem('paymentHistory') || '[]')
              paymentHistory.push({
                ...paymentRecord,
                id: Date.now().toString(),
                guestName: selectedReservation.guestName,
                roomNumber: selectedReservation.roomNumber
              })
              localStorage.setItem('paymentHistory', JSON.stringify(paymentHistory))
            }
            
            // Update reservation
            if (onReservationUpdate) {
              await onReservationUpdate(selectedReservation.id, {
                isPaid: payment.isPaid,
                paidAmount: payment.paidAmount,
                remainingAmount: payment.remainingAmount,
                paymentMethod: payment.payments?.map((p: any) => p.method).join(', ') || payment.method,
                payments: payment.payments || [],
                paidAt: new Date().toISOString(),
                paymentRecord: paymentRecord, // Store full payment record
                isPostAuditPayment: isClosedDate // Flag for post-audit payments
              })
            }
            
            // Log activity
            ActivityLogger.log('PAYMENT_RECEIVED', {
              guest: selectedReservation.guestName,
              room: selectedReservation.roomNumber,
              amount: payment.paidAmount,
              method: payment.payments?.map((p: any) => p.method).join(', ') || payment.method,
              reservationId: selectedReservation.id,
              isFullPayment: payment.isPaid,
              isPostAudit: isClosedDate,
              forDate: checkOutDate,
              processedOn: moment().format('YYYY-MM-DD')
            })
            
            setShowPayment(false)
            setSelectedReservation(null)
            
            // Show success message
            if (isClosedDate) {
              alert(`✅ Payment recorded successfully!\n\n` +
                    `⚠️ Note: This payment was processed after Night Audit for ${checkOutDate}\n` +
                    `Processing date: ${moment().format('YYYY-MM-DD')}`)
            } else {
              alert(payment.isPaid ? 
                '✅ გადახდა სრულად დასრულდა!' : 
                `✅ ნაწილობრივი გადახდა მიღებულია. დარჩენილი: ₾${payment.remainingAmount}`
              )
            }
            
            if (loadReservations) {
              loadReservations()
            }
          }}
        />
      )}
      
      {/* Check-Out Modal */}
      {showCheckOutModal && selectedReservation && (
        <CheckOutModal
          reservation={selectedReservation}
          onClose={() => {
            setShowCheckOutModal(false)
            setSelectedReservation(null)
            setContextMenu(null)
          }}
          onCheckOut={() => {
            setShowCheckOutModal(false)
            setSelectedReservation(null)
            setContextMenu(null)
            if (loadReservations) {
              loadReservations()
            }
          }}
          onReservationUpdate={onReservationUpdate}
        />
      )}
      
      {/* Edit Modal */}
      {showEditModal && selectedReservation && (
        <EditReservationModal
          reservation={selectedReservation}
          rooms={rooms}
          onClose={() => {
            setShowEditModal(false)
            setSelectedReservation(null)
          }}
          onSave={async (updates: any) => {
            if (!canEditReservation(selectedReservation, 'რედაქტირება')) {
              setShowEditModal(false)
              setSelectedReservation(null)
              return
            }
            
            if (onReservationUpdate) {
              await onReservationUpdate(selectedReservation.id, {
                ...updates,
                checkIn: new Date(updates.checkIn).toISOString(),
                checkOut: new Date(updates.checkOut).toISOString()
              })
            }
            setShowEditModal(false)
            setSelectedReservation(null)
            if (loadReservations) {
              loadReservations()
            }
          }}
          onDelete={async (id: string) => {
            if (!canEditReservation(selectedReservation, 'წაშლა')) {
              setShowEditModal(false)
              setSelectedReservation(null)
              return
            }
            
            if (onReservationDelete) {
              await onReservationDelete(id)
            }
            setShowEditModal(false)
            setSelectedReservation(null)
            if (loadReservations) {
              loadReservations()
            }
          }}
        />
      )}
      
      {/* NO-SHOW Confirmation Modal */}
      {showNoShowModal && (
        <NoShowConfirmationModal
          reservation={showNoShowModal}
          onConfirm={processNoShow}
          onCancel={() => setShowNoShowModal(null)}
        />
      )}
      
      {showCheckOutModal && selectedReservation && (
        <CheckOutModal
          reservation={selectedReservation}
          onClose={() => {
            setShowCheckOutModal(false)
            setSelectedReservation(null)
            setContextMenu(null)
          }}
          onCheckOut={() => {
            setShowCheckOutModal(false)
            setSelectedReservation(null)
            setContextMenu(null)
            if (loadReservations) {
              loadReservations()
            }
          }}
          onReservationUpdate={onReservationUpdate}
        />
      )}
      
      {/* Folio View Modal */}
      {showFolioModal && selectedReservation && (
        <FolioViewModal
          reservation={selectedReservation}
          onClose={() => {
            setShowFolioModal(false)
            setSelectedReservation(null)
            setContextMenu(null)
          }}
        />
      )}
      
      {/* Extra Charges Modal */}
      {showExtraChargesModal && selectedReservation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto mx-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Post Extra Charges - {selectedReservation.guestName}</h2>
              <button
                onClick={() => {
                  setShowExtraChargesModal(false)
                  setSelectedReservation(null)
                  setContextMenu(null)
                }}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ×
              </button>
            </div>
            <ExtraChargesPanel
              reservationId={selectedReservation.id}
              onChargePosted={() => {
                // Reload or refresh after charge
                if (loadReservations) {
                  loadReservations()
                }
              }}
            />
          </div>
        </div>
      )}
    </div>
    </>
  )
}

// NO-SHOW Confirmation Modal Component
function NoShowConfirmationModal({ reservation, onConfirm, onCancel }: any) {
  const [chargePolicy, setChargePolicy] = useState('first')
  const [reason, setReason] = useState('არ გამოცხადდა...')
  const [sendNotification, setSendNotification] = useState(true)
  const [freeRoom, setFreeRoom] = useState(true)
  const [customCharge, setCustomCharge] = useState(0)
  
  if (!reservation) return null
  
  const nights = moment(reservation.checkOut).diff(moment(reservation.checkIn), 'days')
  const perNight = nights > 0 ? reservation.totalAmount / nights : reservation.totalAmount
  
  const handleConfirm = () => {
    onConfirm(reservation, chargePolicy, reason, sendNotification, freeRoom, customCharge)
  }
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center" onClick={onCancel}>
      <div className="bg-white rounded-lg shadow-xl p-6 max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-xl font-bold mb-4">❌ Mark as NO-SHOW</h3>
        
        <div className="bg-gray-50 rounded p-4 mb-4">
          <p><strong>სტუმარი:</strong> {reservation.guestName}</p>
          <p><strong>ოთახი:</strong> {reservation.roomNumber || reservation.roomId}</p>
          <p><strong>Check-in:</strong> {moment(reservation.checkIn).format('DD/MM/YYYY')}</p>
          <p><strong>ღამეები:</strong> {nights}</p>
          <p><strong>სრული თანხა:</strong> ₾{reservation.totalAmount}</p>
        </div>
        
        <div className="mb-4">
          <label className="font-bold mb-2 block">Charge Policy:</label>
          <select 
            className="w-full border rounded px-3 py-2" 
            value={chargePolicy}
            onChange={(e) => setChargePolicy(e.target.value)}
          >
            <option value="first">პირველი ღამე (₾{perNight.toFixed(2)})</option>
            <option value="full">სრული თანხა (₾{reservation.totalAmount})</option>
            <option value="none">არ დაერიცხოს</option>
            <option value="custom">სხვა თანხა</option>
          </select>
        </div>
        
        {chargePolicy === 'custom' && (
          <div className="mb-4">
            <label className="font-bold mb-2 block">Custom Amount (₾):</label>
            <input
              type="number"
              id="customCharge"
              value={customCharge}
              onChange={(e) => setCustomCharge(parseFloat(e.target.value) || 0)}
              className="w-full border rounded px-3 py-2"
              min="0"
              step="0.01"
            />
          </div>
        )}
        
        <div className="mb-4">
          <label className="font-bold mb-2 block">მიზეზი:</label>
          <textarea 
            className="w-full border rounded px-3 py-2" 
            rows={2}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="არ გამოცხადდა..."
          />
        </div>
        
        <div className="mb-4 space-y-2">
          <label className="flex items-center">
            <input 
              type="checkbox" 
              className="mr-2" 
              checked={sendNotification}
              onChange={(e) => setSendNotification(e.target.checked)}
            />
            გაეგზავნოს შეტყობინება სტუმარს
          </label>
          <label className="flex items-center">
            <input 
              type="checkbox" 
              className="mr-2" 
              checked={freeRoom}
              onChange={(e) => setFreeRoom(e.target.checked)}
            />
            ოთახი გათავისუფლდეს
          </label>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={handleConfirm}
            className="flex-1 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            დადასტურება
          </button>
          <button
            onClick={onCancel}
            className="flex-1 px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
          >
            გაუქმება
          </button>
        </div>
      </div>
    </div>
  )
}

// Reservation Details Modal
// View Only Modal Component for Closed Day Reservations
function ViewOnlyReservationModal({ reservation, onClose }: any) {
  if (!reservation) return null
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">📋 ჯავშნის დეტალები (მხოლოდ ნახვა)</h2>
          <button onClick={onClose} className="text-2xl hover:text-gray-600">×</button>
        </div>
        
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3 mb-4">
          <p className="text-sm text-yellow-700">
            ⚠️ დახურული პერიოდის ჯავშანი - რედაქტირება შეუზღუდულია
          </p>
        </div>
        
        <div className="space-y-3">
          <div>
            <label className="text-sm text-gray-600">სტუმარი:</label>
            <div className="font-medium">{reservation.guestName}</div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-gray-600">Check In:</label>
              <div>{moment(reservation.checkIn).format('DD/MM/YYYY')}</div>
            </div>
            <div>
              <label className="text-sm text-gray-600">Check Out:</label>
              <div>{moment(reservation.checkOut).format('DD/MM/YYYY')}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-gray-600">ოთახი:</label>
              <div>{reservation.roomNumber || reservation.roomId || 'N/A'}</div>
            </div>
            <div>
              <label className="text-sm text-gray-600">სტატუსი:</label>
              <div>{reservation.status}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-gray-600">თანხა:</label>
              <div>₾{reservation.totalAmount || 0}</div>
            </div>
            <div>
              <label className="text-sm text-gray-600">გადახდა:</label>
              <div>
                {reservation.isPaid === true || reservation.paymentStatus === 'PAID' || (reservation.paidAmount || 0) >= (reservation.totalAmount || 0) 
                  ? '✅ გადახდილი' 
                  : '❌ გადაუხდელი'}
              </div>
            </div>
          </div>
        </div>
        
        <button 
          onClick={onClose}
          className="w-full mt-6 px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition"
        >
          დახურვა
        </button>
      </div>
    </div>
  )
}

function ReservationDetails({ reservation, onClose, onPayment }: any) {
  const [hotelInfo, setHotelInfo] = useState<any>({
    name: 'Hotel Tbilisi',
    companyName: '',
    taxId: '',
    bankName: '',
    bankAccount: '',
    address: 'თბილისი, საქართველო',
    phone: '+995 322 123456',
    email: 'info@hotel.ge',
    logo: ''
  })
  
  useEffect(() => {
    const saved = localStorage.getItem('hotelInfo')
    if (saved) {
      try {
        setHotelInfo(JSON.parse(saved))
      } catch (e) {
        console.error('Failed to load hotel info:', e)
      }
    }
  }, [])
  const nights = moment(reservation.checkOut).diff(moment(reservation.checkIn), 'days')
  
  if (!reservation) return null
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">ჯავშნის დეტალები</h2>
          <button onClick={onClose} className="text-2xl text-gray-500 hover:text-gray-700">×</button>
        </div>
        
        {reservation.reservationNumber && (
          <div className="mb-4 p-3 bg-blue-50 rounded">
            <p className="text-sm text-gray-600">რეზერვაციის ნომერი:</p>
            <p className="text-lg font-bold text-blue-700">#{reservation.reservationNumber}</p>
          </div>
        )}
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <h3 className="font-semibold mb-2 text-gray-800">სტუმრის ინფორმაცია</h3>
            <div className="space-y-1 text-sm">
              <p><span className="text-gray-500">სახელი:</span> <span className="font-medium">{reservation.guestName}</span></p>
              <p><span className="text-gray-500">Email:</span> {reservation.guestEmail || 'N/A'}</p>
              <p><span className="text-gray-500">ტელეფონი:</span> {reservation.guestPhone || 'N/A'}</p>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2 text-gray-800">ჯავშნის ინფორმაცია</h3>
            <div className="space-y-1 text-sm">
              <p><span className="text-gray-500">ოთახი:</span> <span className="font-medium">Room {reservation.roomNumber}</span></p>
              <p><span className="text-gray-500">Check In:</span> {moment(reservation.checkIn).format('DD/MM/YYYY')}</p>
              <p><span className="text-gray-500">Check Out:</span> {moment(reservation.checkOut).format('DD/MM/YYYY')}</p>
              <p><span className="text-gray-500">ღამეები:</span> {nights} ღამე</p>
              <p><span className="text-gray-500">სტატუსი:</span> 
                <span className={`ml-2 px-2 py-1 rounded text-xs text-white ${
                  reservation.status === 'CONFIRMED' ? 'bg-green-500' :
                  reservation.status === 'CHECKED_IN' ? 'bg-blue-500' :
                  reservation.status === 'CHECKED_OUT' ? 'bg-gray-500' :
                  'bg-red-500'
                }`}>
                  {reservation.status}
                </span>
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t pt-4">
          <h3 className="font-semibold mb-2 text-gray-800">Folio / გადახდები</h3>
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-2 text-left">თარიღი</th>
                <th className="p-2 text-left">აღწერა</th>
                <th className="p-2 text-right">თანხა</th>
                <th className="p-2 text-center">სტატუსი</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t">
                <td className="p-2">{moment(reservation.checkIn).format('DD/MM')}</td>
                <td className="p-2">ოთახის ღირებულება ({nights} ღამე)</td>
                <td className="p-2 text-right font-medium">₾{reservation.totalAmount || 0}</td>
                <td className="p-2 text-center">
                  {reservation.isPaid ? (
                    <span className="text-green-600 font-semibold">✓ გადახდილი</span>
                  ) : (
                    <span className="text-orange-500">მოლოდინში</span>
                  )}
                </td>
              </tr>
            </tbody>
            <tfoot className="border-t font-bold bg-gray-50">
              <tr>
                <td colSpan={2} className="p-2">სულ:</td>
                <td className="p-2 text-right">₾{reservation.totalAmount || 0}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
        
        <div className="border-t pt-4 mt-4">
          <h3 className="font-bold mb-2">ინვოისი</h3>
          <Invoice 
            reservation={reservation}
            hotelInfo={hotelInfo}
          />
        </div>
        
        <div className="flex justify-end gap-2 mt-6">
          <button onClick={onClose} className="px-4 py-2 border rounded hover:bg-gray-50 transition">
            დახურვა
          </button>
          {!reservation.isPaid && (
            <button 
              onClick={onPayment}
              className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition"
            >
              💳 გადახდა
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

