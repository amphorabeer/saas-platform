'use client'

import { useState, useEffect } from 'react'
import moment from 'moment'

export default function Reports({ reservations, rooms }: any) {
  const [reportType, setReportType] = useState('daily')
  const [dateRange, setDateRange] = useState({
    start: moment().startOf('month').format('YYYY-MM-DD'),
    end: moment().endOf('month').format('YYYY-MM-DD')
  })
  
  // Calculate occupancy for selected period
  const calculateOccupancy = () => {
    const start = moment(dateRange.start)
    const end = moment(dateRange.end)
    const totalDays = end.diff(start, 'days') + 1
    const totalRoomDays = rooms.length * totalDays
    
    let occupiedDays = 0
    
    reservations.forEach((res: any) => {
      if (res.status === 'CANCELLED') return
      
      const checkIn = moment(res.checkIn)
      const checkOut = moment(res.checkOut)
      
      // Calculate overlap with selected period
      const overlapStart = moment.max(start, checkIn)
      const overlapEnd = moment.min(end, checkOut)
      
      if (overlapEnd.isAfter(overlapStart)) {
        const days = overlapEnd.diff(overlapStart, 'days')
        occupiedDays += days
      }
    })
    
    return totalRoomDays > 0 ? Math.round((occupiedDays / totalRoomDays) * 100) : 0
  }
  
  // Calculate average cleaning time
  const calculateAverageCleaningTime = (tasks: any[]) => {
    const completedTasks = tasks.filter((t: any) => t.startedAt && t.completedAt)
    if (completedTasks.length === 0) return 0
    
    const totalMinutes = completedTasks.reduce((sum: number, task: any) => {
      const start = moment(task.startedAt)
      const end = moment(task.completedAt)
      return sum + end.diff(start, 'minutes')
    }, 0)
    
    return Math.round(totalMinutes / completedTasks.length)
  }
  
  // Group tasks by staff
  const groupTasksByStaff = (tasks: any[]) => {
    const staffMap = new Map()
    
    tasks.forEach((task: any) => {
      const staffName = task.assignedTo || 'დაუნიშნავი'
      if (!staffMap.has(staffName)) {
        staffMap.set(staffName, { name: staffName, tasks: 0, completed: 0, times: [] })
      }
      const staff = staffMap.get(staffName)
      staff.tasks++
      if (task.status === 'completed' || task.status === 'verified') {
        staff.completed++
      }
      if (task.startedAt && task.completedAt) {
        const start = moment(task.startedAt)
        const end = moment(task.completedAt)
        staff.times.push(end.diff(start, 'minutes'))
      }
    })
    
    return Array.from(staffMap.values()).map((staff: any) => ({
      ...staff,
      avgTime: staff.times.length > 0 ? Math.round(staff.times.reduce((a: number, b: number) => a + b, 0) / staff.times.length) : 0
    }))
  }
  
  // Get housekeeping report
  const getHousekeepingReport = () => {
    const housekeepingTasks = JSON.parse(localStorage.getItem('housekeepingTasks') || '[]')
    const archive = JSON.parse(localStorage.getItem('housekeepingArchive') || '[]')
    const allTasks = [...housekeepingTasks, ...archive]
    
    // Filter by date range
    const filteredTasks = allTasks.filter((task: any) => {
      if (!task.completedAt && !task.id) return false
      const taskDate = task.completedAt ? moment(task.completedAt) : moment(parseInt(task.id.split('-')[1]))
      return taskDate.isBetween(dateRange.start, dateRange.end, 'day', '[]')
    })
    
    const completed = filteredTasks.filter((t: any) => t.status === 'completed' || t.status === 'verified').length
    const avgTime = calculateAverageCleaningTime(filteredTasks)
    const byStaff = groupTasksByStaff(filteredTasks)
    const efficiency = filteredTasks.length > 0 ? Math.round((completed / filteredTasks.length) * 100) : 0
    
    return {
      total: filteredTasks.length,
      completed,
      averageTime: avgTime,
      efficiency,
      byStaff
    }
  }
  
  const housekeepingStats = getHousekeepingReport()
  
  // Calculate statistics
  const stats = {
    totalRevenue: reservations
      .filter((r: any) => r.status !== 'CANCELLED' && moment(r.checkIn).isBetween(dateRange.start, dateRange.end, 'day', '[]'))
      .reduce((sum: number, r: any) => sum + (r.totalAmount || 0), 0),
    
    totalReservations: reservations.filter((r: any) => 
      moment(r.checkIn).isBetween(dateRange.start, dateRange.end, 'day', '[]')
    ).length,
    
    occupancyRate: calculateOccupancy(),
    
    averageStay: reservations.length > 0 ? Math.round(
      reservations.reduce((sum: number, r: any) => {
        const days = moment(r.checkOut).diff(moment(r.checkIn), 'days') || 1
        return sum + days
      }, 0) / reservations.length
    ) : 0
  }
  
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📊 რეპორტები</h2>
      
      {/* Date Range Selector */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <div className="flex gap-4 items-center">
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            className="border rounded px-3 py-2"
          >
            <option value="daily">დღიური</option>
            <option value="weekly">კვირეული</option>
            <option value="monthly">თვიური</option>
            <option value="custom">სხვა პერიოდი</option>
          </select>
          
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
            className="border rounded px-3 py-2"
          />
          
          <span>-დან</span>
          
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
            className="border rounded px-3 py-2"
          />
          
          <span>-მდე</span>
          
          <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            📥 ექსპორტი
          </button>
        </div>
      </div>
      
      {/* Statistics Cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-gray-500 text-sm">სულ შემოსავალი</div>
          <div className="text-2xl font-bold text-green-600">₾{stats.totalRevenue}</div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-gray-500 text-sm">ჯავშნები</div>
          <div className="text-2xl font-bold">{stats.totalReservations}</div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-gray-500 text-sm">დატვირთულობა</div>
          <div className="text-2xl font-bold">{stats.occupancyRate}%</div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-4">
          <div className="text-gray-500 text-sm">საშუალო ვადა</div>
          <div className="text-2xl font-bold">{stats.averageStay} დღე</div>
        </div>
      </div>
      
      {/* Detailed Report Table */}
      <div className="bg-white rounded-lg shadow p-4">
        <h3 className="font-semibold mb-4">დეტალური რეპორტი</h3>
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="p-2 text-left">თარიღი</th>
              <th className="p-2 text-left">სტუმარი</th>
              <th className="p-2 text-left">ოთახი</th>
              <th className="p-2 text-left">სტატუსი</th>
              <th className="p-2 text-right">თანხა</th>
            </tr>
          </thead>
          <tbody>
            {reservations
              .filter((r: any) => moment(r.checkIn).isBetween(dateRange.start, dateRange.end, 'day', '[]'))
              .slice(0, 10)
              .map((r: any) => (
              <tr key={r.id} className="border-t">
                <td className="p-2">{moment(r.checkIn).format('DD/MM/YYYY')}</td>
                <td className="p-2">{r.guestName}</td>
                <td className="p-2">Room {r.roomNumber}</td>
                <td className="p-2">
                  <span className={`px-2 py-1 rounded text-xs ${
                    r.status === 'CONFIRMED' ? 'bg-green-100' :
                    r.status === 'CHECKED_IN' ? 'bg-blue-100' :
                    'bg-gray-100'
                  }`}>
                    {r.status}
                  </span>
                </td>
                <td className="p-2 text-right font-medium">₾{r.totalAmount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Housekeeping Report */}
      <div className="bg-white rounded-lg shadow p-4 mt-6">
        <h3 className="font-semibold mb-4">🧹 დასუფთავების ანგარიში</h3>
        <div className="grid grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold">{housekeepingStats.total}</div>
            <div className="text-sm text-gray-500">სულ დავალებები</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{housekeepingStats.completed}</div>
            <div className="text-sm text-gray-500">დასრულებული</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{housekeepingStats.averageTime} წთ</div>
            <div className="text-sm text-gray-500">საშუალო დრო</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold">{housekeepingStats.efficiency}%</div>
            <div className="text-sm text-gray-500">ეფექტურობა</div>
          </div>
        </div>
        
        {/* Staff Performance Table */}
        {housekeepingStats.byStaff.length > 0 && (
          <table className="w-full mt-4 text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-2 text-left">თანამშრომელი</th>
                <th className="p-2 text-center">დავალებები</th>
                <th className="p-2 text-center">დასრულებული</th>
                <th className="p-2 text-center">საშუალო დრო</th>
              </tr>
            </thead>
            <tbody>
              {housekeepingStats.byStaff.map((staff: any) => (
                <tr key={staff.name} className="border-t">
                  <td className="p-2">{staff.name}</td>
                  <td className="p-2 text-center">{staff.tasks}</td>
                  <td className="p-2 text-center">{staff.completed}</td>
                  <td className="p-2 text-center">{staff.avgTime} წთ</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

