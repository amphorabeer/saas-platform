'use client'

import React, { useState, useEffect } from 'react'

export default function PricingSettings() {
  const [activeTab, setActiveTab] = useState('rates')
  const [items, setItems] = useState<any[]>([])
  const [showImport, setShowImport] = useState(false)
  
  const pricingTabs = [
    { id: 'rates', label: 'Room Rates', icon: '💵' },
    { id: 'extras', label: 'Extra Services', icon: '➕' },
    { id: 'packages', label: 'Packages', icon: '📦' },
    { id: 'taxes', label: 'Taxes', icon: '📊' },
    { id: 'quick', label: 'Quick Charges', icon: '⚡' }
  ]
  
  useEffect(() => {
    if (typeof window === 'undefined') return
    const savedItems = localStorage.getItem('chargeItems')
    if (savedItems) {
      try {
        setItems(JSON.parse(savedItems))
      } catch (e) {
        console.error('Error loading items:', e)
      }
    }
  }, [])
  
  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header with Actions */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
          <div>
            <h2 className="text-xl font-bold">💰 Pricing & Charges</h2>
            <p className="text-gray-600 mt-1">Manage all pricing configurations</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setShowImport(true)}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50 transition"
            >
              📥 Import
            </button>
            <button 
              onClick={() => {
                // Export functionality
                const data = { items, rates: [] }
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
                const url = URL.createObjectURL(blob)
                const a = document.createElement('a')
                a.href = url
                a.download = `pricing-export-${new Date().toISOString().split('T')[0]}.json`
                a.click()
              }}
              className="px-4 py-2 border rounded-lg hover:bg-gray-50 transition"
            >
              📤 Export
            </button>
            <button 
              onClick={() => {
                // Navigate to add item based on active tab
                alert('Add item functionality')
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
            >
              + Add Item
            </button>
          </div>
        </div>
        
        {/* Sub-tabs */}
        <div className="flex gap-2 mb-6 border-b overflow-x-auto">
          {pricingTabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 font-medium transition-colors border-b-2 whitespace-nowrap ${
                activeTab === tab.id
                  ? 'text-blue-600 border-blue-600'
                  : 'text-gray-600 border-transparent hover:text-gray-900'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
        
        {/* Content based on active tab */}
        {activeTab === 'rates' && <RoomRatesManager />}
        {activeTab === 'extras' && <ExtraServicesManager items={items} />}
        {activeTab === 'packages' && <PackagesManager />}
        {activeTab === 'taxes' && <TaxesManager />}
        {activeTab === 'quick' && <QuickChargesManager items={items} />}
      </div>
    </div>
  )
}

// Room Rates Manager with Visual Grid
const RoomRatesManager = () => {
  const [rates, setRates] = useState([
    { id: 1, type: 'Standard', weekday: 150, weekend: 180, holiday: 220 },
    { id: 2, type: 'Deluxe', weekday: 200, weekend: 240, holiday: 300 },
    { id: 3, type: 'Suite', weekday: 350, weekend: 400, holiday: 500 }
  ])
  
  useEffect(() => {
    if (typeof window === 'undefined') return
    const savedRates = localStorage.getItem('roomRates')
    if (savedRates) {
      try {
        const parsed = JSON.parse(savedRates)
        if (parsed.length > 0) {
          setRates(parsed)
        }
      } catch (e) {
        console.error('Error loading rates:', e)
      }
    }
  }, [])
  
  const updateRate = (id: number, field: string, value: number) => {
    const updated = rates.map(r => 
      r.id === id ? { ...r, [field]: value } : r
    )
    setRates(updated)
    if (typeof window !== 'undefined') {
      localStorage.setItem('roomRates', JSON.stringify(updated))
    }
  }
  
  const bulkAction = (action: string, percentage?: number) => {
    let updated = [...rates]
    
    if (action === 'increase' && percentage) {
      updated = updated.map(r => ({
        ...r,
        weekday: Math.round(r.weekday * (1 + percentage / 100)),
        weekend: Math.round(r.weekend * (1 + percentage / 100)),
        holiday: Math.round(r.holiday * (1 + percentage / 100))
      }))
    } else if (action === 'decrease' && percentage) {
      updated = updated.map(r => ({
        ...r,
        weekday: Math.round(r.weekday * (1 - percentage / 100)),
        weekend: Math.round(r.weekend * (1 - percentage / 100)),
        holiday: Math.round(r.holiday * (1 - percentage / 100))
      }))
    } else if (action === 'reset') {
      updated = [
        { id: 1, type: 'Standard', weekday: 150, weekend: 180, holiday: 220 },
        { id: 2, type: 'Deluxe', weekday: 200, weekend: 240, holiday: 300 },
        { id: 3, type: 'Suite', weekday: 350, weekend: 400, holiday: 500 }
      ]
    }
    
    setRates(updated)
    if (typeof window !== 'undefined') {
      localStorage.setItem('roomRates', JSON.stringify(updated))
    }
  }
  
  return (
    <div className="space-y-4">
      {/* Visual Rate Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {rates.map(rate => (
          <div key={rate.id} className="border rounded-lg p-4 hover:shadow-lg transition-shadow bg-white">
            <div className="flex justify-between items-start mb-3">
              <h4 className="font-bold text-lg">{rate.type}</h4>
              <button 
                onClick={() => {
                  // Edit functionality
                  alert(`Edit ${rate.type} rates`)
                }}
                className="text-gray-400 hover:text-gray-600 transition"
              >
                ✏️
              </button>
            </div>
            
            <div className="space-y-2">
              <RateInput
                label="Weekday"
                value={rate.weekday}
                onChange={(val) => updateRate(rate.id, 'weekday', val)}
                color="blue"
              />
              <RateInput
                label="Weekend"
                value={rate.weekend}
                onChange={(val) => updateRate(rate.id, 'weekend', val)}
                color="green"
              />
              <RateInput
                label="Holiday"
                value={rate.holiday}
                onChange={(val) => updateRate(rate.id, 'holiday', val)}
                color="red"
              />
            </div>
            
            {/* Quick Actions */}
            <div className="mt-4 pt-4 border-t flex gap-2">
              <button 
                onClick={() => alert('Rate history')}
                className="text-xs px-2 py-1 bg-blue-100 text-blue-600 rounded hover:bg-blue-200 transition"
              >
                📊 History
              </button>
              <button 
                onClick={() => alert('Rate schedule')}
                className="text-xs px-2 py-1 bg-green-100 text-green-600 rounded hover:bg-green-200 transition"
              >
                📅 Schedule
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {/* Bulk Actions */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h4 className="font-semibold mb-3">Bulk Actions</h4>
        <div className="flex gap-2 flex-wrap">
          <button 
            onClick={() => {
              const percent = prompt('Enter percentage to increase:')
              if (percent) bulkAction('increase', parseFloat(percent))
            }}
            className="px-3 py-1.5 bg-white border rounded hover:bg-gray-50 text-sm transition"
          >
            📈 Increase All by %
          </button>
          <button 
            onClick={() => {
              const percent = prompt('Enter percentage to decrease:')
              if (percent) bulkAction('decrease', parseFloat(percent))
            }}
            className="px-3 py-1.5 bg-white border rounded hover:bg-gray-50 text-sm transition"
          >
            📉 Decrease All by %
          </button>
          <button 
            onClick={() => {
              if (confirm('Reset all rates to default?')) {
                bulkAction('reset')
              }
            }}
            className="px-3 py-1.5 bg-white border rounded hover:bg-gray-50 text-sm transition"
          >
            🔄 Reset to Default
          </button>
        </div>
      </div>
    </div>
  )
}

// Rate Input Component
const RateInput = ({ label, value, onChange, color }: {
  label: string
  value: number
  onChange: (val: number) => void
  color: string
}) => {
  const colors: Record<string, string> = {
    blue: 'focus:border-blue-500 focus:ring-blue-500',
    green: 'focus:border-green-500 focus:ring-green-500',
    red: 'focus:border-red-500 focus:ring-red-500'
  }
  
  return (
    <div className="flex justify-between items-center">
      <span className="text-sm text-gray-600">{label}:</span>
      <div className="flex items-center">
        <span className="text-gray-500 mr-1">₾</span>
        <input
          type="number"
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
          className={`w-20 border rounded px-2 py-1 text-right font-medium focus:outline-none focus:ring-1 ${colors[color] || colors.blue}`}
          min="0"
          step="1"
        />
      </div>
    </div>
  )
}

// Extra Services Manager
const ExtraServicesManager = ({ items }: { items: any[] }) => {
  return (
    <div className="space-y-4">
      <p className="text-gray-600">Extra services management - integrate with ChargesSettings</p>
      <div className="text-sm text-gray-500">
        {items.length} items available
      </div>
    </div>
  )
}

// Packages Manager
const PackagesManager = () => {
  return (
    <div className="space-y-4">
      <p className="text-gray-600">Packages management - integrate with PackagePostingService</p>
    </div>
  )
}

// Taxes Manager
const TaxesManager = () => {
  const [taxes, setTaxes] = useState({
    VAT: 18,
    CITY_TAX: 3,
    TOURISM_TAX: 1,
    SERVICE_CHARGE: 10
  })
  
  useEffect(() => {
    if (typeof window === 'undefined') return
    const saved = localStorage.getItem('taxSettings')
    if (saved) {
      try {
        setTaxes(JSON.parse(saved))
      } catch (e) {
        console.error('Error loading tax settings:', e)
      }
    }
  }, [])
  
  const saveTaxes = () => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('taxSettings', JSON.stringify(taxes))
      alert('✅ Tax settings saved!')
    }
  }
  
  return (
    <div className="space-y-4">
      <div className="max-w-2xl">
        <h3 className="text-lg font-bold mb-4">Tax Configuration</h3>
        
        <div className="space-y-4">
          {Object.entries(taxes).map(([key, value]) => (
            <div key={key} className="flex items-center justify-between p-3 bg-gray-50 rounded">
              <label className="font-medium">
                {key.replace(/_/g, ' ')}
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={value}
                  onChange={(e) => setTaxes({...taxes, [key]: parseFloat(e.target.value) || 0})}
                  className="w-20 border rounded px-2 py-1 text-right focus:outline-none focus:ring-1 focus:ring-blue-500"
                  step="0.5"
                  min="0"
                  max="100"
                />
                <span>%</span>
              </div>
            </div>
          ))}
        </div>
        
        <button
          onClick={saveTaxes}
          className="mt-6 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
        >
          Save Tax Settings
        </button>
      </div>
    </div>
  )
}

// Quick Charges Manager
const QuickChargesManager = ({ items }: { items: any[] }) => {
  const [quickButtons, setQuickButtons] = useState<any[]>([])
  
  useEffect(() => {
    if (typeof window === 'undefined') return
    const saved = localStorage.getItem('quickButtons')
    if (saved) {
      try {
        setQuickButtons(JSON.parse(saved))
      } catch (e) {
        console.error('Error loading quick buttons:', e)
      }
    }
  }, [])
  
  return (
    <div className="space-y-4">
      <p className="text-gray-600">Quick charges configuration - integrate with ChargesSettings Quick Buttons tab</p>
      <div className="text-sm text-gray-500">
        {quickButtons.length} quick buttons configured
      </div>
    </div>
  )
}

