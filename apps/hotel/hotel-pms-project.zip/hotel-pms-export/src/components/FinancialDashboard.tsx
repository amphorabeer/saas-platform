'use client'

import React, { useState, useEffect } from 'react'
import moment from 'moment'
import { FinancialReportsService } from '../services/FinancialReportsService'

export default function FinancialDashboard() {
  const [selectedDate, setSelectedDate] = useState(moment().format('YYYY-MM-DD'))
  const [revenueReport, setRevenueReport] = useState<any>(null)
  const [managerReport, setManagerReport] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  
  useEffect(() => {
    loadReports()
  }, [selectedDate])
  
  const loadReports = async () => {
    setLoading(true)
    
    try {
      const revenue = await FinancialReportsService.generateDailyRevenueReport(selectedDate)
      const manager = await FinancialReportsService.generateManagerReport(selectedDate)
      
      setRevenueReport(revenue)
      setManagerReport(manager)
    } catch (error) {
      console.error('Error loading reports:', error)
    } finally {
      setLoading(false)
    }
  }
  
  if (loading) {
    return (
      <div className="p-6">
        <div className="bg-white rounded-lg shadow-lg p-6 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading reports...</p>
        </div>
      </div>
    )
  }
  
  if (!revenueReport || !managerReport) {
    return (
      <div className="p-6">
        <div className="bg-white rounded-lg shadow-lg p-6 text-center">
          <p className="text-gray-500">No data available</p>
        </div>
      </div>
    )
  }
  
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">💰 Financial Dashboard</h1>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="border rounded px-3 py-2"
          />
        </div>
      </div>
      
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <KPICard
          title="Revenue"
          value={`₾${revenueReport.revenue.total.toFixed(2)}`}
          icon="💰"
          color="green"
        />
        <KPICard
          title="Occupancy"
          value={managerReport.kpis.occupancyRate}
          icon="🏨"
          color="blue"
        />
        <KPICard
          title="ADR"
          value={`₾${managerReport.kpis.adr}`}
          icon="📊"
          color="purple"
        />
        <KPICard
          title="RevPAR"
          value={`₾${managerReport.kpis.revpar}`}
          icon="📈"
          color="orange"
        />
      </div>
      
      {/* Revenue by Category */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-bold mb-4">Revenue by Category</h2>
          <div className="space-y-3">
            {Object.entries(revenueReport.revenue.byCategory)
              .filter(([_, amount]: any) => amount > 0)
              .map(([cat, amount]: any) => (
              <div key={cat} className="flex justify-between items-center">
                <span className="capitalize font-medium">{cat}</span>
                <div className="flex items-center gap-2 flex-1 max-w-xs">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full transition-all"
                      style={{ 
                        width: `${revenueReport.revenue.total > 0 ? (amount / revenueReport.revenue.total) * 100 : 0}%` 
                      }}
                    />
                  </div>
                  <span className="font-bold w-20 text-right">
                    ₾{amount.toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
            {Object.values(revenueReport.revenue.byCategory).every((v: any) => v === 0) && (
              <p className="text-gray-500 text-center py-4">No revenue data for this date</p>
            )}
          </div>
        </div>
        
        {/* Revenue by Department */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-bold mb-4">Revenue by Department</h2>
          <div className="space-y-3">
            {Object.entries(revenueReport.revenue.byDepartment)
              .filter(([_, amount]: any) => amount > 0)
              .map(([dept, amount]: any) => (
              <div key={dept} className="flex justify-between items-center">
                <span className="font-medium">{dept}</span>
                <div className="flex items-center gap-2 flex-1 max-w-xs">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full transition-all"
                      style={{ 
                        width: `${revenueReport.revenue.total > 0 ? (amount / revenueReport.revenue.total) * 100 : 0}%` 
                      }}
                    />
                  </div>
                  <span className="font-bold w-20 text-right">
                    ₾{amount.toFixed(2)}
                  </span>
                </div>
              </div>
            ))}
            {Object.values(revenueReport.revenue.byDepartment).every((v: any) => v === 0) && (
              <p className="text-gray-500 text-center py-4">No revenue data for this date</p>
            )}
          </div>
        </div>
      </div>
      
      {/* Payment Methods & Tax Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Payment Methods */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-bold mb-4">Payment Methods</h2>
          <div className="space-y-2">
            {Object.entries(revenueReport.payments.methods)
              .filter(([_, amount]: any) => amount > 0)
              .map(([method, amount]: any) => (
              <div key={method} className="flex justify-between">
                <span className="capitalize font-medium">{method}</span>
                <span className="font-bold">₾{amount.toFixed(2)}</span>
              </div>
            ))}
            {revenueReport.payments.total === 0 && (
              <p className="text-gray-500 text-center py-2">No payments for this date</p>
            )}
            {revenueReport.payments.total > 0 && (
              <div className="border-t pt-2 font-bold flex justify-between">
                <span>Total</span>
                <span>₾{revenueReport.payments.total.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>
        
        {/* Tax Summary */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-lg font-bold mb-4">Tax Summary</h2>
          <div className="space-y-2">
            {revenueReport.taxes.VAT > 0 && (
              <div className="flex justify-between">
                <span>VAT (18%)</span>
                <span>₾{revenueReport.taxes.VAT.toFixed(2)}</span>
              </div>
            )}
            {revenueReport.taxes.CITY_TAX > 0 && (
              <div className="flex justify-between">
                <span>City Tax (3%)</span>
                <span>₾{revenueReport.taxes.CITY_TAX.toFixed(2)}</span>
              </div>
            )}
            {revenueReport.taxes.TOURISM_TAX > 0 && (
              <div className="flex justify-between">
                <span>Tourism Tax (1%)</span>
                <span>₾{revenueReport.taxes.TOURISM_TAX.toFixed(2)}</span>
              </div>
            )}
            {revenueReport.taxes.total === 0 && (
              <p className="text-gray-500 text-center py-2">No tax data for this date</p>
            )}
            {revenueReport.taxes.total > 0 && (
              <div className="border-t pt-2 font-bold flex justify-between">
                <span>Total Tax</span>
                <span>₾{revenueReport.taxes.total.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Outstanding Balances */}
      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-lg font-bold mb-4">Financial Position</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-red-50 p-4 rounded border border-red-200">
            <div className="text-sm text-gray-600 mb-1">Outstanding Balances</div>
            <div className="text-2xl font-bold text-red-600">
              ₾{managerReport.financial.outstandingBalances.toFixed(2)}
            </div>
          </div>
          <div className="bg-green-50 p-4 rounded border border-green-200">
            <div className="text-sm text-gray-600 mb-1">Cash Position</div>
            <div className="text-2xl font-bold text-green-600">
              ₾{managerReport.financial.cashPosition.toFixed(2)}
            </div>
          </div>
          <div className="bg-blue-50 p-4 rounded border border-blue-200">
            <div className="text-sm text-gray-600 mb-1">Credit Card Receipts</div>
            <div className="text-2xl font-bold text-blue-600">
              ₾{managerReport.financial.creditCardReceipts.toFixed(2)}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// KPI Card Component
const KPICard = ({ title, value, icon, color }: {
  title: string
  value: string
  icon: string
  color: 'green' | 'blue' | 'purple' | 'orange'
}) => {
  const colors = {
    green: 'bg-green-50 text-green-600 border-green-200',
    blue: 'bg-blue-50 text-blue-600 border-blue-200',
    purple: 'bg-purple-50 text-purple-600 border-purple-200',
    orange: 'bg-orange-50 text-orange-600 border-orange-200'
  }
  
  return (
    <div className={`rounded-lg p-6 border ${colors[color]}`}>
      <div className="text-3xl mb-2">{icon}</div>
      <div className="text-sm opacity-75 mb-1">{title}</div>
      <div className="text-2xl font-bold">{value}</div>
    </div>
  )
}

