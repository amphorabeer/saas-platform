import moment from 'moment'

export class FinancialReportsService {
  
  // Generate daily revenue report
  static async generateDailyRevenueReport(date: string) {
    if (typeof window === 'undefined') {
      return {
        date,
        revenue: { byCategory: {}, byDepartment: {}, total: 0 },
        taxes: { VAT: 0, CITY_TAX: 0, TOURISM_TAX: 0, total: 0 },
        payments: { methods: {}, total: 0, count: 0 },
        statistics: { transactionCount: 0, averageTransaction: 0 }
      }
    }
    
    const folios = JSON.parse(localStorage.getItem('hotelFolios') || '[]')
    
    // Get all transactions for the date
    const dayTransactions = folios.flatMap((f: any) => 
      f.transactions
        .filter((t: any) => t.date === date && t.type === 'charge')
        .map((t: any) => ({
          ...t,
          folioNumber: f.folioNumber,
          guestName: f.guestName,
          roomNumber: f.roomNumber
        }))
    )
    
    // Group by category
    const revenueByCategory = this.groupByCategory(dayTransactions)
    
    // Group by department
    const revenueByDepartment = this.groupByDepartment(dayTransactions)
    
    // Tax summary
    const taxSummary = this.calculateTaxSummary(dayTransactions)
    
    // Payment methods
    const paymentSummary = await this.getPaymentSummary(date)
    
    return {
      date,
      revenue: {
        byCategory: revenueByCategory,
        byDepartment: revenueByDepartment,
        total: Object.values(revenueByCategory).reduce((sum: any, val: any) => sum + val, 0)
      },
      taxes: taxSummary,
      payments: paymentSummary,
      statistics: {
        transactionCount: dayTransactions.length,
        averageTransaction: dayTransactions.length > 0 
          ? (Object.values(revenueByCategory).reduce((sum: any, val: any) => sum + val, 0) / dayTransactions.length)
          : 0
      }
    }
  }
  
  // Group revenue by category
  static groupByCategory(transactions: any[]) {
    const categories: Record<string, number> = {
      room: 0,
      food: 0,
      beverage: 0,
      spa: 0,
      laundry: 0,
      transport: 0,
      phone: 0,
      misc: 0
    }
    
    transactions.forEach(t => {
      const category = t.category || 'misc'
      categories[category] = (categories[category] || 0) + t.debit
    })
    
    return categories
  }
  
  // Group revenue by department
  static groupByDepartment(transactions: any[]) {
    const departments: Record<string, number> = {
      ROOMS: 0,
      'F&B': 0,
      SPA: 0,
      OTHER: 0
    }
    
    transactions.forEach(t => {
      if (['room', 'minibar'].includes(t.category)) {
        departments.ROOMS += t.debit
      } else if (['food', 'beverage', 'breakfast', 'lunch', 'dinner'].includes(t.category)) {
        departments['F&B'] += t.debit
      } else if (t.category === 'spa') {
        departments.SPA += t.debit
      } else {
        departments.OTHER += t.debit
      }
    })
    
    return departments
  }
  
  // Calculate tax summary
  static calculateTaxSummary(transactions: any[]) {
    const taxes = {
      VAT: 0,
      CITY_TAX: 0,
      TOURISM_TAX: 0,
      total: 0
    }
    
    transactions.forEach(t => {
      if (t.taxDetails) {
        t.taxDetails.forEach((tax: any) => {
          if (tax.taxType === 'VAT') {
            taxes.VAT += tax.amount
          } else if (tax.taxType === 'CITY_TAX') {
            taxes.CITY_TAX += tax.amount
          } else if (tax.taxType === 'TOURISM_TAX') {
            taxes.TOURISM_TAX += tax.amount
          }
          taxes.total += tax.amount
        })
      }
    })
    
    return taxes
  }
  
  // Get payment summary
  static async getPaymentSummary(date: string) {
    if (typeof window === 'undefined') {
      return { methods: {}, total: 0, count: 0 }
    }
    
    const folios = JSON.parse(localStorage.getItem('hotelFolios') || '[]')
    
    const payments = folios.flatMap((f: any) =>
      f.transactions
        .filter((t: any) => t.date === date && t.type === 'payment')
    )
    
    const paymentMethods: Record<string, number> = {
      cash: 0,
      card: 0,
      bank: 0,
      company: 0
    }
    
    payments.forEach((p: any) => {
      // Try to get payment method from description or default to cash
      const desc = (p.description || '').toLowerCase()
      let method = 'cash'
      
      if (desc.includes('card') || desc.includes('credit')) {
        method = 'card'
      } else if (desc.includes('bank') || desc.includes('transfer')) {
        method = 'bank'
      } else if (desc.includes('company')) {
        method = 'company'
      }
      
      paymentMethods[method] = (paymentMethods[method] || 0) + p.credit
    })
    
    return {
      methods: paymentMethods,
      total: Object.values(paymentMethods).reduce((sum: any, val: any) => sum + val, 0),
      count: payments.length
    }
  }
  
  // Generate manager report
  static async generateManagerReport(date: string) {
    const reservations = await fetch('/api/hotel/reservations').then(r => r.json())
    const rooms = await fetch('/api/hotel/rooms').then(r => r.json())
    
    if (typeof window === 'undefined') {
      return {
        date,
        occupancy: { rooms: { total: 0, occupied: 0, available: 0, percentage: 0 }, guests: { inHouse: 0, arrivals: 0, departures: 0 } },
        revenue: { byCategory: {}, byDepartment: {}, total: 0 },
        kpis: { adr: '0.00', revpar: '0.00', occupancyRate: '0%' },
        financial: { outstandingBalances: 0, cashPosition: 0, creditCardReceipts: 0 }
      }
    }
    
    const folios = JSON.parse(localStorage.getItem('hotelFolios') || '[]')
    
    // Occupancy statistics
    const occupiedRooms = reservations.filter((r: any) => {
      const checkIn = moment(r.checkIn)
      const checkOut = moment(r.checkOut)
      const targetDate = moment(date)
      return r.status === 'CHECKED_IN' && 
             checkIn.isSameOrBefore(targetDate, 'day') && 
             checkOut.isAfter(targetDate, 'day')
    }).length
    
    const occupancy = rooms.length > 0 ? (occupiedRooms / rooms.length) * 100 : 0
    
    // Revenue statistics
    const revenueReport = await this.generateDailyRevenueReport(date)
    
    // ADR (Average Daily Rate)
    const adr = occupiedRooms > 0 
      ? (revenueReport.revenue.byCategory.room || 0) / occupiedRooms 
      : 0
    
    // RevPAR (Revenue Per Available Room)
    const revpar = rooms.length > 0
      ? (revenueReport.revenue.byCategory.room || 0) / rooms.length
      : 0
    
    // Outstanding balances
    const outstandingBalances = folios
      .filter((f: any) => f.status === 'open' && f.balance > 0)
      .reduce((sum: number, f: any) => sum + f.balance, 0)
    
    return {
      date,
      occupancy: {
        rooms: {
          total: rooms.length,
          occupied: occupiedRooms,
          available: rooms.length - occupiedRooms,
          percentage: occupancy
        },
        guests: {
          inHouse: reservations.filter((r: any) => r.status === 'CHECKED_IN').length,
          arrivals: reservations.filter((r: any) => 
            moment(r.checkIn).format('YYYY-MM-DD') === date
          ).length,
          departures: reservations.filter((r: any) => 
            moment(r.checkOut).format('YYYY-MM-DD') === date
          ).length
        }
      },
      revenue: revenueReport.revenue,
      kpis: {
        adr: adr.toFixed(2),
        revpar: revpar.toFixed(2),
        occupancyRate: occupancy.toFixed(1) + '%'
      },
      financial: {
        outstandingBalances,
        cashPosition: revenueReport.payments.methods.cash || 0,
        creditCardReceipts: revenueReport.payments.methods.card || 0
      }
    }
  }
}

