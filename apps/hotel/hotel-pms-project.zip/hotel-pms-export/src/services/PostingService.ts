import moment from 'moment'
import { Folio, FolioTransaction, TaxBreakdown } from '../types/folio.types'

export class PostingService {
  
  // Post room charges for all in-house guests
  static async postRoomCharges(auditDate: string) {
    const results = {
      posted: 0,
      failed: 0,
      skipped: 0,
      totalAmount: 0,
      details: [] as any[]
    }
    
    try {
      // Get all reservations
      const reservations = await fetch('/api/hotel/reservations').then(r => r.json())
      
      // Filter in-house guests for audit date
      const inHouseGuests = reservations.filter((res: any) => {
        const checkIn = moment(res.checkIn)
        const checkOut = moment(res.checkOut)
        const audit = moment(auditDate)
        
        return res.status === 'CHECKED_IN' && 
               checkIn.isSameOrBefore(audit, 'day') && 
               checkOut.isAfter(audit, 'day')
      })
      
      // Post charge for each guest
      for (const reservation of inHouseGuests) {
        const postResult = await this.postRoomChargeForReservation(reservation, auditDate)
        
        if (postResult.success) {
          results.posted++
          results.totalAmount += postResult.amount
        } else if (postResult.skipped) {
          results.skipped++
        } else {
          results.failed++
        }
        
        results.details.push(postResult)
      }
      
    } catch (error) {
      console.error('Room charge posting error:', error)
    }
    
    return results
  }
  
  // Post room charge for single reservation
  static async postRoomChargeForReservation(reservation: any, auditDate: string) {
    try {
      // Check if already posted for this date
      const folios = typeof window !== 'undefined' 
        ? JSON.parse(localStorage.getItem('hotelFolios') || '[]')
        : []
      let folio = folios.find((f: any) => f.reservationId === reservation.id)
      
      // Create folio if doesn't exist
      if (!folio) {
        folio = await this.createFolio(reservation)
        folios.push(folio)
      }
      
      // Check for duplicate posting (check both nightAuditDate and referenceId)
      const existingCharge = folio.transactions.find((t: any) => 
        (t.nightAuditDate === auditDate && t.category === 'room' && t.type === 'charge') ||
        t.referenceId === `ROOM-${reservation.id}-${auditDate}`
      )
      
      if (existingCharge) {
        return {
          success: false,
          skipped: true,
          message: 'Room charge already posted for this date',
          reservation: reservation.id,
          room: reservation.roomNumber || reservation.roomId,
          guest: reservation.guestName
        }
      }
      
      // Calculate room charge
      const rateBreakdown = this.calculateRoomRate(reservation, auditDate)
      
      // Recalculate balance from existing transactions
      const currentBalance = folio.transactions.reduce((balance, trx) => {
        return balance + (trx.debit || 0) - (trx.credit || 0)
      }, 0)
      
      const newBalance = currentBalance + rateBreakdown.total
      
      // Create room charge transaction
      const roomCharge: FolioTransaction = {
        id: `RC-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        folioId: folio.id,
        date: auditDate,
        time: moment().format('HH:mm:ss'),
        
        type: 'charge',
        category: 'room',
        description: `Room Charge - ${reservation.roomNumber || reservation.roomId}`,
        
        debit: rateBreakdown.total,
        credit: 0,
        balance: newBalance,
        
        postedBy: 'Night Audit',
        postedAt: moment().format(),
        nightAuditDate: auditDate,
        
        taxDetails: rateBreakdown.taxes,
        
        referenceId: `ROOM-${reservation.id}-${auditDate}`
      }
      
      // Update folio
      folio.balance = newBalance
      folio.transactions.push(roomCharge)
      
      // Save updated folio
      const folioIndex = folios.findIndex((f: any) => f.id === folio.id)
      if (folioIndex >= 0) {
        folios[folioIndex] = folio
      } else {
        folios.push(folio)
      }
      
      if (typeof window !== 'undefined') {
        localStorage.setItem('hotelFolios', JSON.stringify(folios))
      }
      
      return {
        success: true,
        amount: rateBreakdown.total,
        reservation: reservation.id,
        room: reservation.roomNumber || reservation.roomId,
        guest: reservation.guestName,
        breakdown: rateBreakdown
      }
      
    } catch (error: any) {
      return {
        success: false,
        error: error.message,
        reservation: reservation.id,
        room: reservation.roomNumber || reservation.roomId,
        guest: reservation.guestName
      }
    }
  }
  
  // Calculate room rate with taxes
  static calculateRoomRate(reservation: any, date: string) {
    // Get base rate
    const checkIn = moment(reservation.checkIn)
    const checkOut = moment(reservation.checkOut)
    const nights = checkOut.diff(checkIn, 'days')
    const totalAmount = reservation.totalAmount || 0
    const baseRatePerNight = nights > 0 ? totalAmount / nights : totalAmount
    
    // Check for special rates (weekend, seasonal, etc.)
    const dayOfWeek = moment(date).day()
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6
    
    let adjustedRate = baseRatePerNight
    
    // Weekend surcharge
    if (isWeekend && reservation.weekendSurcharge !== false) {
      adjustedRate *= 1.1 // 10% weekend surcharge
    }
    
    // Apply discounts if any
    let discount = 0
    if (reservation.discountPercent) {
      discount = adjustedRate * (reservation.discountPercent / 100)
    }
    if (reservation.discountAmount) {
      discount = Math.max(discount, reservation.discountAmount / nights)
    }
    
    const netRate = adjustedRate - discount
    
    // Calculate taxes
    const taxes = this.calculateTaxes(netRate)
    
    // Total with taxes
    const total = netRate + taxes.totalTax
    
    return {
      baseRate: baseRatePerNight,
      adjustedRate: adjustedRate,
      discount: discount,
      netRate: netRate,
      taxes: taxes.breakdown,
      totalTax: taxes.totalTax,
      total: total
    }
  }
  
  // Calculate taxes
  static calculateTaxes(amount: number) {
    // Load tax rates from settings, fallback to defaults
    let taxRates = {
      VAT: 18,          // 18% VAT
      CITY_TAX: 3,      // 3% City tax
      TOURISM_TAX: 1    // 1% Tourism tax
    }
    
    if (typeof window !== 'undefined') {
      const savedTaxes = localStorage.getItem('taxSettings')
      if (savedTaxes) {
        try {
          const settings = JSON.parse(savedTaxes)
          taxRates = {
            VAT: settings.VAT || taxRates.VAT,
            CITY_TAX: settings.CITY_TAX || taxRates.CITY_TAX,
            TOURISM_TAX: settings.TOURISM_TAX || taxRates.TOURISM_TAX
          }
        } catch (e) {
          console.error('Error loading tax settings:', e)
        }
      }
    }
    
    const breakdown: TaxBreakdown[] = []
    let totalTax = 0
    
    // Calculate each tax
    for (const [taxType, rate] of Object.entries(taxRates)) {
      const taxAmount = amount * (rate / 100)
      totalTax += taxAmount
      
      breakdown.push({
        taxType: taxType as any,
        rate: rate,
        base: amount,
        amount: taxAmount
      })
    }
    
    return {
      breakdown,
      totalTax
    }
  }
  
  // Create new folio
  static async createFolio(reservation: any): Promise<Folio> {
    return {
      id: `FOLIO-${Date.now()}`,
      folioNumber: `F${moment().format('YYMMDD')}-${reservation.roomNumber || reservation.roomId || Math.floor(Math.random() * 1000)}`,
      reservationId: reservation.id,
      guestName: reservation.guestName,
      roomNumber: reservation.roomNumber || reservation.roomId,
      
      balance: 0,
      creditLimit: 5000,
      paymentMethod: 'cash',
      
      status: 'open',
      openDate: moment().format('YYYY-MM-DD'),
      
      transactions: []
    }
  }
}

