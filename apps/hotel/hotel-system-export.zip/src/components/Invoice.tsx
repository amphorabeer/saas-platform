'use client'

import moment from 'moment'
import { ActivityLogger } from '../lib/activityLogger'

export default function Invoice({ reservation, hotelInfo, onPrint, onEmail }: any) {
  const nights = moment(reservation.checkOut).diff(moment(reservation.checkIn), 'days')
  const pricePerNight = nights > 0 ? reservation.totalAmount / nights : reservation.totalAmount
  
  const generateInvoiceHTML = () => {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Invoice #${reservation.reservationNumber || reservation.id}</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; }
          .invoice-header { border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-start; }
          .logo { max-width: 150px; }
          .company-info { text-align: right; }
          .invoice-details { margin: 20px 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
          th { background: #f5f5f5; font-weight: bold; }
          .total { font-size: 1.2em; font-weight: bold; }
          .footer { margin-top: 40px; border-top: 1px solid #ddd; padding-top: 20px; }
        </style>
      </head>
      <body>
        <div class="invoice-header">
          ${hotelInfo?.logo ? `<img src="${hotelInfo.logo}" class="logo" alt="Logo">` : '<div></div>'}
          <div class="company-info">
            <h2>${hotelInfo?.name || 'Hotel Tbilisi'}</h2>
            ${hotelInfo?.companyName ? `<p>${hotelInfo.companyName}</p>` : ''}
            ${hotelInfo?.taxId ? `<p>ს/კ: ${hotelInfo.taxId}</p>` : ''}
            ${hotelInfo?.address ? `<p>${hotelInfo.address}</p>` : ''}
            ${hotelInfo?.phone ? `<p>${hotelInfo.phone}</p>` : ''}
            ${hotelInfo?.email ? `<p>${hotelInfo.email}</p>` : ''}
          </div>
        </div>
        
        <h2>ინვოისი #${reservation.reservationNumber || reservation.id}</h2>
        <div class="invoice-details">
          <p><strong>თარიღი:</strong> ${moment().format('DD/MM/YYYY')}</p>
          <p><strong>სტუმარი:</strong> ${reservation.guestName}</p>
          ${reservation.guestPhone ? `<p><strong>ტელეფონი:</strong> ${reservation.guestPhone}</p>` : ''}
          ${reservation.guestEmail ? `<p><strong>ელ-ფოსტა:</strong> ${reservation.guestEmail}</p>` : ''}
        </div>
        
        <table>
          <thead>
            <tr>
              <th>აღწერა</th>
              <th>Check In</th>
              <th>Check Out</th>
              <th>ღამეები</th>
              <th>ფასი/ღამე</th>
              <th>სულ</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>ოთახი ${reservation.roomNumber || 'N/A'}</td>
              <td>${moment(reservation.checkIn).format('DD/MM/YYYY')}</td>
              <td>${moment(reservation.checkOut).format('DD/MM/YYYY')}</td>
              <td>${nights}</td>
              <td>₾${pricePerNight.toFixed(2)}</td>
              <td>₾${reservation.totalAmount}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="5" class="total">სულ გადასახდელი:</td>
              <td class="total">₾${reservation.totalAmount}</td>
            </tr>
            <tr>
              <td colspan="5">გადახდილი:</td>
              <td>₾${reservation.isPaid ? reservation.totalAmount : 0}</td>
            </tr>
            ${reservation.isPaid ? '' : `<tr><td colspan="5">დარჩენილი:</td><td>₾${reservation.totalAmount}</td></tr>`}
          </tfoot>
        </table>
        
        ${hotelInfo?.bankName || hotelInfo?.bankAccount ? `
        <div class="footer">
          <p><strong>საბანკო რეკვიზიტები:</strong></p>
          ${hotelInfo.bankName ? `<p>ბანკი: ${hotelInfo.bankName}</p>` : ''}
          ${hotelInfo.bankAccount ? `<p>ანგარიში: ${hotelInfo.bankAccount}</p>` : ''}
        </div>
        ` : ''}
      </body>
      </html>
    `
  }
  
  const handlePrint = () => {
    const printWindow = window.open('', '', 'height=800,width=600')
    if (printWindow) {
      printWindow.document.write(generateInvoiceHTML())
      printWindow.document.close()
      printWindow.print()
    }
    
    ActivityLogger.log('INVOICE_PRINTED', {
      reservation: reservation.reservationNumber || reservation.id,
      guest: reservation.guestName
    })
    
    if (onPrint) onPrint()
  }
  
  const handleEmail = () => {
    const subject = `Invoice #${reservation.reservationNumber || reservation.id}`
    const body = `Dear ${reservation.guestName},\n\nPlease find attached your invoice.\n\nBest regards,\n${hotelInfo?.name || 'Hotel'}`
    
    // For demo - opens email client
    if (reservation.guestEmail) {
      window.location.href = `mailto:${reservation.guestEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    } else {
      alert('❌ სტუმრის email არ არის მითითებული')
      return
    }
    
    // In production, you'd send via API
    ActivityLogger.log('INVOICE_SENT', {
      reservation: reservation.reservationNumber || reservation.id,
      email: reservation.guestEmail
    })
    
    alert('📧 ინვოისი გაგზავნილია email-ზე')
    if (onEmail) onEmail()
  }
  
  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button
          onClick={handlePrint}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          🖨️ დაბეჭდვა
        </button>
        <button
          onClick={handleEmail}
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          disabled={!reservation.guestEmail}
        >
          📧 Email-ით გაგზავნა
        </button>
      </div>
    </div>
  )
}

