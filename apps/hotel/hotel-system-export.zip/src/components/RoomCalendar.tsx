'use client'

import { useState, useMemo, useRef, useEffect } from 'react'
import moment from 'moment'
import PaymentModal from './PaymentModal'
import EditReservationModal from './EditReservationModal'
import Invoice from './Invoice'
import { ActivityLogger } from '../lib/activityLogger'

interface RoomCalendarProps {
  rooms: any[]
  reservations: any[]
  onSlotClick?: (roomId: string, date: Date, room: any) => void
  onReservationUpdate?: (id: string, updates: any) => Promise<void>
  onReservationDelete?: (id: string) => Promise<void>
  loadReservations?: () => void
}

export default function RoomCalendar({ 
  rooms, 
  reservations, 
  onSlotClick,
  onReservationUpdate,
  onReservationDelete,
  loadReservations
}: RoomCalendarProps) {
  // Start with current date (November 2025)
  const [currentDate, setCurrentDate] = useState(() => {
    // Use actual current date
    return new Date()
  })
  const [view, setView] = useState<'week' | 'month'>('week')
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; items?: Array<{ label: string; action: () => void }> } | null>(null)
  const [selectedReservation, setSelectedReservation] = useState<any>(null)
  const [showDetails, setShowDetails] = useState(false)
  const [showPayment, setShowPayment] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [viewOnlyReservation, setViewOnlyReservation] = useState<any>(null)
  const [showViewOnlyModal, setShowViewOnlyModal] = useState(false)
  const [blockedDates, setBlockedDates] = useState<any>({})
  const [maintenanceRooms, setMaintenanceRooms] = useState<string[]>([])
  const menuRef = useRef<HTMLDivElement>(null)
  
  // Load blocked dates from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('blockedDates')
    if (saved) {
      try {
        setBlockedDates(JSON.parse(saved))
      } catch (e) {
        console.error('Failed to load blocked dates:', e)
      }
    }
  }, [])
  
  // Load maintenance rooms from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('maintenanceRooms')
    if (saved) {
      try {
        setMaintenanceRooms(JSON.parse(saved))
      } catch (e) {
        console.error('Failed to load maintenance rooms:', e)
      }
    }
  }, [])
  
  // Get business day (last closed audit + 1)
  const getBusinessDay = () => {
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (!lastAuditDate) {
      // No audit yet - allow booking from today
      return moment().format('YYYY-MM-DD')
    }
    
    try {
      const lastClosed = JSON.parse(lastAuditDate)
      const businessDay = moment(lastClosed).add(1, 'day')
      return businessDay.format('YYYY-MM-DD')
    } catch {
      // If parsing fails, use today
      return moment().format('YYYY-MM-DD')
    }
  }
  
  // Check if date can be booked
  const canBookOnDate = (date: Date | string) => {
    const dateStr = typeof date === 'string' ? date : moment(date).format('YYYY-MM-DD')
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (!lastAuditDate) {
      // No audit yet - can book from today
      return moment(dateStr).isSameOrAfter(TODAY, 'day')
    }
    
    try {
      // Parse last audit date
      const lastClosed = JSON.parse(lastAuditDate) // "2025-11-01"
      const businessDay = moment(lastClosed).add(1, 'day') // Nov 2
      
      // Can book from business day onwards
      // Nov 2 to Nov 26 and beyond should be bookable
      return moment(dateStr).isSameOrAfter(businessDay, 'day')
    } catch {
      // If parsing fails, allow from today
      return moment(dateStr).isSameOrAfter(TODAY, 'day')
    }
  }
  
  // Alias for backward compatibility
  const isDateBookable = canBookOnDate
  
  // Get current actual date (November 26, 2025)
  const TODAY = moment('2025-11-26') // System current date
  
  // Get today's date without time
  const today = useMemo(() => {
    const date = new Date()
    date.setHours(0, 0, 0, 0)
    return date
  }, [])
  
  // Generate dates for view
  const dates = useMemo(() => {
    const result: Date[] = []
    const startDate = new Date(currentDate)
    
    if (view === 'week') {
      // Get start of week (Monday)
      const day = startDate.getDay()
      const diff = startDate.getDate() - day + (day === 0 ? -6 : 1)
      startDate.setDate(diff)
      
      for (let i = 0; i < 7; i++) {
        const date = new Date(startDate)
        date.setDate(startDate.getDate() + i)
        result.push(date)
      }
    } else {
      // Month view - show 30 days
      for (let i = 0; i < 30; i++) {
        const date = new Date(startDate)
        date.setDate(startDate.getDate() + i)
        result.push(date)
      }
    }
    
    return result
  }, [currentDate, view])
  
  // Check if room is available on specific date
  const isRoomAvailable = (roomId: string, date: Date): boolean => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    
    // Check if any reservation exists for this room on this date
    const hasReservation = reservations.some(res => {
      const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
      const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
      
      return res.roomId === roomId && 
             dateStr >= checkIn && 
             dateStr < checkOut &&
             res.status !== 'CANCELLED'
    })
    
    return !hasReservation
  }
  
  // Check if date is valid for new reservation
  const isValidReservationDate = (date: Date): boolean => {
    // Use business day logic instead of "today"
    // If date is bookable (after business day), it's valid
    return canBookOnDate(date)
  }
  
  // Check if date is a closed day (before or on last audit date)
  const isClosedDay = (date: Date | string): boolean => {
    const dateStr = typeof date === 'string' ? date : moment(date).format('YYYY-MM-DD')
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    if (!lastAuditDate) return false
    
    try {
      const lastClosed = JSON.parse(lastAuditDate)
      // Only dates on or before last audit are closed
      return moment(dateStr).isSameOrBefore(lastClosed, 'day')
    } catch {
      return false
    }
  }
  
  // Check if room is in maintenance
  const isRoomInMaintenance = (roomId: string) => {
    return maintenanceRooms.includes(roomId)
  }
  
  // Visual indication for closed days
  const getCellStyle = (room: any, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${room.id}_${dateStr}`
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        
        // Days before and including last audit are closed
        if (moment(dateStr).isSameOrBefore(lastClosed, 'day')) {
          return 'bg-gray-100 cursor-not-allowed opacity-50'
        }
      } catch {
        // If parsing fails, continue
      }
    }
    
    // If room is in maintenance - all dates red
    if (room.status === 'MAINTENANCE') {
      return 'bg-red-100 cursor-not-allowed'
    }
    
    // If specific date is blocked
    if (blockedDates[key]) {
      return 'bg-red-100 cursor-not-allowed'
    }
    
    // Check for reservation
    const reservation = getReservation(room.id, date)
    if (reservation) {
      return getStatusColor(reservation.status)
    }
    
    // Future dates or business days
    return 'bg-white hover:bg-blue-50 cursor-pointer'
  }
  
  // Get cell className for background cells
  const getCellClassName = (date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        
        // Days before and including last audit are closed
        if (moment(dateStr).isSameOrBefore(lastClosed, 'day')) {
          return 'bg-gray-100 cursor-not-allowed opacity-50'
        }
      } catch {
        // If parsing fails, continue
      }
    }
    
    // Future dates or business days
    return 'hover:bg-blue-50 cursor-pointer'
  }
  
  // Handle empty slot click
  const handleSlotClick = (roomId: string, date: Date) => {
    console.log('Clicking on date:', date) // Debug log
    
    const room = rooms.find(r => r.id === roomId)
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    let canBook = true
    let blockReason = ''
    
    // Check if date is after business day
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate) // "2025-11-01"
        
        // Can't book on or before last closed date
        if (moment(dateStr).isSameOrBefore(lastClosed, 'day')) {
          canBook = false
          blockReason = `დახურული დღე (Night Audit: ${moment(lastClosed).format('DD/MM/YYYY')})`
        }
        // Nov 2 and later should be bookable
      } catch (error) {
        console.error('Error parsing lastAuditDate:', error)
      }
    }
    
    // Check for existing reservation
    const hasReservation = reservations.some((r: any) => 
      r.roomId === roomId && 
      moment(dateStr).isBetween(moment(r.checkIn), moment(r.checkOut), 'day', '[)') &&
      r.status !== 'CANCELLED'
    )
    
    if (hasReservation) {
      canBook = false
      blockReason = 'უკვე დაკავებულია'
    }
    
    console.log('Can book:', canBook, 'Reason:', blockReason) // Debug
    
    if (!canBook) {
      if (blockReason) {
        alert(`❌ ${blockReason}`)
      }
      return
    }
    
    // Prevent booking if maintenance or blocked
    if (isRoomInMaintenance(roomId)) {
      alert('❌ ეს ოთახი რემონტშია და დაბლოკილია!')
      return
    }
    
    if (room?.status === 'MAINTENANCE') {
      alert('❌ ეს ოთახი რემონტშია და დაბლოკილია!')
      return
    }
    
    if (blockedDates[key]) {
      alert('❌ ეს თარიღი დაბლოკილია!')
      return
    }
    
    // Validation
    if (!isValidReservationDate(date)) {
      alert('❌ ვერ შექმნით ჯავშანს ამ თარიღზე!')
      return
    }
    
    if (!isRoomAvailable(roomId, date)) {
      alert('❌ ოთახი დაკავებულია ამ თარიღზე!')
      return
    }
    
    // Date is valid - open modal
    console.log('Opening modal for:', dateStr) // Debug
    
    // Make sure onSlotClick is called
    if (onSlotClick) {
      onSlotClick(roomId, date, room)
    } else {
      console.error('onSlotClick function not provided!')
    }
  }
  
  // Close context menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setContextMenu(null)
      }
    }
    
    const handleEscKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setContextMenu(null)
      }
    }
    
    if (contextMenu) {
      document.addEventListener('mousedown', handleClickOutside)
      document.addEventListener('keydown', handleEscKey)
      return () => {
        document.removeEventListener('mousedown', handleClickOutside)
        document.removeEventListener('keydown', handleEscKey)
      }
    }
  }, [contextMenu])
  
  // Get reservation for room/date
  const getReservation = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    
    return reservations.find(res => {
      const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
      const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
      
      return res.roomId === roomId && 
             dateStr >= checkIn && 
             dateStr < checkOut
    })
  }
  
  // Block/unblock functions
  const blockDate = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    const newBlocked = { ...blockedDates, [key]: true }
    setBlockedDates(newBlocked)
    localStorage.setItem('blockedDates', JSON.stringify(newBlocked))
    setContextMenu(null)
  }
  
  const unblockDate = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    const newBlocked = { ...blockedDates }
    delete newBlocked[key]
    setBlockedDates(newBlocked)
    localStorage.setItem('blockedDates', JSON.stringify(newBlocked))
    setContextMenu(null)
  }
  
  // Handle right-click on reservation
  const handleRightClick = (e: React.MouseEvent, reservation: any) => {
    e.preventDefault()
    e.stopPropagation()
    setSelectedReservation(reservation)
    
    // Adjust position if menu would go off screen
    let x = e.clientX
    let y = e.clientY
    
    if (typeof window !== 'undefined') {
      if (x + 200 > window.innerWidth) {
        x = window.innerWidth - 220
      }
      if (y + 300 > window.innerHeight) {
        y = window.innerHeight - 320
      }
    }
    
    setContextMenu({ x, y })
  }
  
  // Handle right-click on empty cell
  const handleEmptyCellRightClick = (e: React.MouseEvent, roomId: string, date: Date) => {
    e.preventDefault()
    e.stopPropagation()
    
    const dateStr = moment(date).format('YYYY-MM-DD')
    const key = `${roomId}_${dateStr}`
    const isBlocked = blockedDates[key]
    
    const menu = [
      {
        label: isBlocked ? '✅ განბლოკვა' : '🚫 დაბლოკვა',
        action: () => isBlocked ? unblockDate(roomId, date) : blockDate(roomId, date)
      }
    ]
    
    // Adjust position if menu would go off screen
    let x = e.clientX
    let y = e.clientY
    
    if (typeof window !== 'undefined') {
      if (x + 200 > window.innerWidth) {
        x = window.innerWidth - 220
      }
      if (y + 100 > window.innerHeight) {
        y = window.innerHeight - 120
      }
    }
    
    setContextMenu({ x, y, items: menu })
  }
  
  // Handle double-click on reservation
  const handleDoubleClick = (reservation: any) => {
    setSelectedReservation(reservation)
    setShowDetails(true)
  }
  
  // Context menu actions
  const handleCheckIn = async () => {
    if (!selectedReservation || !onReservationUpdate) return
    
    const now = new Date()
    const checkInDate = new Date(selectedReservation.checkIn)
    
    // Check-in rules
    if (now < checkInDate) {
      if (!confirm('⚠️ Check-in თარიღი ჯერ არ დამდგარა. გსურთ ადრე Check-in?')) {
        return
      }
    }
    
    try {
      await onReservationUpdate(selectedReservation.id, {
        status: 'CHECKED_IN',
        actualCheckIn: now.toISOString()
      })
      
      // Update room status to OCCUPIED
      await fetch('/api/hotel/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: selectedReservation.roomId,
          status: 'OCCUPIED'
        })
      })
      
      ActivityLogger.log('CHECK_IN', {
        guest: selectedReservation.guestName,
        room: selectedReservation.roomNumber,
        reservationId: selectedReservation.id
      })
      
      alert('✅ Check-in წარმატებით დასრულდა!')
    } catch (error) {
      console.error('Failed to check in:', error)
      alert('შეცდომა Check-in-ისას')
    }
    
    setContextMenu(null)
    setSelectedReservation(null)
  }
  
  const handleCheckOut = async () => {
    if (!selectedReservation || !onReservationUpdate) return
    
    const now = new Date()
    const checkOutDate = new Date(selectedReservation.checkOut)
    
    // Check-out validation
    if (now < checkOutDate) {
      if (!confirm('Check-out თარიღი ჯერ არ დამდგარა. გსურთ ადრე Check-out?')) {
        return
      }
    }
    
    // Check if payment is completed
    if (!selectedReservation.isPaid && selectedReservation.totalAmount > 0) {
      alert('⚠️ გადახდა არ არის დასრულებული. გთხოვთ ჯერ გადაიხადოთ.')
      setShowPayment(true)
      setContextMenu(null)
      return
    }
    
    try {
      // Update reservation status to CHECKED_OUT
      await onReservationUpdate(selectedReservation.id, {
        status: 'CHECKED_OUT',
        actualCheckOut: now.toISOString()
      })
      
      // Update room status to CLEANING (not VACANT!)
      await fetch('/api/hotel/rooms/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId: selectedReservation.roomId,
          status: 'CLEANING' // Important: CLEANING, not VACANT
        })
      })
      
      // Auto-create housekeeping task
      const savedTasks = localStorage.getItem('housekeepingTasks')
      const existingTasks = savedTasks ? JSON.parse(savedTasks) : []
      
      const housekeepingTask = {
        id: `task-${Date.now()}`,
        roomId: selectedReservation.roomId,
        roomNumber: selectedReservation.roomNumber,
        floor: rooms.find((r: any) => r.id === selectedReservation.roomId)?.floor || 1,
        type: 'checkout',
        status: 'pending',
        priority: 'high',
        assignedTo: '',
        scheduledTime: moment().format('HH:mm'),
        notes: `Check-out cleaning after ${selectedReservation.guestName}`,
        checklist: [
          { item: 'ზეწრების შეცვლა', completed: false },
          { item: 'პირსახოცების შეცვლა', completed: false },
          { item: 'აბაზანის დასუფთავება', completed: false },
          { item: 'იატაკის დალაგება', completed: false },
          { item: 'მინიბარის შემოწმება', completed: false },
          { item: 'ნაგვის გატანა', completed: false },
          { item: 'ზედაპირების დასუფთავება', completed: false }
        ]
      }
      
      localStorage.setItem('housekeepingTasks', JSON.stringify([...existingTasks, housekeepingTask]))
      
      alert('✅ Check-out დასრულდა!')
      setContextMenu(null)
      
      // Don't reload page, just update data
      if (loadReservations) {
        loadReservations()
      }
    } catch (error) {
      console.error('Failed to check out:', error)
      alert('შეცდომა Check-out-ისას')
      setContextMenu(null)
      setSelectedReservation(null)
    }
  }
  
  const handleCancel = async () => {
    if (!selectedReservation) return
    
    if (!confirm('ნამდვილად გსურთ ჯავშნის გაუქმება?')) return
    
    // Delete reservation completely
    if (onReservationDelete) {
      try {
        await onReservationDelete(selectedReservation.id)
        
        ActivityLogger.log('RESERVATION_CANCEL', {
          guest: selectedReservation.guestName,
          room: selectedReservation.roomNumber,
          reservationId: selectedReservation.id
        })
        
        alert('❌ ჯავშანი წაიშალა')
        if (loadReservations) {
          loadReservations()
        }
      } catch (error) {
        console.error('Failed to delete reservation:', error)
        alert('შეცდომა ჯავშნის წაშლისას')
      }
    } else {
      // Fallback to update status if delete not available
      if (onReservationUpdate) {
        try {
          await onReservationUpdate(selectedReservation.id, {
            status: 'CANCELLED',
            cancelledAt: new Date().toISOString()
          })
          
          // Update room status to VACANT
          await fetch('/api/hotel/rooms', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              roomId: selectedReservation.roomId,
              status: 'VACANT'
            })
          })
          
          alert('❌ ჯავშანი გაუქმებულია')
          if (loadReservations) {
            loadReservations()
          }
        } catch (error) {
          console.error('Failed to cancel reservation:', error)
          alert('შეცდომა ჯავშნის გაუქმებისას')
        }
      }
    }
    
    setContextMenu(null)
    setSelectedReservation(null)
  }
  
  // Get status color
  const getStatusColor = (status: string) => {
    switch(status) {
      case 'CONFIRMED': return 'bg-green-500'
      case 'CHECKED_IN': return 'bg-blue-500'
      case 'CHECKED_OUT': return 'bg-gray-400'
      case 'CANCELLED': return 'bg-red-400 opacity-50'
      case 'PENDING': return 'bg-yellow-500'
      default: return 'bg-gray-500'
    }
  }
  
  // Check if date is in the past
  // Check if date is in the past relative to business day, not actual today
  const isPastDate = (date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        const businessDay = moment(lastClosed).add(1, 'day')
        // Only dates before business day are considered "past" for booking purposes
        return moment(dateStr).isBefore(businessDay, 'day')
      } catch {
        // If parsing fails, compare with fixed TODAY
        return moment(dateStr).isBefore(TODAY, 'day')
      }
    }
    
    // If no audit, compare with fixed TODAY
    return moment(dateStr).isBefore(TODAY, 'day')
  }
  
  // Get reservations for room and date
  const getReservationsForRoomAndDate = (roomId: string, date: Date) => {
    const dateStr = moment(date).format('YYYY-MM-DD')
    return reservations.filter(res => {
      const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
      const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
      return res.roomId === roomId && 
             dateStr >= checkIn && 
             dateStr < checkOut &&
             res.status !== 'CANCELLED'
    })
  }
  
  // Render reservation as continuous bar
  const renderReservationBar = (reservation: any, room: any, dateStrings: string[]) => {
    const checkIn = moment(reservation.checkIn)
    const checkOut = moment(reservation.checkOut)
    const firstDate = moment(dateStrings[0])
    const lastDate = moment(dateStrings[dateStrings.length - 1])
    
    // Skip if reservation is outside visible dates
    if (checkOut.isBefore(firstDate, 'day') || checkIn.isAfter(lastDate, 'day')) {
      return null
    }
    
    // Calculate start and end positions
    const startIndex = Math.max(0, checkIn.diff(firstDate, 'days'))
    const endIndex = Math.min(dateStrings.length - 1, checkOut.diff(firstDate, 'days') - 1)
    const spanLength = endIndex - startIndex + 1
    
    if (spanLength <= 0) return null
    
    // Status colors
    const statusColors: any = {
      'CONFIRMED': 'bg-blue-500',
      'CHECKED_IN': 'bg-green-500',
      'CHECKED_OUT': 'bg-gray-400',
      'CANCELLED': 'bg-red-300 opacity-50'
    }
    
    const nights = checkOut.diff(checkIn, 'days')
    
    return (
      <div
        key={reservation.id}
        className={`absolute ${statusColors[reservation.status] || 'bg-blue-500'} text-white 
                    rounded-lg px-2 py-1 text-xs font-medium
                    hover:shadow-lg transition-shadow cursor-pointer z-10
                    flex items-center justify-center`}
        style={{
          left: `${(startIndex * 100) / dateStrings.length}%`,
          width: `${(spanLength * 100) / dateStrings.length}%`,
          top: '50%',
          transform: 'translateY(-50%)',
          minWidth: '60px'
        }}
        onClick={(e) => {
          e.stopPropagation()
          setSelectedReservation(reservation)
          setShowDetails(true)
        }}
        onContextMenu={(e) => {
          e.preventDefault()
          e.stopPropagation()
          handleRightClick(e, reservation)
        }}
        onDoubleClick={(e) => {
          e.stopPropagation()
          handleDoubleClick(reservation)
        }}
        title={`${reservation.guestName} - ${nights} ღამე`}
      >
        <div className="truncate text-center">
          {reservation.guestName}
          {spanLength > 1 && (
            <span className="ml-1 opacity-75">({nights}დღე)</span>
          )}
        </div>
      </div>
    )
  }
  
  // Handle reservation click
  const handleReservationClick = (reservation: any) => {
    // Check if reservation date is in closed period
    const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
    
    if (lastAuditDate) {
      try {
        const lastClosed = JSON.parse(lastAuditDate)
        
        // If check-in or any day of reservation is on/before closed date
        if (moment(reservation.checkIn).isSameOrBefore(lastClosed, 'day')) {
          // Show details only - no editing
          setViewOnlyReservation(reservation)
          setShowViewOnlyModal(true)
          return
        }
      } catch (error) {
        console.error('Error parsing lastAuditDate:', error)
      }
    }
    
    // Normal edit for future reservations
    setSelectedReservation(reservation)
    setShowDetails(true)
  }
  
  // Check if room should be OCCUPIED today
  const getRoomCurrentStatus = (room: any) => {
    // If room is in maintenance (from localStorage), return MAINTENANCE
    if (isRoomInMaintenance(room.id)) {
      return 'MAINTENANCE'
    }
    
    // If room status is MAINTENANCE, return MAINTENANCE
    if (room.status === 'MAINTENANCE') {
      return 'MAINTENANCE'
    }
    
    const todayStr = moment().format('YYYY-MM-DD')
    
    // Check if any CHECKED_IN reservation exists for today
    const hasCheckedInGuest = reservations.some(res => {
      const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
      const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
      
      return res.roomId === room.id && 
             res.status === 'CHECKED_IN' &&
             todayStr >= checkIn && 
             todayStr < checkOut
    })
    
    if (hasCheckedInGuest) return 'OCCUPIED'
    
    // Check if room is in cleaning
    if (room.status === 'CLEANING') return 'CLEANING'
    
    // Otherwise vacant
    return 'VACANT'
  }
  
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      {/* Header with controls */}
      <div className="bg-gray-50 border-b p-4 flex justify-between items-center">
        <div className="flex gap-2">
          <button 
            onClick={() => {
              const newDate = new Date(currentDate)
              newDate.setDate(currentDate.getDate() - (view === 'week' ? 7 : 30))
              setCurrentDate(newDate)
            }}
            className="px-3 py-1 border rounded hover:bg-white transition"
          >
            ← წინა
          </button>
          <button 
            onClick={() => setCurrentDate(new Date())}
            className="px-3 py-1 border rounded bg-blue-500 text-white hover:bg-blue-600 transition"
          >
            დღეს
          </button>
          <button 
            onClick={() => {
              const newDate = new Date(currentDate)
              newDate.setDate(currentDate.getDate() + (view === 'week' ? 7 : 30))
              setCurrentDate(newDate)
            }}
            className="px-3 py-1 border rounded hover:bg-white transition"
          >
            შემდეგი →
          </button>
        </div>
        
        <h2 className="text-lg font-bold text-gray-800">
          {moment(currentDate).format('MMMM YYYY')}
        </h2>
        
        <div className="flex gap-2">
          <button
            onClick={() => setView('week')}
            className={`px-3 py-1 border rounded transition ${
              view === 'week' 
                ? 'bg-blue-500 text-white border-blue-500' 
                : 'hover:bg-white'
            }`}
          >
            კვირა
          </button>
          <button
            onClick={() => setView('month')}
            className={`px-3 py-1 border rounded transition ${
              view === 'month' 
                ? 'bg-blue-500 text-white border-blue-500' 
                : 'hover:bg-white'
            }`}
          >
            თვე
          </button>
        </div>
      </div>
      
      {/* Business Day Indicator */}
      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-2 mb-2">
        <div className="flex items-center">
          <span className="text-sm text-yellow-700">
            📅 Business Day: {moment(getBusinessDay()).format('DD/MM/YYYY')}
            {typeof window !== 'undefined' && localStorage.getItem('lastAuditDate') && (() => {
              try {
                const lastClosed = JSON.parse(localStorage.getItem('lastAuditDate') || '')
                return (
                  <span className="ml-2 text-xs">
                    (ბოლო დახურვა: {moment(lastClosed).format('DD/MM/YYYY')})
                  </span>
                )
              } catch {
                return null
              }
            })()}
          </span>
        </div>
      </div>
      
      {/* Instructions */}
      <div className="bg-blue-50 p-2 text-sm text-center border-b">
        💡 დააკლიკეთ ცარიელ უჯრას ახალი ჯავშნისთვის | მარჯვენა კლიკი = მენიუ | ორმაგი კლიკი = დეტალები
      </div>
      
      {/* Calendar Grid */}
      <div 
        className="overflow-auto room-calendar-grid" 
        style={{ 
          maxHeight: 'calc(100vh - 350px)',
          minHeight: '400px'
        }}
      >
        <table className="w-full border-collapse">
          <thead className="sticky top-0 z-20 bg-white">
            <tr>
              <th className="border bg-gray-100 p-2 text-left sticky left-0 z-30 min-w-[120px] sticky-room-header">
                ოთახები
              </th>
              {dates.map((date, i) => {
                const isToday = moment(date).format('YYYY-MM-DD') === moment(today).format('YYYY-MM-DD')
                const isPast = isPastDate(date)
                
                return (
                  <th 
                    key={i} 
                    className={`border p-2 min-w-[100px] text-center ${
                      isToday ? 'bg-blue-100' : 
                      isPast ? 'bg-gray-100' : 
                      'bg-gray-50'
                    }`}
                  >
                    <div className="text-xs text-gray-500">
                      {moment(date).format('ddd')}
                    </div>
                    <div className={`font-bold ${isToday ? 'text-blue-600' : ''}`}>
                      {moment(date).format('DD')}
                    </div>
                  </th>
                )
              })}
            </tr>
          </thead>
          <tbody>
            {rooms.map((room) => {
              const dateStrings = dates.map(d => moment(d).format('YYYY-MM-DD'))
              const roomReservations = reservations.filter((res: any) => 
                res.roomId === room.id && res.status !== 'CANCELLED'
              )
              
              return (
                <tr key={room.id} className="hover:bg-gray-50 transition h-16">
                  <td className="border-r border-gray-200 bg-gray-50 p-3 sticky left-0 z-10 font-medium sticky-room-header" style={{ minWidth: '150px' }}>
                    <div>
                      <div className="font-medium">{room.roomNumber}</div>
                      <div className="text-xs text-gray-500">{room.roomType || 'Standard'}</div>
                      {(() => {
                        const displayStatus = getRoomCurrentStatus(room)
                        return (
                          <div className={`text-xs mt-1 px-1 py-0.5 rounded inline-block ${
                            displayStatus === 'OCCUPIED' ? 'bg-red-100 text-red-800' :
                            displayStatus === 'VACANT' ? 'bg-green-100 text-green-800' :
                            displayStatus === 'CLEANING' ? 'bg-yellow-100 text-yellow-800' :
                            displayStatus === 'MAINTENANCE' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {displayStatus}
                          </div>
                        )
                      })()}
                    </div>
                  </td>
                  
                  {/* Single cell for entire period with reservation bars */}
                  <td colSpan={dates.length} className="relative h-16 border-b border-r">
                    {/* Background cells for clicking */}
                    <div className="absolute inset-0 flex">
                      {dates.map((date, idx) => {
                        const isPast = isPastDate(date)
                        const dateStr = moment(date).format('YYYY-MM-DD')
                        const blockedKey = `${room.id}_${dateStr}`
                        const isBlocked = blockedDates[blockedKey] || isRoomInMaintenance(room.id) || room.status === 'MAINTENANCE'
                        const hasReservation = getReservationsForRoomAndDate(room.id, date).length > 0
                        const isClosed = !canBookOnDate(date)
                        
                        return (
                          <div
                            key={idx}
                            className={`flex-1 border-r border-gray-200 ${
                              isClosed
                                ? 'bg-gray-100 cursor-not-allowed opacity-50'
                                : isBlocked 
                                ? 'bg-red-100 cursor-not-allowed' 
                                : hasReservation
                                ? 'cursor-pointer'
                                : getCellClassName(date)
                            }`}
                            onClick={(e) => {
                              e.stopPropagation()
                              const dateStr = moment(date).format('YYYY-MM-DD')
                              console.log('Cell clicked:', dateStr) // Debug
                              
                              // Check if date is closed (before or on last audit)
                              const isClosed = isClosedDay(date)
                              
                              if (canBookOnDate(date) && !isClosed) {
                                const hasReservation = getReservationsForRoomAndDate(room.id, date).length > 0
                                if (!hasReservation && !isBlocked) {
                                  console.log('Calling handleSlotClick for:', dateStr) // Debug
                                  handleSlotClick(room.id, date)
                                } else {
                                  console.log('Click blocked:', { hasReservation, isBlocked, isClosed }) // Debug
                                }
                              } else {
                                console.log('Date not bookable or closed:', dateStr, { canBook: canBookOnDate(date), isClosed }) // Debug
                              }
                            }}
                            onContextMenu={(e) => {
                              const isClosed = isClosedDay(date)
                              if (!isClosed && !hasReservation && canBookOnDate(date)) {
                                handleEmptyCellRightClick(e, room.id, date)
                              }
                            }}
                          >
                            {/* Show blocked indicator */}
                            {isBlocked && !hasReservation && !isClosed && (
                              <div className="h-full flex items-center justify-center">
                                <span className="text-red-500 text-xs font-bold">BLOCKED</span>
                              </div>
                            )}
                            {/* Show closed indicator */}
                            {isClosed && !hasReservation && (
                              <div className="h-full flex items-center justify-center">
                                <span className="text-gray-400 text-xs">დახურული</span>
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                    
                    {/* Render continuous reservation bars */}
                    {roomReservations.map((res: any) => renderReservationBar(res, room, dateStrings))}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      
      {/* Context Menu */}
      {contextMenu && (
        <div
          ref={menuRef}
          className="fixed bg-white rounded-lg shadow-xl border border-gray-200 py-1 z-50 min-w-[200px]"
          style={{ left: contextMenu.x, top: contextMenu.y }}
        >
          {contextMenu.items ? (
            // Empty cell context menu (block/unblock)
            contextMenu.items.map((item, idx) => (
              <button
                key={idx}
                onClick={item.action}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm transition"
              >
                <span>{item.label}</span>
              </button>
            ))
          ) : selectedReservation ? (
            // Reservation context menu
            <>
              <div className="px-3 py-2 border-b border-gray-200">
                <div className="font-semibold text-sm">{selectedReservation?.guestName}</div>
                <div className="text-xs text-gray-500">Room {selectedReservation?.roomNumber}</div>
                <div className="text-xs text-gray-400 mt-1">
                  {selectedReservation?.status === 'CONFIRMED' && '📅 დადასტურებული'}
                  {selectedReservation?.status === 'CHECKED_IN' && '✅ Check In გაკეთებულია'}
                  {selectedReservation?.status === 'CHECKED_OUT' && '🚪 Check Out გაკეთებულია'}
                  {selectedReservation?.status === 'CANCELLED' && '❌ გაუქმებული'}
                </div>
              </div>
              
              <button
                onClick={() => {
                  setShowDetails(true)
                  setContextMenu(null)
                }}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm transition"
              >
                <span>👁️</span> ნახვა დეტალები
              </button>
              
              <button 
                onClick={() => {
                  setShowEditModal(true)
                  setContextMenu(null)
                }}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm transition"
              >
                <span>✏️</span> რედაქტირება
              </button>
              
              {selectedReservation?.status === 'CONFIRMED' && (
                <button
                  onClick={handleCheckIn}
                  className="w-full px-3 py-2 text-left hover:bg-green-50 flex items-center gap-2 text-sm text-green-600 transition"
                >
                  <span>✅</span> Check In
                </button>
              )}
              
              {selectedReservation?.status === 'CHECKED_IN' && (
                <button
                  onClick={handleCheckOut}
                  className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-center gap-2 text-sm text-blue-600 transition"
                >
                  <span>🚪</span> Check Out
                </button>
              )}
              
              <button
                onClick={() => {
                  setShowPayment(true)
                  setContextMenu(null)
                }}
                className="w-full px-3 py-2 text-left hover:bg-gray-100 flex items-center gap-2 text-sm transition"
              >
                <span>💳</span> გადახდა
              </button>
              
              <div className="border-t border-gray-200 my-1"></div>
              
              {selectedReservation?.status !== 'CHECKED_OUT' && selectedReservation?.status !== 'CANCELLED' && (
                <button
                  onClick={handleCancel}
                  className="w-full px-3 py-2 text-left hover:bg-red-50 flex items-center gap-2 text-sm text-red-600 transition"
                >
                  <span>❌</span> გაუქმება
                </button>
              )}
            </>
          ) : null}
        </div>
      )}
      
      {/* View Only Modal for Closed Day Reservations */}
      {showViewOnlyModal && viewOnlyReservation && (
        <ViewOnlyReservationModal
          reservation={viewOnlyReservation}
          onClose={() => {
            setShowViewOnlyModal(false)
            setViewOnlyReservation(null)
          }}
        />
      )}
      
      {/* Reservation Details Modal */}
      {showDetails && selectedReservation && (
        <ReservationDetails
          reservation={selectedReservation}
          onClose={() => {
            setShowDetails(false)
            setSelectedReservation(null)
          }}
          onPayment={() => {
            setShowDetails(false)
            setShowPayment(true)
          }}
        />
      )}
      
      {/* Payment Modal */}
      {showPayment && selectedReservation && (
        <PaymentModal
          reservation={selectedReservation}
          onClose={() => {
            setShowPayment(false)
            setSelectedReservation(null)
          }}
          onPayment={async (payment: any) => {
            if (onReservationUpdate) {
              await onReservationUpdate(selectedReservation.id, {
                isPaid: payment.isPaid,
                paidAmount: payment.paidAmount,
                remainingAmount: payment.remainingAmount,
                paymentMethod: payment.payments?.map((p: any) => p.method).join(', ') || payment.method,
                payments: payment.payments || [],
                paidAt: new Date().toISOString()
              })
            }
            setShowPayment(false)
            setSelectedReservation(null)
            if (loadReservations) {
              loadReservations()
            }
          }}
        />
      )}
      
      {/* Edit Modal */}
      {showEditModal && selectedReservation && (
        <EditReservationModal
          reservation={selectedReservation}
          rooms={rooms}
          onClose={() => {
            setShowEditModal(false)
            setSelectedReservation(null)
          }}
          onSave={async (updates: any) => {
            if (onReservationUpdate) {
              await onReservationUpdate(selectedReservation.id, {
                ...updates,
                checkIn: new Date(updates.checkIn).toISOString(),
                checkOut: new Date(updates.checkOut).toISOString()
              })
            }
            setShowEditModal(false)
            setSelectedReservation(null)
            if (loadReservations) {
              loadReservations()
            }
          }}
          onDelete={async (id: string) => {
            if (onReservationDelete) {
              await onReservationDelete(id)
            }
            setShowEditModal(false)
            setSelectedReservation(null)
            if (loadReservations) {
              loadReservations()
            }
          }}
        />
      )}
    </div>
  )
}

// Reservation Details Modal
// View Only Modal Component for Closed Day Reservations
function ViewOnlyReservationModal({ reservation, onClose }: any) {
  if (!reservation) return null
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">📋 ჯავშნის დეტალები (მხოლოდ ნახვა)</h2>
          <button onClick={onClose} className="text-2xl hover:text-gray-600">×</button>
        </div>
        
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-3 mb-4">
          <p className="text-sm text-yellow-700">
            ⚠️ დახურული პერიოდის ჯავშანი - რედაქტირება შეუზღუდულია
          </p>
        </div>
        
        <div className="space-y-3">
          <div>
            <label className="text-sm text-gray-600">სტუმარი:</label>
            <div className="font-medium">{reservation.guestName}</div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-gray-600">Check In:</label>
              <div>{moment(reservation.checkIn).format('DD/MM/YYYY')}</div>
            </div>
            <div>
              <label className="text-sm text-gray-600">Check Out:</label>
              <div>{moment(reservation.checkOut).format('DD/MM/YYYY')}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-gray-600">ოთახი:</label>
              <div>{reservation.roomNumber || reservation.roomId || 'N/A'}</div>
            </div>
            <div>
              <label className="text-sm text-gray-600">სტატუსი:</label>
              <div>{reservation.status}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm text-gray-600">თანხა:</label>
              <div>₾{reservation.totalAmount || 0}</div>
            </div>
            <div>
              <label className="text-sm text-gray-600">გადახდა:</label>
              <div>
                {reservation.isPaid === true || reservation.paymentStatus === 'PAID' || (reservation.paidAmount || 0) >= (reservation.totalAmount || 0) 
                  ? '✅ გადახდილი' 
                  : '❌ გადაუხდელი'}
              </div>
            </div>
          </div>
        </div>
        
        <button 
          onClick={onClose}
          className="w-full mt-6 px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition"
        >
          დახურვა
        </button>
      </div>
    </div>
  )
}

function ReservationDetails({ reservation, onClose, onPayment }: any) {
  const [hotelInfo, setHotelInfo] = useState<any>({
    name: 'Hotel Tbilisi',
    companyName: '',
    taxId: '',
    bankName: '',
    bankAccount: '',
    address: 'თბილისი, საქართველო',
    phone: '+995 322 123456',
    email: 'info@hotel.ge',
    logo: ''
  })
  
  useEffect(() => {
    const saved = localStorage.getItem('hotelInfo')
    if (saved) {
      try {
        setHotelInfo(JSON.parse(saved))
      } catch (e) {
        console.error('Failed to load hotel info:', e)
      }
    }
  }, [])
  const nights = moment(reservation.checkOut).diff(moment(reservation.checkIn), 'days')
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">ჯავშნის დეტალები</h2>
          <button onClick={onClose} className="text-2xl text-gray-500 hover:text-gray-700">×</button>
        </div>
        
        {reservation.reservationNumber && (
          <div className="mb-4 p-3 bg-blue-50 rounded">
            <p className="text-sm text-gray-600">რეზერვაციის ნომერი:</p>
            <p className="text-lg font-bold text-blue-700">#{reservation.reservationNumber}</p>
          </div>
        )}
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <h3 className="font-semibold mb-2 text-gray-800">სტუმრის ინფორმაცია</h3>
            <div className="space-y-1 text-sm">
              <p><span className="text-gray-500">სახელი:</span> <span className="font-medium">{reservation.guestName}</span></p>
              <p><span className="text-gray-500">Email:</span> {reservation.guestEmail || 'N/A'}</p>
              <p><span className="text-gray-500">ტელეფონი:</span> {reservation.guestPhone || 'N/A'}</p>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-2 text-gray-800">ჯავშნის ინფორმაცია</h3>
            <div className="space-y-1 text-sm">
              <p><span className="text-gray-500">ოთახი:</span> <span className="font-medium">Room {reservation.roomNumber}</span></p>
              <p><span className="text-gray-500">Check In:</span> {moment(reservation.checkIn).format('DD/MM/YYYY')}</p>
              <p><span className="text-gray-500">Check Out:</span> {moment(reservation.checkOut).format('DD/MM/YYYY')}</p>
              <p><span className="text-gray-500">ღამეები:</span> {nights} ღამე</p>
              <p><span className="text-gray-500">სტატუსი:</span> 
                <span className={`ml-2 px-2 py-1 rounded text-xs text-white ${
                  reservation.status === 'CONFIRMED' ? 'bg-green-500' :
                  reservation.status === 'CHECKED_IN' ? 'bg-blue-500' :
                  reservation.status === 'CHECKED_OUT' ? 'bg-gray-500' :
                  'bg-red-500'
                }`}>
                  {reservation.status}
                </span>
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t pt-4">
          <h3 className="font-semibold mb-2 text-gray-800">Folio / გადახდები</h3>
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-2 text-left">თარიღი</th>
                <th className="p-2 text-left">აღწერა</th>
                <th className="p-2 text-right">თანხა</th>
                <th className="p-2 text-center">სტატუსი</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t">
                <td className="p-2">{moment(reservation.checkIn).format('DD/MM')}</td>
                <td className="p-2">ოთახის ღირებულება ({nights} ღამე)</td>
                <td className="p-2 text-right font-medium">₾{reservation.totalAmount || 0}</td>
                <td className="p-2 text-center">
                  {reservation.isPaid ? (
                    <span className="text-green-600 font-semibold">✓ გადახდილი</span>
                  ) : (
                    <span className="text-orange-500">მოლოდინში</span>
                  )}
                </td>
              </tr>
            </tbody>
            <tfoot className="border-t font-bold bg-gray-50">
              <tr>
                <td colSpan={2} className="p-2">სულ:</td>
                <td className="p-2 text-right">₾{reservation.totalAmount || 0}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
        
        <div className="border-t pt-4 mt-4">
          <h3 className="font-bold mb-2">ინვოისი</h3>
          <Invoice 
            reservation={reservation}
            hotelInfo={hotelInfo}
          />
        </div>
        
        <div className="flex justify-end gap-2 mt-6">
          <button onClick={onClose} className="px-4 py-2 border rounded hover:bg-gray-50 transition">
            დახურვა
          </button>
          {!reservation.isPaid && (
            <button 
              onClick={onPayment}
              className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition"
            >
              💳 გადახდა
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

