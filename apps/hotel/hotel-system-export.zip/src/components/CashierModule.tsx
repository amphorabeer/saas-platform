'use client'

import { useState, useEffect } from 'react'
import moment from 'moment'

interface CashierShift {
  id: string
  userId: string
  userName: string
  openingBalance: number
  cashCollected: number
  cardPayments: number
  chequePayments: number
  totalCollected: number
  expectedAmount: number
  discrepancy: number
  discrepancyReason?: string
  openedAt: string
  closedAt?: string
  status: 'open' | 'closed'
  withdrawal?: number
  nextDayOpening?: number
}

export default function CashierModule() {
  const [currentShift, setCurrentShift] = useState<CashierShift | null>(null)
  const [shifts, setShifts] = useState<CashierShift[]>([])
  const [showCloseModal, setShowCloseModal] = useState(false)
  
  // Load current shift
  useEffect(() => {
    const savedShift = localStorage.getItem('currentCashierShift')
    if (savedShift) {
      setCurrentShift(JSON.parse(savedShift))
    }
    
    const allShifts = JSON.parse(localStorage.getItem('cashierShifts') || '[]')
    setShifts(allShifts)
  }, [])
  
  // Open new shift
  const openShift = (openingBalance: number) => {
    const user = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem('currentUser') || '{}') : {}
    
    const newShift: CashierShift = {
      id: Date.now().toString(),
      userId: user.id || 'unknown',
      userName: user.name || 'Unknown User',
      openingBalance,
      cashCollected: 0,
      cardPayments: 0,
      chequePayments: 0,
      totalCollected: 0,
      expectedAmount: openingBalance,
      discrepancy: 0,
      openedAt: new Date().toISOString(),
      status: 'open'
    }
    
    setCurrentShift(newShift)
    localStorage.setItem('currentCashierShift', JSON.stringify(newShift))
  }
  
  // Record payment
  const recordPayment = (type: 'cash' | 'card' | 'cheque', amount: number) => {
    if (!currentShift) return
    
    const updated = { ...currentShift }
    
    switch(type) {
      case 'cash':
        updated.cashCollected += amount
        break
      case 'card':
        updated.cardPayments += amount
        break
      case 'cheque':
        updated.chequePayments += amount
        break
    }
    
    updated.totalCollected = updated.cashCollected + updated.cardPayments + updated.chequePayments
    updated.expectedAmount = updated.openingBalance + updated.totalCollected
    
    setCurrentShift(updated)
    localStorage.setItem('currentCashierShift', JSON.stringify(updated))
  }
  
  // Close shift modal
  const CloseShiftModal = () => {
    const [actualCash, setActualCash] = useState(0)
    const [nextDayOpening, setNextDayOpening] = useState(0)
    const [discrepancyReason, setDiscrepancyReason] = useState('')
    
    const handleClose = () => {
      if (!currentShift) return
      
      const discrepancy = actualCash - (currentShift.openingBalance + currentShift.cashCollected)
      
      if (discrepancy !== 0 && !discrepancyReason) {
        alert('გთხოვთ მიუთითოთ სხვაობის მიზეზი')
        return
      }
      
      // Calculate withdrawal
      const withdrawal = actualCash - nextDayOpening
      
      // Close shift
      const closedShift = {
        ...currentShift,
        closedAt: new Date().toISOString(),
        status: 'closed' as const,
        discrepancy,
        discrepancyReason,
        withdrawal,
        nextDayOpening
      }
      
      // Save to history
      const allShifts = JSON.parse(localStorage.getItem('cashierShifts') || '[]')
      allShifts.push(closedShift)
      localStorage.setItem('cashierShifts', JSON.stringify(allShifts))
      
      // Clear current
      localStorage.removeItem('currentCashierShift')
      setCurrentShift(null)
      setShowCloseModal(false)
      
      alert(`✅ სალარო დახურულია\n\nგასატანი: ₾${withdrawal}\nშემდეგი დღის ბალანსი: ₾${nextDayOpening}`)
    }
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-6 max-w-md w-full">
          <h2 className="text-xl font-bold mb-4">💰 სალაროს დახურვა</h2>
          
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>გახსნის ბალანსი:</div>
                <div className="font-bold">₾{currentShift?.openingBalance}</div>
                
                <div>ნაღდი შემოსავალი:</div>
                <div className="font-bold">₾{currentShift?.cashCollected}</div>
                
                <div>ბარათით:</div>
                <div className="font-bold">₾{currentShift?.cardPayments}</div>
                
                <div className="border-t pt-2">მოსალოდნელი ნაღდი:</div>
                <div className="border-t pt-2 font-bold">
                  ₾{(currentShift?.openingBalance || 0) + (currentShift?.cashCollected || 0)}
                </div>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">ფაქტიური ნაღდი ფული</label>
              <input
                type="number"
                value={actualCash}
                onChange={(e) => setActualCash(Number(e.target.value))}
                className="w-full border rounded px-3 py-2"
                placeholder="დათვალეთ და შეიყვანეთ"
              />
            </div>
            
            {actualCash > 0 && actualCash !== ((currentShift?.openingBalance || 0) + (currentShift?.cashCollected || 0)) && (
              <div className="bg-red-50 p-3 rounded">
                <div className="text-red-600 font-bold">
                  სხვაობა: ₾{actualCash - ((currentShift?.openingBalance || 0) + (currentShift?.cashCollected || 0))}
                </div>
                <input
                  type="text"
                  value={discrepancyReason}
                  onChange={(e) => setDiscrepancyReason(e.target.value)}
                  className="w-full border rounded px-3 py-2 mt-2"
                  placeholder="მიუთითეთ სხვაობის მიზეზი..."
                  required
                />
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium mb-1">დატოვეთ შემდეგი დღისთვის</label>
              <input
                type="number"
                value={nextDayOpening}
                onChange={(e) => setNextDayOpening(Number(e.target.value))}
                className="w-full border rounded px-3 py-2"
                placeholder="რამდენი დარჩეს სალაროში"
              />
            </div>
            
            {actualCash > 0 && nextDayOpening >= 0 && (
              <div className="bg-blue-50 p-3 rounded">
                <div className="text-blue-700">
                  გასატანი თანხა: <span className="font-bold">₾{actualCash - nextDayOpening}</span>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex gap-2 mt-6">
            <button
              onClick={handleClose}
              disabled={!actualCash}
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:bg-gray-400"
            >
              დახურვა და განაღდება
            </button>
            <button
              onClick={() => setShowCloseModal(false)}
              className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
            >
              გაუქმება
            </button>
          </div>
        </div>
      </div>
    )
  }
  
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-bold mb-4">💳 სალაროს მართვა</h3>
      
      {currentShift ? (
        <div>
          <div className="bg-green-50 border-l-4 border-green-400 p-4 mb-4">
            <p className="font-bold">სალარო ღიაა</p>
            <p className="text-sm">მოლარე: {currentShift.userName}</p>
            <p className="text-sm">გახსნის დრო: {moment(currentShift.openedAt).format('HH:mm')}</p>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-2xl font-bold">₾{currentShift.cashCollected}</div>
              <div className="text-sm text-gray-600">ნაღდი</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-2xl font-bold">₾{currentShift.cardPayments}</div>
              <div className="text-sm text-gray-600">ბარათი</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded">
              <div className="text-2xl font-bold">₾{currentShift.totalCollected}</div>
              <div className="text-sm text-gray-600">სულ</div>
            </div>
          </div>
          
          <button
            onClick={() => setShowCloseModal(true)}
            className="w-full px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            სალაროს დახურვა
          </button>
        </div>
      ) : (
        <div>
          <p className="text-gray-600 mb-4">სალარო დახურულია</p>
          <OpenShiftForm onOpen={openShift} />
        </div>
      )}
      
      {showCloseModal && <CloseShiftModal />}
    </div>
  )
}

// Helper component
const OpenShiftForm = ({ onOpen }: { onOpen: (balance: number) => void }) => {
  const [openingBalance, setOpeningBalance] = useState(0)
  
  return (
    <div className="space-y-4">
      <input
        type="number"
        value={openingBalance}
        onChange={(e) => setOpeningBalance(Number(e.target.value))}
        className="w-full border rounded px-3 py-2"
        placeholder="გახსნის ბალანსი (₾)"
      />
      <button
        onClick={() => onOpen(openingBalance)}
        className="w-full px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
      >
        სალაროს გახსნა
      </button>
    </div>
  )
}

