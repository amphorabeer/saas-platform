'use client'

import { useState } from 'react'
import moment from 'moment'

interface EditReservationModalProps {
  reservation: any
  rooms: any[]
  onClose: () => void
  onSave: (updates: any) => void
  onDelete: (id: string) => void
}

export default function EditReservationModal({ 
  reservation, 
  rooms,
  onClose, 
  onSave,
  onDelete 
}: EditReservationModalProps) {
  const [formData, setFormData] = useState({
    guestName: reservation.guestName,
    guestEmail: reservation.guestEmail || '',
    guestPhone: reservation.guestPhone || '',
    roomId: reservation.roomId,
    checkIn: moment(reservation.checkIn).format('YYYY-MM-DD'),
    checkOut: moment(reservation.checkOut).format('YYYY-MM-DD'),
    adults: reservation.adults || 1,
    children: reservation.children || 0,
    totalAmount: reservation.totalAmount,
    notes: reservation.notes || '',
    status: reservation.status
  })
  
  const handleDelete = () => {
    if (confirm('ნამდვილად გსურთ ჯავშნის წაშლა?')) {
      onDelete(reservation.id)
      onClose()
    }
  }
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
        <h2 className="text-xl font-bold mb-4">ჯავშნის რედაქტირება</h2>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium mb-1">სტუმარის სახელი</label>
            <input
              type="text"
              className="w-full border rounded px-3 py-2"
              value={formData.guestName}
              onChange={(e) => setFormData({...formData, guestName: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">ოთახი</label>
            <select
              className="w-full border rounded px-3 py-2"
              value={formData.roomId}
              onChange={(e) => setFormData({...formData, roomId: e.target.value})}
            >
              {rooms.map(room => (
                <option key={room.id} value={room.id}>
                  Room {room.roomNumber} - {room.roomType}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Check In</label>
            <input
              type="date"
              className="w-full border rounded px-3 py-2"
              value={formData.checkIn}
              onChange={(e) => setFormData({...formData, checkIn: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Check Out</label>
            <input
              type="date"
              className="w-full border rounded px-3 py-2"
              value={formData.checkOut}
              onChange={(e) => setFormData({...formData, checkOut: e.target.value})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">თანხა (₾)</label>
            <input
              type="number"
              className="w-full border rounded px-3 py-2"
              value={formData.totalAmount}
              onChange={(e) => setFormData({...formData, totalAmount: parseInt(e.target.value)})}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">სტატუსი</label>
            <select
              className="w-full border rounded px-3 py-2"
              value={formData.status}
              onChange={(e) => setFormData({...formData, status: e.target.value})}
            >
              <option value="CONFIRMED">დადასტურებული</option>
              <option value="CHECKED_IN">Check In</option>
              <option value="CHECKED_OUT">Check Out</option>
              <option value="CANCELLED">გაუქმებული</option>
            </select>
          </div>
        </div>
        
        <div className="flex justify-between mt-6">
          <button
            onClick={handleDelete}
            className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          >
            🗑️ წაშლა
          </button>
          
          <div className="flex gap-3">
            <button onClick={onClose} className="px-4 py-2 border rounded hover:bg-gray-50">
              გაუქმება
            </button>
            <button 
              onClick={() => onSave(formData)}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              შენახვა
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
