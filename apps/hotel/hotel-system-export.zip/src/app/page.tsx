'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { DndProvider } from 'react-dnd'
import { HTML5Backend } from 'react-dnd-html5-backend'
import moment from 'moment'
import CalendarView from '../components/CalendarView'
import ResourceCalendar from '../components/ResourceCalendar'
import EnhancedCalendar from '../components/EnhancedCalendar'
import RoomCalendar from '../components/RoomCalendar'
import RoomGridView from '../components/RoomGridView'
import HousekeepingView from '../components/HousekeepingView'
import SettingsModal from '../components/SettingsModal'
import CheckInModal from '../components/CheckInModal'
import PaymentModal from '../components/PaymentModal'
import Reports from '../components/Reports'
import NightAuditView from '../components/NightAuditView'
import SystemLockOverlay from '../components/SystemLockOverlay'
import ReservationsView from '../components/ReservationsView'
import { SystemLockService } from '../lib/systemLockService'
import { ActivityLogger } from '../lib/activityLogger'

interface Room {
  id: string
  roomNumber: string
  floor: number
  status: string
  basePrice: number
  roomType?: string
}

interface Reservation {
  id: string
  guestName: string
  guestEmail: string
  roomId: string
  checkIn: string
  checkOut: string
  status: string
  totalAmount: number
  roomNumber?: string
}

export default function HotelDashboard() {
  const router = useRouter()
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [activeTabs, setActiveTabs] = useState<string[]>(['calendar']) // Always have calendar
  const [activeTab, setActiveTab] = useState('calendar')
  const [showQuickMenu, setShowQuickMenu] = useState(false)
  const [rooms, setRooms] = useState<Room[]>([])
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)
  const [maintenanceRooms, setMaintenanceRooms] = useState<string[]>([])
  
  // Auth check
  useEffect(() => {
    const user = localStorage.getItem('currentUser')
    if (!user) {
      router.push('/login')
    } else {
      try {
        setCurrentUser(JSON.parse(user))
        // Login is already logged in login page
      } catch (e) {
        console.error('Failed to parse user:', e)
        router.push('/login')
      }
    }
  }, [router])
  
  // Role-based permissions
  const canEdit = currentUser?.role === 'admin' || currentUser?.role === 'manager'
  const canViewReports = currentUser?.role !== 'receptionist'
  const canCloseDay = currentUser?.role === 'admin'
  
  const handleLogout = () => {
    ActivityLogger.log('LOGOUT', { username: currentUser?.username })
    localStorage.removeItem('currentUser')
    router.push('/login')
  }

  // Load maintenance rooms from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('maintenanceRooms')
    if (saved) {
      try {
        setMaintenanceRooms(JSON.parse(saved))
      } catch (e) {
        console.error('Error loading maintenance rooms:', e)
      }
    }
  }, [])
  const [initialCheckInDate, setInitialCheckInDate] = useState<string | undefined>(undefined)
  const [showCheckInModal, setShowCheckInModal] = useState(false)
  const [showSettingsModal, setShowSettingsModal] = useState(false)
  const [showPaymentModal, setShowPaymentModal] = useState(false)
  const [selectedReservation, setSelectedReservation] = useState<any>(null)
  
  // Add tab from dropdown
  const addTabFromMenu = (tabId: string) => {
    if (!activeTabs.includes(tabId)) {
      setActiveTabs([...activeTabs, tabId])
    }
    setActiveTab(tabId)
    setShowQuickMenu(false)
  }
  
  // Close tab
  const closeTab = (tabId: string) => {
    if (tabId === 'calendar') return // Can't close calendar
    
    const newTabs = activeTabs.filter(t => t !== tabId)
    setActiveTabs(newTabs)
    
    // Switch to calendar if closing active tab
    if (activeTab === tabId) {
      setActiveTab('calendar')
    }
  }
  
  const getTabLabel = (tabId: string) => {
    switch(tabId) {
      case 'calendar': return '📅 კალენდარი'
      case 'rooms': return '🏨 ნომრები'
      case 'reservations': return '📋 ჯავშნები'
      case 'housekeeping': return '🧹 დასუფთავება'
      case 'roomgrid': return '🏨 ოთახები'
      case 'reports': return '📊 რეპორტები'
      case 'nightaudit': return '🌙 დღის დახურვა'
      default: return ''
    }
  }
  
  // Statistics
  const stats = {
    total: rooms.length,
    occupied: rooms.filter(r => r.status === 'OCCUPIED').length,
    vacant: rooms.filter(r => r.status === 'VACANT').length,
    cleaning: rooms.filter(r => r.status === 'CLEANING').length,
    occupancyRate: rooms.length > 0 
      ? Math.round((rooms.filter(r => r.status === 'OCCUPIED').length / rooms.length) * 100)
      : 0
  }

  useEffect(() => {
    loadRooms()
    loadReservations()
    // Auto-refresh every 30 seconds
    const interval = setInterval(() => {
      loadRooms()
      loadReservations()
    }, 30000)
    return () => clearInterval(interval)
  }, [])
  
  // Close quick menu on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (showQuickMenu) {
        setShowQuickMenu(false)
      }
    }
    if (showQuickMenu) {
      document.addEventListener('click', handleClickOutside)
      return () => document.removeEventListener('click', handleClickOutside)
    }
  }, [showQuickMenu])
  
  // Update room statuses when reservations change
  useEffect(() => {
    if (reservations.length > 0 && rooms.length > 0) {
      updateRoomStatuses()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reservations.length])
  

  async function loadRooms() {
    try {
      const res = await fetch('/api/hotel/rooms')
      if (res.ok) {
        const data = await res.json()
        setRooms(data)
      }
    } catch (error) {
      console.error('Failed to load rooms:', error)
    }
  }

  async function loadReservations() {
    try {
      const res = await fetch('/api/hotel/reservations')
      if (res.ok) {
        const data = await res.json()
        setReservations(data)
        // Update room statuses after loading reservations
        updateRoomStatuses(data)
      }
    } catch (error) {
      console.error('Failed to load reservations:', error)
    }
  }
  
  // Update room statuses based on current reservations
  async function updateRoomStatuses(reservationsData?: any[]) {
    const reservationsToCheck = reservationsData || reservations
    const today = moment().format('YYYY-MM-DD')
    
    const updatePromises = rooms.map(async (room) => {
      // Check if room has active guest TODAY
      const activeReservation = reservationsToCheck.find((res: any) => {
        const checkIn = moment(res.checkIn).format('YYYY-MM-DD')
        const checkOut = moment(res.checkOut).format('YYYY-MM-DD')
        
        return res.roomId === room.id && 
               res.status === 'CHECKED_IN' &&
               today >= checkIn && 
               today < checkOut
      })
      
      let newStatus = 'VACANT'
      
      if (activeReservation) {
        newStatus = 'OCCUPIED'
      } else if (room.status === 'CLEANING') {
        newStatus = 'CLEANING'
      }
      
      // Update if different
      if (room.status !== newStatus) {
        try {
          await fetch('/api/hotel/rooms/status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              roomId: room.id,
              status: newStatus
            })
          })
        } catch (error) {
          console.error('Failed to update room status:', error)
        }
      }
    })
    
    await Promise.all(updatePromises)
    // Reload rooms after all status updates
    await loadRooms()
  }

  async function updateRoomStatus(roomId: string, status: string) {
    try {
      const res = await fetch('/api/hotel/rooms/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ roomId, status })
      })
      if (res.ok) {
        loadRooms()
      }
    } catch (error) {
      console.error('Failed to update room status:', error)
    }
  }

  async function checkInGuest(data: any) {
    // Check if system is locked
    if (SystemLockService.isLocked()) {
      alert('❌ სისტემა დაბლოკილია! დღის დახურვა მიმდინარეობს.\nგთხოვთ დაელოდოთ პროცესის დასრულებას.')
      return
    }
    try {
      // Generate reservation number if not provided
      const reservationNumber = data.reservationNumber || Math.floor(10000 + Math.random() * 90000).toString()
      
      // Save reservation
      const res = await fetch('/api/hotel/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          reservationNumber,
          status: 'CONFIRMED',
          createdAt: new Date().toISOString()
        })
      })
      
      if (res.ok) {
        const newReservation = await res.json()
        ActivityLogger.log('RESERVATION_CREATE', { 
          reservationNumber, 
          room: data.roomNumber, 
          guest: data.guestName,
          checkIn: data.checkIn,
          checkOut: data.checkOut,
          amount: data.totalAmount
        })
        
        // Update room status to OCCUPIED
        await fetch('/api/hotel/rooms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            roomId: data.roomId, 
            status: 'OCCUPIED' 
          })
        })
        
        // Reload data
        await loadRooms()
        await loadReservations()
        
        // Close modal
        setShowCheckInModal(false)
        setSelectedRoom(null)
        
        // Show success message
        alert('ჯავშანი წარმატებით შეიქმნა!')
      }
    } catch (error) {
      console.error('Failed to check in guest:', error)
      alert('შეცდომა ჯავშნის შექმნისას')
    }
  }

  async function updateReservation(id: string, updates: any): Promise<void> {
    try {
      const res = await fetch('/api/hotel/reservations', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...updates })
      })
      
      if (res.ok) {
        await loadReservations()
        await loadRooms()
      } else {
        throw new Error('Failed to update reservation')
      }
    } catch (error) {
      console.error('Failed to update reservation:', error)
      throw error
    }
  }

  async function deleteReservation(id: string): Promise<void> {
    // Check if system is locked
    if (SystemLockService.isLocked()) {
      alert('❌ სისტემა დაბლოკილია! დღის დახურვა მიმდინარეობს.')
      throw new Error('System is locked')
    }
    try {
      const res = await fetch(`/api/hotel/reservations/${id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      })
      
      if (res.ok) {
        ActivityLogger.log('RESERVATION_DELETE', { reservationId: id })
        await loadReservations()
        await loadRooms()
      } else {
        throw new Error('Failed to delete reservation')
      }
    } catch (error) {
      console.error('Failed to delete reservation:', error)
      throw error
    }
  }

  if (!currentUser) {
    return null // Will redirect to login
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Mobile Menu Toggle */}
      <button 
        className="md:hidden fixed bottom-4 right-4 z-50 bg-blue-600 text-white p-3 rounded-full shadow-lg"
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
      >
        {mobileMenuOpen ? '✕' : '☰'}
      </button>
      
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="px-4 md:px-6 py-3 md:py-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center gap-4">
              <h1 className="text-xl md:text-2xl font-bold">🏨 Hotel Management System</h1>
              <span className="text-sm text-gray-500 hidden md:inline">Hotel Tbilisi Dashboard</span>
              {(() => {
                const getBusinessDay = () => {
                  const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
                  
                  if (lastAuditDate) {
                    try {
                      const lastClosed = JSON.parse(lastAuditDate)
                      // Business day is NEXT day after audit
                      return moment(lastClosed).add(1, 'day').format('YYYY-MM-DD')
                    } catch {
                      return moment().format('YYYY-MM-DD')
                    }
                  }
                  
                  // If no audit, use today
                  return moment().format('YYYY-MM-DD')
                }
                
                const businessDay = getBusinessDay()
                const lastAuditDate = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
                
                return (
                  <span className="text-xs md:text-sm text-blue-600 font-medium hidden md:inline">
                    Business Day: {moment(businessDay).format('DD/MM/YYYY')}
                  </span>
                )
              })()}
              
              {/* Debug button - remove after testing */}
              <button
                onClick={() => {
                  const lastAudit = typeof window !== 'undefined' ? localStorage.getItem('lastAuditDate') : null
                  const parsed = lastAudit ? JSON.parse(lastAudit) : null
                  const businessDay = parsed ? moment(parsed).add(1, 'day').format('YYYY-MM-DD') : 'No audit'
                  
                  alert(`Debug Info:\n
Today: ${moment().format('YYYY-MM-DD')}
TODAY (fixed): 2025-11-26
Last Audit: ${parsed || 'None'}
Business Day: ${businessDay}
Can book from: ${businessDay}

Try clicking on Nov 26 in calendar.`)
                }}
                className="px-3 py-2 bg-yellow-500 text-white rounded text-xs md:text-sm hover:bg-yellow-600 transition"
              >
                🐛 Debug
              </button>
            </div>
            
            <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
              {/* User Info Badge */}
              <div className="bg-gray-100 px-3 md:px-4 py-2 rounded-lg flex items-center gap-2 order-3 md:order-1">
                <span className="text-xl md:text-2xl">
                  {currentUser?.role === 'admin' ? '👑' : 
                   currentUser?.role === 'manager' ? '💼' : '👤'}
                </span>
                <div>
                  <div className="text-xs md:text-sm font-medium">{currentUser?.name}</div>
                  <div className="text-xs text-gray-500">{currentUser?.role}</div>
                </div>
              </div>
              
              {/* Quick Menu Dropdown */}
              <div className="flex gap-2 order-1 md:order-2">
                {/* Quick Menu Dropdown */}
                <div className="relative">
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      setShowQuickMenu(!showQuickMenu)
                    }}
                    className="px-3 md:px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 flex items-center gap-2 text-sm md:text-base"
                  >
                    ⚡ სწრაფი მენიუ
                    <span className="text-xs">▼</span>
                  </button>
                  
                  {showQuickMenu && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border z-50">
                      <button
                        onClick={() => addTabFromMenu('reservations')}
                        className="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center gap-2"
                      >
                        📋 ჯავშნები
                      </button>
                      <button
                        onClick={() => addTabFromMenu('housekeeping')}
                        className="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center gap-2"
                      >
                        🧹 დასუფთავება
                      </button>
                      <button
                        onClick={() => addTabFromMenu('roomgrid')}
                        className="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center gap-2"
                      >
                        🏨 ოთახები
                      </button>
                      {canViewReports && (
                        <button
                          onClick={() => addTabFromMenu('reports')}
                          className="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center gap-2"
                        >
                          📊 რეპორტები
                        </button>
                      )}
                      {canCloseDay && (
                        <button
                          onClick={() => addTabFromMenu('nightaudit')}
                          className="w-full text-left px-4 py-3 hover:bg-gray-100 flex items-center gap-2"
                        >
                          🌙 დღის დახურვა
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
              
              {/* Settings Button - Only for admins/managers */}
              {canEdit && (
                <button
                  onClick={() => {
                    setShowSettingsModal(true)
                    ActivityLogger.log('OPEN_SETTINGS', {})
                  }}
                  className="px-3 md:px-4 py-2 bg-gray-100 border rounded hover:bg-gray-200 text-sm md:text-base order-2 md:order-3"
                >
                  ⚙️ პარამეტრები
                </button>
              )}
              
              {/* Clear Test Data - Development Only */}
              {process.env.NODE_ENV === 'development' && (
                <button
                  onClick={() => {
                    if (confirm('წაიშალოს ყველა ტესტ მონაცემი?')) {
                      // Clear all reservations
                      localStorage.removeItem('hotelReservations')
                      
                      // Clear all night audits
                      localStorage.removeItem('nightAudits')
                      localStorage.removeItem('lastAuditDate')
                      localStorage.removeItem('tempChecklist')
                      
                      // Clear housekeeping
                      localStorage.removeItem('housekeepingTasks')
                      localStorage.removeItem('housekeepingArchive')
                      
                      // Clear activity logs
                      localStorage.removeItem('activityLogs')
                      
                      // Keep settings but clear data
                      alert('✅ ყველა ტესტ მონაცემი წაშლილია!')
                      location.reload()
                    }
                  }}
                  className="px-3 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm md:text-base order-4 md:order-5"
                >
                  🗑️ Clear Test Data
                </button>
              )}
              
              {/* Logout */}
              <button
                onClick={handleLogout}
                className="px-3 md:px-4 py-2 text-red-600 hover:bg-red-50 rounded text-sm md:text-base order-5 md:order-6"
                title="გასვლა"
              >
                ↗
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Statistics - ONLY ONCE */}
      <div className="bg-white px-2 md:px-6 py-3 md:py-4 border-b">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 md:gap-4">
          <div className="bg-white rounded-lg p-3 md:p-4 border shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-gray-500">სულ ნომრები</p>
                <p className="text-xl md:text-2xl font-bold">{stats.total}</p>
              </div>
              <span className="text-2xl md:text-3xl">🏨</span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-3 md:p-4 border border-red-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-gray-500">დაკავებული</p>
                <p className="text-xl md:text-2xl font-bold text-red-600">{stats.occupied}</p>
              </div>
              <span className="w-2 h-2 md:w-3 md:h-3 bg-red-500 rounded-full"></span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-3 md:p-4 border border-green-200 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-gray-500">თავისუფალი</p>
                <p className="text-xl md:text-2xl font-bold text-green-600">{stats.vacant}</p>
              </div>
              <span className="w-2 h-2 md:w-3 md:h-3 bg-green-500 rounded-full"></span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-3 md:p-4 border shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-gray-500">დასუფთავება</p>
                <p className="text-xl md:text-2xl font-bold">{stats.cleaning}</p>
              </div>
              <span className="text-xl md:text-2xl">✓</span>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-3 md:p-4 border shadow-sm col-span-2 md:col-span-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-gray-500">დატვირთულობა</p>
                <p className="text-xl md:text-2xl font-bold text-blue-600">{stats.occupancyRate}%</p>
              </div>
              <span className="text-xl md:text-2xl">📊</span>
            </div>
          </div>
        </div>
      </div>
        
      {/* Dynamic Tabs */}
      <div className="bg-white border-b px-4 md:px-6">
        <div className="flex gap-2 items-center overflow-x-auto">
          {activeTabs.map(tabId => (
            <div
              key={tabId}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 cursor-pointer transition whitespace-nowrap ${
                activeTab === tabId ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <button
                onClick={() => setActiveTab(tabId)}
                className="font-medium"
              >
                {getTabLabel(tabId)}
              </button>
              
              {/* Close button - not for calendar */}
              {tabId !== 'calendar' && (
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    closeTab(tabId)
                  }}
                  className="ml-2 text-gray-400 hover:text-red-600 text-lg font-bold"
                >
                  ×
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Main Content - Full Screen */}
      <div className="flex-1 p-2 md:p-6 overflow-auto">
        {activeTab === 'calendar' && (
          <div className="overflow-x-auto">
            <div className="min-w-[800px]">
              <RoomCalendar 
                rooms={rooms.map(room => ({
                  ...room,
                  status: maintenanceRooms.includes(room.id) ? 'MAINTENANCE' : room.status
                }))}
                reservations={reservations}
                onSlotClick={(roomId, date, room) => {
                  setSelectedRoom(room)
                  const checkInDate = moment(date).format('YYYY-MM-DD')
                  setInitialCheckInDate(checkInDate)
                  setShowCheckInModal(true)
                }}
                onReservationUpdate={updateReservation}
                onReservationDelete={deleteReservation}
                loadReservations={loadReservations}
              />
            </div>
          </div>
        )}
        
        {activeTab === 'rooms' && (
          <div>
            <h2 className="text-xl font-bold mb-4">🏨 ნომრების მართვა</h2>
            
            {/* Floor 3 */}
            {rooms.filter(r => r.floor === 3).length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-600 mb-3 px-2 py-1 bg-gray-50 rounded">
                  მესამე სართული
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {rooms.filter(r => r.floor === 3).map(room => (
                    <RoomCard 
                      key={room.id} 
                      room={room} 
                      onClick={() => setSelectedRoom(room)}
                      onStatusChange={updateRoomStatus}
                    />
                  ))}
                </div>
              </div>
            )}
            
            {/* Floor 2 */}
            {rooms.filter(r => r.floor === 2).length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-600 mb-3 px-2 py-1 bg-gray-50 rounded">
                  მეორე სართული
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {rooms.filter(r => r.floor === 2).map(room => (
                    <RoomCard 
                      key={room.id} 
                      room={room} 
                      onClick={() => setSelectedRoom(room)}
                      onStatusChange={updateRoomStatus}
                    />
                  ))}
                </div>
              </div>
            )}
            
            {/* Floor 1 */}
            {rooms.filter(r => r.floor === 1).length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium text-gray-600 mb-3 px-2 py-1 bg-gray-50 rounded">
                  პირველი სართული
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {rooms.filter(r => r.floor === 1).map(room => (
                    <RoomCard 
                      key={room.id} 
                      room={room} 
                      onClick={() => setSelectedRoom(room)}
                      onStatusChange={updateRoomStatus}
                    />
                  ))}
                </div>
              </div>
            )}

            {rooms.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                ოთახები არ მოიძებნა
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'reservations' && (
          <ReservationsView reservations={reservations} rooms={rooms} />
        )}
        
        {activeTab === 'housekeeping' && (
          <HousekeepingView rooms={rooms} onRoomStatusUpdate={updateRoomStatus} />
        )}
        
        {activeTab === 'roomgrid' && (
          <RoomGridView 
            rooms={rooms}
            onRoomClick={(room) => {
              console.log('Room clicked:', room)
            }}
            onStatusChange={updateRoomStatus}
            loadRooms={loadRooms}
          />
        )}
        
        {activeTab === 'reports' && canViewReports && (
          <Reports reservations={reservations} rooms={rooms} />
        )}
        
        {activeTab === 'nightaudit' && canCloseDay && (
          <NightAuditView 
            rooms={rooms}
            reservations={reservations}
            onAuditComplete={(action: string, id: string) => {
              if (action === 'cancelNoShow') {
                // Handle no-show cancellation
                updateReservation(id, { status: 'CANCELLED' })
              }
            }}
          />
        )}
      </div>

      {/* Check-in Modal */}
      {showCheckInModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <CheckInModal 
              room={selectedRoom || undefined}
              rooms={rooms.filter(r => r.status === 'VACANT')}
              initialCheckIn={initialCheckInDate}
              onClose={() => {
                setShowCheckInModal(false)
                setSelectedRoom(null)
                setInitialCheckInDate(undefined)
              }}
              onSubmit={checkInGuest}
            />
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettingsModal && canEdit && (
        <SettingsModal 
          onClose={() => setShowSettingsModal(false)}
          rooms={rooms}
          onRoomsUpdate={() => {
            loadRooms() // Reload rooms after update
          }}
        />
      )}
      
      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-50"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div 
            className="bg-white w-64 h-full p-4 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg">მენიუ</h3>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ×
              </button>
            </div>
            <div className="space-y-2">
              <button 
                onClick={() => {
                  setActiveTab('calendar')
                  setMobileMenuOpen(false)
                }} 
                className={`w-full text-left p-3 hover:bg-gray-100 rounded ${
                  activeTab === 'calendar' ? 'bg-blue-50 text-blue-600' : ''
                }`}
              >
                📅 კალენდარი
              </button>
              <button 
                onClick={() => {
                  addTabFromMenu('reservations')
                  setMobileMenuOpen(false)
                }} 
                className={`w-full text-left p-3 hover:bg-gray-100 rounded ${
                  activeTab === 'reservations' ? 'bg-blue-50 text-blue-600' : ''
                }`}
              >
                📋 ჯავშნები
              </button>
              <button 
                onClick={() => {
                  addTabFromMenu('housekeeping')
                  setMobileMenuOpen(false)
                }} 
                className={`w-full text-left p-3 hover:bg-gray-100 rounded ${
                  activeTab === 'housekeeping' ? 'bg-blue-50 text-blue-600' : ''
                }`}
              >
                🧹 დასუფთავება
              </button>
              <button 
                onClick={() => {
                  addTabFromMenu('roomgrid')
                  setMobileMenuOpen(false)
                }} 
                className={`w-full text-left p-3 hover:bg-gray-100 rounded ${
                  activeTab === 'roomgrid' ? 'bg-blue-50 text-blue-600' : ''
                }`}
              >
                🏨 ოთახები
              </button>
              {canViewReports && (
                <button 
                  onClick={() => {
                    addTabFromMenu('reports')
                    setMobileMenuOpen(false)
                  }} 
                  className={`w-full text-left p-3 hover:bg-gray-100 rounded ${
                    activeTab === 'reports' ? 'bg-blue-50 text-blue-600' : ''
                  }`}
                >
                  📊 რეპორტები
                </button>
              )}
              {canCloseDay && (
                <button 
                  onClick={() => {
                    addTabFromMenu('nightaudit')
                    setMobileMenuOpen(false)
                  }} 
                  className={`w-full text-left p-3 hover:bg-gray-100 rounded ${
                    activeTab === 'nightaudit' ? 'bg-blue-50 text-blue-600' : ''
                  }`}
                >
                  🌙 დღის დახურვა
                </button>
              )}
              {canEdit && (
                <button 
                  onClick={() => {
                    setShowSettingsModal(true)
                    setMobileMenuOpen(false)
                    ActivityLogger.log('OPEN_SETTINGS', {})
                  }} 
                  className="w-full text-left p-3 hover:bg-gray-100 rounded"
                >
                  ⚙️ პარამეტრები
                </button>
              )}
              <div className="border-t pt-2 mt-4">
                <div className="px-3 py-2 text-sm text-gray-600">
                  <div className="font-medium">{currentUser?.name}</div>
                  <div className="text-xs text-gray-500">{currentUser?.role}</div>
                </div>
                <button 
                  onClick={() => {
                    handleLogout()
                    setMobileMenuOpen(false)
                  }} 
                  className="w-full text-left p-3 hover:bg-red-50 text-red-600 rounded"
                >
                  ↗ გასვლა
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* System Lock Overlay - Always at the end */}
      <SystemLockOverlay />
    </div>
  )
}

// Room Card Component
function RoomCard({ room, onClick, onStatusChange }: {
  room: Room
  onClick: () => void
  onStatusChange: (roomId: string, status: string) => void
}) {
  const statusConfig: Record<string, { color: string; label: string; icon: string }> = {
    'VACANT': { color: 'bg-green-100 border-green-400 text-green-800', label: 'თავისუფალი', icon: '🟢' },
    'OCCUPIED': { color: 'bg-red-100 border-red-400 text-red-800', label: 'დაკავებული', icon: '🔴' },
    'CLEANING': { color: 'bg-yellow-100 border-yellow-400 text-yellow-800', label: 'დასუფთავება', icon: '🧹' },
    'MAINTENANCE': { color: 'bg-gray-100 border-gray-400 text-gray-800', label: 'რემონტი', icon: '🔧' }
  }

  const config = statusConfig[room.status] || statusConfig['VACANT']

  return (
    <div 
      className={`border-2 rounded-lg p-3 cursor-pointer transition hover:shadow-md ${config.color}`}
      onClick={onClick}
    >
      <div className="flex justify-between items-start mb-2">
        <span className="font-bold text-lg">{room.roomNumber}</span>
        <span className="text-lg">{config.icon}</span>
      </div>
      <div className="text-sm font-medium mb-1">
        {room.roomType || (room.floor === 3 ? 'Suite' : room.floor === 2 ? 'Deluxe' : 'Standard')}
      </div>
      <div className="text-xs font-medium mb-2">
        {config.label}
      </div>
      <div className="text-xs text-gray-600">
        ₾{room.basePrice}/ღამე
      </div>
      
      {room.status === 'VACANT' && (
        <button 
          onClick={(e) => {
            e.stopPropagation()
            onStatusChange(room.id, 'CLEANING')
          }}
          className="w-full mt-2 bg-yellow-500 text-white text-xs py-1 rounded hover:bg-yellow-600 transition-colors"
        >
          დასუფთავება
        </button>
      )}
      
      {room.status === 'CLEANING' && (
        <button 
          onClick={(e) => {
            e.stopPropagation()
            onStatusChange(room.id, 'VACANT')
          }}
          className="w-full mt-2 bg-green-500 text-white text-xs py-1 rounded hover:bg-green-600 transition-colors"
        >
          დასრულებულია
        </button>
      )}
    </div>
  )
}
