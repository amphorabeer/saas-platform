# 🌙 Night Audit - დღის დახურვის წესები

## 📋 ზოგადი ინფორმაცია

Night Audit არის ყოველდღიური პროცესი, რომელიც ახდენს დღის ფინანსურ და ოპერაციულ შეჯამებას. დღის დახურვის შემდეგ, დახურული პერიოდის რედაქტირება შეუძლებელია.

---

## ✅ დახურვის წინაპირობები

### 1. თარიღის შემოწმება
- ❌ **დღევანდელი დღე არ იხურება** - მხოლოდ გუშინდელი ან უფრო ძველი დღეები
- ❌ **მომავალი თარიღი არ იხურება**
- ❌ **ერთი დღე მხოლოდ ერთხელ იხურება** - თუ უკვე დახურულია, ხელახლა არ იხურება

### 2. თანმიმდევრული დახურვა
- ✅ **დღეები უნდა იხურებოდეს თანმიმდევრულად** - გამოტოვება არ შეიძლება
- 📅 **მაგალითი**: თუ ბოლო დახურვა იყო **Nov 1**, შემდეგი უნდა იყოს **Nov 2**

### 3. System Lock შემოწმება
- ⚠️ **სისტემა არ უნდა იყოს დაბლოკილი** - სხვა პროცესის მიმდინარეობისას დახურვა შეუძლებელია

---

## 🚫 მკაცრი ვალიდაცია (Blocking Errors)

### 1. Pending Check-outs (დაუსრულებელი Check-out-ები)
- ❌ **ყველა pending check-out უნდა იყოს დასრულებული**
- 📅 **შემოწმება**: თუ checkout date ≤ audit date და status = 'CHECKED_IN'
- 💬 **Error**: `❌ X დაუსრულებელი Check-out: [სია] - უნდა გასულიყო [თარიღი]`

### 2. Unpaid Check-outs (გადაუხდელი Check-out-ები)
- 💰 **დღევანდელი checkout-ები უნდა იყოს გადახდილი**
- 📅 **შემოწმება**: checkout date = audit date, status = 'CHECKED_IN', isPaid = false
- 💬 **Error**: `💰 X გადაუხდელი Check-out: [სია] - ₾[თანხა]`

### 3. Pending Check-ins (დაუსრულებელი Check-in-ები)
- ❌ **დღევანდელი check-in-ები უნდა იყოს დასრულებული**
- 📅 **შემოწმება**: check-in date = audit date, status = 'CONFIRMED'
- 💬 **Error**: `❌ X დაუსრულებელი Check-in: [სია]`

---

## ✅ Checklist Validation

ყველა checklist item უნდა იყოს მონიშნული:

1. ✅ **დღევანდელი Check-in დასრულებულია**
2. ✅ **დღევანდელი Check-out დასრულებულია**
3. ✅ **გადახდები შემოწმებულია**
4. ✅ **ნაღდი ფული დათვლილია**
5. ✅ **დასუფთავება შემოწმებულია**
6. ✅ **No-show დამუშავებულია**
7. ✅ **მომავალი დღის ჯავშნები შემოწმებულია**
8. ✅ **Backup შექმნილია**

---

## 📊 No-Show Processing

### ავტომატური დამუშავება:
- 🔍 **შემოწმება**: CONFIRMED reservations audit day-ზე
- ⚠️ **Confirmation**: კითხულობს მომხმარებლის დადასტურებას
- 📝 **დამუშავება**: ამთავრებს status-ს 'NO_SHOW'-ზე
- 💾 **შენახვა**: ინახავს localStorage-ში
- 📋 **Activity Log**: ჩაწერს Activity Log-ში

---

## 📈 Statistics Calculation

დახურვისას გამოითვლება:

### Basic Counts:
- **totalCheckIns**: დღევანდელი check-ins
- **totalCheckOuts**: დღევანდელი check-outs

### Financial:
- **totalRevenue**: გადახდილი reservations-ის revenue
- **averageRate**: საშუალო გადასახადი

### Occupancy:
- **occupiedRooms**: დაკავებული ოთახები audit day-ზე
- **totalRooms**: სულ ოთახები
- **occupancyRate**: დატვირთულობის პროცენტი

### Other:
- **noShows**: no-show reservations
- **cancellations**: გაუქმებული reservations

---

## 🔄 დახურვის პროცესი

### Step-by-Step:

1. **System Lock Check** - სისტემა არ უნდა იყოს დაბლოკილი
2. **Auto Checks** - ავტომატურად გადაიწერება checklist
3. **Date Validation** - თარიღის შემოწმება
4. **Sequential Check** - თანმიმდევრულობის შემოწმება
5. **Strict Validation** - `validateDayCanBeClosed()` შემოწმება
6. **Checklist Validation** - ყველა item მონიშნულია
7. **No-Show Processing** - no-show-ების დამუშავება
8. **Statistics Calculation** - სტატისტიკის გამოთვლა
9. **Confirmation** - მომხმარებლის დადასტურება სტატისტიკით
10. **System Lock** - სისტემის დაბლოკვა დახურვისას
11. **Audit Log** - audit log-ის შენახვა localStorage-ში
12. **Activity Log** - activity log-ში ჩაწერა
13. **Unlock & Reload** - სისტემის განბლოკვა და გვერდის განახლება

---

## 💾 Audit Log Structure

```json
{
  "id": 1234567890,
  "date": "2025-11-01",
  "closedAt": "2025-11-02T10:30:00.000Z",
  "closedBy": "admin",
  "stats": {
    "totalCheckIns": 5,
    "totalCheckOuts": 3,
    "totalRevenue": 1500,
    "occupiedRooms": 12,
    "totalRooms": 20,
    "occupancyRate": 60,
    "averageRate": 300,
    "noShows": 1,
    "cancellations": 0
  },
  "checklist": [...],
  "noShowsProcessed": 1
}
```

---

## ⚙️ Admin Override System

### ხელახალი გახსნა:
- 👑 **მხოლოდ Admin-ისთვის** - role check
- 📋 **დახურული დღეების სია** - ყველა დახურული დღე
- 🔓 **ხელახალი გახსნა** - მიზეზის მითითებით (მინ. 10 სიმბოლო)
- 📝 **Override Log** - ინახავს localStorage-ში
- 📋 **Activity Log** - ჩაწერს Activity Log-ში
- 🔄 **lastAuditDate Update** - განახლებს last audit date-ს

### Override Log Structure:
```json
{
  "action": "REOPEN_DAY",
  "date": "2025-11-01",
  "reason": "დეტალური მიზეზი...",
  "user": "admin",
  "timestamp": "2025-11-02T11:00:00.000Z"
}
```

---

## ⚠️ შენიშვნები

### Continuing Guests:
- ℹ️ **სტუმრები, რომლებიც კვლავ დარჩენილები არიან, არ ბლოკავენ დახურვას**
- 💰 **გადახდა მოწმდება checkout-ზე, არა audit day-ზე**

### Payment Validation:
- 💰 **გადახდა მოწმდება მხოლოდ checkout-ზე**
- ✅ **Continuing guests-ის გადახდა არ ბლოკავს დახურვას**

### No-Show Processing:
- ⚠️ **No-show-ები დამუშავდება დახურვისას**
- 📝 **Status იცვლება 'NO_SHOW'-ზე**
- 💾 **ინახება localStorage-ში**

---

## 🎯 დახურვის კონფირმაცია

დახურვისას ჩანს:

```
დღის დახურვა: DD/MM/YYYY

📊 სტატისტიკა:
• Check-ins: X
• Check-outs: Y
• შემოსავალი: ₾Z
• დატვირთულობა: W%
• No-shows: N

დარწმუნებული ხართ?
```

---

## ✅ წარმატებული დახურვა

დახურვის შემდეგ:
- ✅ **Audit log ინახება** localStorage-ში
- ✅ **lastAuditDate განახლდება**
- ✅ **Activity log-ში ჩაიწერება**
- ✅ **Alert**: "✅ დღე წარმატებით დაიხურა!"
- ✅ **Page reload**

---

## 📝 Error Messages

### Pending Check-outs:
```
❌ X დაუსრულებელი Check-out:
- Guest Name (Room XXX) - უნდა გასულიყო DD/MM
```

### Unpaid Check-outs:
```
💰 X გადაუხდელი Check-out:
- Guest Name (Room XXX) - ₾XXX
```

### Pending Check-ins:
```
❌ X დაუსრულებელი Check-in:
- Guest Name (Room XXX)
```

### General Blocking:
```
🚫 დღე ვერ დაიხურება!

პრობლემები:
[error messages]

გთხოვთ დაასრულოთ ყველა ოპერაცია.
```

---

## 🔒 დახურული პერიოდის რედაქტირება

დახურვის შემდეგ:
- ❌ **Reservations-ის რედაქტირება შეუძლებელია**
- 👁️ **მხოლოდ View-Only modal** - დეტალების ნახვა
- ⚠️ **Warning**: "დახურული პერიოდის ჯავშანი - რედაქტირება შეუზღუდულია"
- 🔓 **Admin Override** - admin-ს შეუძლია დღის ხელახალი გახსნა

---

## 📚 დამატებითი ინფორმაცია

- **Business Day**: ბოლო დახურული დღე + 1
- **Booking Restriction**: ახალი reservations მხოლოდ business day-დან
- **Sequential Closing**: დღეები უნდა იხურებოდეს თანმიმდევრულად
- **Activity Logging**: ყველა მოქმედება ინახება Activity Log-ში

---

**ბოლო განახლება**: 2025-11-26

