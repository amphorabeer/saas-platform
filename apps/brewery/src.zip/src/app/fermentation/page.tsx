'use client'



import { useState, useEffect } from 'react'

import { DashboardLayout } from '@/components/layout'

import { Card, CardHeader, CardBody, ProgressBar, BatchStatusBadge } from '@/components/ui'

import { TankCard, TankDetailModal } from '@/components/fermentation'

import { mockTanks as sharedTanks, mockBatches } from '@/data/mockData'



interface Tank {

  id: string

  name: string

  type: 'fermenter' | 'brite' | 'conditioning'

  capacity: number

  currentVolume: number

  status: 'available' | 'in_use' | 'cleaning' | 'maintenance'

  batch?: {

    id: string

    batchNumber: string

    recipe: string

    status: 'fermenting' | 'conditioning' | 'ready'

    startDate: Date

    estimatedEndDate: Date

    progress: number

  }

  temperature: {

    current: number

    target: number

    history: { time: string; value: number }[]

  }

  gravity: {

    original: number

    current: number

    target: number

    history: { time: string; value: number }[]

  }

  pressure?: number

  ph?: number

  lastUpdated: Date

}



const mockTanks: Tank[] = [

  {

    id: 'fv-01',

    name: 'FV-01',

    type: 'fermenter',

    capacity: 2000,

    currentVolume: 1850,

    status: 'in_use',

    batch: {

      id: '1',

      batchNumber: 'BRW-2024-0156',

      recipe: 'Georgian Amber Lager',

      status: 'fermenting',

      startDate: new Date('2024-12-01'),

      estimatedEndDate: new Date('2024-12-15'),

      progress: 65,

    },

    temperature: {

      current: 12.3,

      target: 12.0,

      history: [

        { time: '00:00', value: 12.1 },

        { time: '04:00', value: 12.2 },

        { time: '08:00', value: 12.4 },

        { time: '12:00', value: 12.3 },

        { time: '16:00', value: 12.2 },

        { time: '20:00', value: 12.3 },

      ],

    },

    gravity: {

      original: 1.052,

      current: 1.018,

      target: 1.012,

      history: [

        { time: 'დღე 1', value: 1.052 },

        { time: 'დღე 3', value: 1.042 },

        { time: 'დღე 5', value: 1.032 },

        { time: 'დღე 7', value: 1.024 },

        { time: 'დღე 9', value: 1.018 },

      ],

    },

    pressure: 1.2,

    ph: 4.3,

    lastUpdated: new Date(),

  },

  {

    id: 'fv-02',

    name: 'FV-02',

    type: 'fermenter',

    capacity: 2000,

    currentVolume: 1920,

    status: 'in_use',

    batch: {

      id: '2',

      batchNumber: 'BRW-2024-0157',

      recipe: 'Tbilisi IPA',

      status: 'fermenting',

      startDate: new Date('2024-12-05'),

      estimatedEndDate: new Date('2024-12-19'),

      progress: 35,

    },

    temperature: {

      current: 18.5,

      target: 18.0,

      history: [

        { time: '00:00', value: 18.2 },

        { time: '04:00', value: 18.4 },

        { time: '08:00', value: 18.6 },

        { time: '12:00', value: 18.5 },

        { time: '16:00', value: 18.3 },

        { time: '20:00', value: 18.5 },

      ],

    },

    gravity: {

      original: 1.065,

      current: 1.038,

      target: 1.012,

      history: [

        { time: 'დღე 1', value: 1.065 },

        { time: 'დღე 3', value: 1.052 },

        { time: 'დღე 5', value: 1.038 },

      ],

    },

    pressure: 1.4,

    ph: 4.1,

    lastUpdated: new Date(),

  },

  {

    id: 'fv-03',

    name: 'FV-03',

    type: 'fermenter',

    capacity: 2500,

    currentVolume: 0,

    status: 'available',

    temperature: {

      current: 4.0,

      target: 4.0,

      history: [],

    },

    gravity: {

      original: 0,

      current: 0,

      target: 0,

      history: [],

    },

    lastUpdated: new Date(),

  },

  {

    id: 'fv-04',

    name: 'FV-04',

    type: 'fermenter',

    capacity: 2500,

    currentVolume: 0,

    status: 'cleaning',

    temperature: {

      current: 65.0,

      target: 65.0,

      history: [],

    },

    gravity: {

      original: 0,

      current: 0,

      target: 0,

      history: [],

    },

    lastUpdated: new Date(),

  },

  {

    id: 'bbt-01',

    name: 'BBT-01',

    type: 'brite',

    capacity: 2000,

    currentVolume: 1800,

    status: 'in_use',

    batch: {

      id: '3',

      batchNumber: 'BRW-2024-0155',

      recipe: 'კახური Pilsner',

      status: 'conditioning',

      startDate: new Date('2024-11-28'),

      estimatedEndDate: new Date('2024-12-12'),

      progress: 85,

    },

    temperature: {

      current: 2.1,

      target: 2.0,

      history: [

        { time: '00:00', value: 2.0 },

        { time: '04:00', value: 2.1 },

        { time: '08:00', value: 2.0 },

        { time: '12:00', value: 2.1 },

        { time: '16:00', value: 2.0 },

        { time: '20:00', value: 2.1 },

      ],

    },

    gravity: {

      original: 1.045,

      current: 1.008,

      target: 1.008,

      history: [],

    },

    pressure: 2.4,

    ph: 4.2,

    lastUpdated: new Date(),

  },

  {

    id: 'bbt-02',

    name: 'BBT-02',

    type: 'brite',

    capacity: 2000,

    currentVolume: 1950,

    status: 'in_use',

    batch: {

      id: '4',

      batchNumber: 'BRW-2024-0154',

      recipe: 'Kolkheti Stout',

      status: 'ready',

      startDate: new Date('2024-11-20'),

      estimatedEndDate: new Date('2024-12-10'),

      progress: 100,

    },

    temperature: {

      current: 4.0,

      target: 4.0,

      history: [],

    },

    gravity: {

      original: 1.070,

      current: 1.015,

      target: 1.015,

      history: [],

    },

    pressure: 2.2,

    ph: 4.4,

    lastUpdated: new Date(),

  },

]



export default function FermentationPage() {

  const [tanks, setTanks] = useState(mockTanks)

  const [selectedTank, setSelectedTank] = useState<Tank | null>(null)

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  const [filterType, setFilterType] = useState<string>('all')



  // Simulate real-time updates

  useEffect(() => {

    const interval = setInterval(() => {

      setTanks(prev => prev.map(tank => {

        if (tank.status !== 'in_use') return tank

        

        // Simulate temperature fluctuation

        const tempVariation = (Math.random() - 0.5) * 0.2

        const newTemp = Math.round((tank.temperature.current + tempVariation) * 10) / 10

        

        return {

          ...tank,

          temperature: {

            ...tank.temperature,

            current: newTemp,

          },

          lastUpdated: new Date(),

        }

      }))

    }, 5000)



    return () => clearInterval(interval)

  }, [])



  const filteredTanks = tanks.filter(tank => {

    if (filterType === 'all') return true

    if (filterType === 'fermenter') return tank.type === 'fermenter'

    if (filterType === 'brite') return tank.type === 'brite'

    if (filterType === 'active') return tank.status === 'in_use'

    if (filterType === 'available') return tank.status === 'available'

    return true

  })



  const stats = {

    totalTanks: tanks.length,

    activeTanks: tanks.filter(t => t.status === 'in_use').length,

    availableTanks: tanks.filter(t => t.status === 'available').length,

    totalCapacity: tanks.reduce((sum, t) => sum + t.capacity, 0),

    usedCapacity: tanks.reduce((sum, t) => sum + t.currentVolume, 0),

  }



  return (

    <DashboardLayout title="ფერმენტაცია" breadcrumb="მთავარი / ფერმენტაცია">

      {/* Stats Row */}

      <div className="grid grid-cols-5 gap-4 mb-6">

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display text-copper-light">{stats.totalTanks}</p>

          <p className="text-xs text-text-muted">სულ ტანკი</p>

        </div>

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display text-amber-400">{stats.activeTanks}</p>

          <p className="text-xs text-text-muted">აქტიური</p>

        </div>

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display text-green-400">{stats.availableTanks}</p>

          <p className="text-xs text-text-muted">თავისუფალი</p>

        </div>

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display">{(stats.totalCapacity / 1000).toFixed(1)}k</p>

          <p className="text-xs text-text-muted">სულ მოცულობა (L)</p>

        </div>

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display">{Math.round(stats.usedCapacity / stats.totalCapacity * 100)}%</p>

          <p className="text-xs text-text-muted">გამოყენება</p>

          <ProgressBar value={Math.round(stats.usedCapacity / stats.totalCapacity * 100)} size="sm" color="copper" className="mt-2" />

        </div>

      </div>



      {/* Filters */}

      <div className="flex justify-between items-center mb-6">

        <div className="flex gap-2">

          {[

            { key: 'all', label: 'ყველა' },

            { key: 'fermenter', label: 'ფერმენტატორები' },

            { key: 'brite', label: 'ბრაიტ ტანკები' },

            { key: 'active', label: 'აქტიური' },

            { key: 'available', label: 'თავისუფალი' },

          ].map(filter => (

            <button

              key={filter.key}

              onClick={() => setFilterType(filter.key)}

              className={`px-4 py-2 rounded-lg text-sm transition-all ${

                filterType === filter.key

                  ? 'bg-copper text-white'

                  : 'bg-bg-tertiary text-text-secondary hover:bg-bg-card'

              }`}

            >

              {filter.label}

            </button>

          ))}

        </div>

        <div className="flex gap-2">

          <button

            onClick={() => setViewMode('grid')}

            className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-copper text-white' : 'bg-bg-tertiary'}`}

          >

            ▦

          </button>

          <button

            onClick={() => setViewMode('list')}

            className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-copper text-white' : 'bg-bg-tertiary'}`}

          >

            ☰

          </button>

        </div>

      </div>



      {/* Tanks Grid */}

      <div className={viewMode === 'grid' ? 'grid grid-cols-3 gap-6' : 'space-y-4'}>

        {filteredTanks.map(tank => (

          <TankCard 

            key={tank.id} 

            tank={tank} 

            viewMode={viewMode}

            onClick={() => setSelectedTank(tank)}

          />

        ))}

      </div>



      {/* Alert Section */}

      {tanks.some(t => t.status === 'in_use' && Math.abs(t.temperature.current - t.temperature.target) > 0.5) && (

        <Card className="mt-6 border-warning/50">

          <CardHeader>

            <span className="text-warning">⚠️ გაფრთხილებები</span>

          </CardHeader>

          <CardBody>

            <div className="space-y-2">

              {tanks

                .filter(t => t.status === 'in_use' && Math.abs(t.temperature.current - t.temperature.target) > 0.5)

                .map(tank => (

                  <div key={tank.id} className="flex items-center justify-between p-3 bg-warning/10 rounded-lg">

                    <div className="flex items-center gap-3">

                      <span className="text-warning">🌡️</span>

                      <span className="font-medium">{tank.name}</span>

                      <span className="text-text-muted">-</span>

                      <span className="text-sm">ტემპერატურა სამიზნეს გარეთაა</span>

                    </div>

                    <div className="text-sm">

                      <span className="text-warning">{tank.temperature.current}°C</span>

                      <span className="text-text-muted"> / სამიზნე: {tank.temperature.target}°C</span>

                    </div>

                  </div>

                ))}

            </div>

          </CardBody>

        </Card>

      )}



      {/* Tank Detail Modal */}

      {selectedTank && (

        <TankDetailModal

          tank={selectedTank}

          onClose={() => setSelectedTank(null)}

        />

      )}

    </DashboardLayout>

  )

}

