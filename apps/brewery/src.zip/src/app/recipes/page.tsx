'use client'



import { useState } from 'react'

import { DashboardLayout } from '@/components/layout'

import { Card, CardHeader, CardBody, Button } from '@/components/ui'

import { RecipeCard } from '@/components/recipes/RecipeCard'

import { RecipeDetailModal } from '@/components/recipes/RecipeDetailModal'

import { NewRecipeModal } from '@/components/recipes/NewRecipeModal'



export interface Ingredient {

  id: string

  name: string

  type: 'grain' | 'hop' | 'yeast' | 'adjunct' | 'water'

  amount: number

  unit: string

  percentage?: number

  addTime?: string

  notes?: string

}



export interface BrewingStep {

  id: string

  order: number

  name: string

  description: string

  duration: number

  temperature?: number

  notes?: string

}



export interface Recipe {

  id: string

  name: string

  style: string

  description: string

  targetOG: number

  targetFG: number

  targetABV: number

  ibu: number

  srm: number

  batchSize: number

  boilTime: number

  efficiency: number

  ingredients: Ingredient[]

  steps: BrewingStep[]

  notes: string

  createdAt: Date

  updatedAt: Date

  batchCount: number

  rating: number

  isFavorite: boolean

}



const mockRecipes: Recipe[] = [

  {

    id: '1',

    name: 'Georgian Amber Lager',

    style: 'Amber Lager',

    description: 'კლასიკური ქარვისფერი ლაგერი ქართული ტრადიციებით. დაბალანსებული სხეული და სასიამოვნო სიმწარე.',

    targetOG: 1.052,

    targetFG: 1.012,

    targetABV: 5.2,

    ibu: 25,

    srm: 14,

    batchSize: 2000,

    boilTime: 60,

    efficiency: 75,

    ingredients: [

      { id: '1', name: 'Pilsner Malt', type: 'grain', amount: 85, unit: 'kg', percentage: 70 },

      { id: '2', name: 'Munich Malt', type: 'grain', amount: 24, unit: 'kg', percentage: 20 },

      { id: '3', name: 'Crystal 60L', type: 'grain', amount: 12, unit: 'kg', percentage: 10 },

      { id: '4', name: 'Saaz', type: 'hop', amount: 1.2, unit: 'kg', addTime: '60 წთ' },

      { id: '5', name: 'Tettnanger', type: 'hop', amount: 0.6, unit: 'kg', addTime: '15 წთ' },

      { id: '6', name: 'Saflager W-34/70', type: 'yeast', amount: 6, unit: 'პაკეტი' },

    ],

    steps: [

      { id: '1', order: 1, name: 'მეიშინგი', description: 'ალაოს დაფქვა და წყალთან შერევა', duration: 60, temperature: 65 },

      { id: '2', order: 2, name: 'მეშ აუტი', description: 'ტემპერატურის აწევა ფერმენტების დეაქტივაციისთვის', duration: 10, temperature: 76 },

      { id: '3', order: 3, name: 'ლაუტერინგი', description: 'ტკბილი სითხის გამოყოფა მარცვლისგან', duration: 45 },

      { id: '4', order: 4, name: 'ხარშვა', description: 'ტკბილის ხარშვა და სვიას დამატება', duration: 60, temperature: 100 },

      { id: '5', order: 5, name: 'გაცივება', description: 'სწრაფი გაცივება ფერმენტაციის ტემპერატურამდე', duration: 30, temperature: 12 },

      { id: '6', order: 6, name: 'ფერმენტაცია', description: 'პირველადი ფერმენტაცია საფუვრით', duration: 14 * 24 * 60, temperature: 12 },

      { id: '7', order: 7, name: 'ლაგერირება', description: 'ცივი კონდიციონირება', duration: 21 * 24 * 60, temperature: 2 },

    ],

    notes: 'საუკეთესო შედეგისთვის გამოიყენეთ რბილი წყალი. ფერმენტაციის ტემპერატურა კრიტიკულია.',

    createdAt: new Date('2024-01-15'),

    updatedAt: new Date('2024-11-20'),

    batchCount: 24,

    rating: 4.8,

    isFavorite: true,

  },

  {

    id: '2',

    name: 'Tbilisi IPA',

    style: 'American IPA',

    description: 'თანამედროვე IPA ციტრუსის და ტროპიკული ხილის არომატით. გამოხატული სვიის ხასიათი.',

    targetOG: 1.065,

    targetFG: 1.012,

    targetABV: 6.8,

    ibu: 65,

    srm: 8,

    batchSize: 2000,

    boilTime: 60,

    efficiency: 72,

    ingredients: [

      { id: '1', name: 'Pale Ale Malt', type: 'grain', amount: 95, unit: 'kg', percentage: 85 },

      { id: '2', name: 'Carapils', type: 'grain', amount: 11, unit: 'kg', percentage: 10 },

      { id: '3', name: 'Crystal 40L', type: 'grain', amount: 5.5, unit: 'kg', percentage: 5 },

      { id: '4', name: 'Citra', type: 'hop', amount: 1.5, unit: 'kg', addTime: '60 წთ' },

      { id: '5', name: 'Mosaic', type: 'hop', amount: 1.2, unit: 'kg', addTime: '15 წთ' },

      { id: '6', name: 'Citra', type: 'hop', amount: 2.0, unit: 'kg', addTime: 'Dry Hop' },

      { id: '7', name: 'Mosaic', type: 'hop', amount: 1.5, unit: 'kg', addTime: 'Dry Hop' },

      { id: '8', name: 'US-05', type: 'yeast', amount: 6, unit: 'პაკეტი' },

    ],

    steps: [

      { id: '1', order: 1, name: 'მეიშინგი', description: 'ერთსაფეხურიანი მეიშინგი', duration: 60, temperature: 67 },

      { id: '2', order: 2, name: 'ხარშვა', description: 'სვიის დამატება გრაფიკით', duration: 60, temperature: 100 },

      { id: '3', order: 3, name: 'Whirlpool', description: 'არომატული სვიის დამატება', duration: 20, temperature: 80 },

      { id: '4', order: 4, name: 'ფერმენტაცია', description: 'აქტიური ფერმენტაცია', duration: 7 * 24 * 60, temperature: 18 },

      { id: '5', order: 5, name: 'Dry Hopping', description: 'მშრალი სვია 5 დღე', duration: 5 * 24 * 60, temperature: 18 },

      { id: '6', order: 6, name: 'Cold Crash', description: 'სწრაფი გაცივება გამჭვირვალობისთვის', duration: 2 * 24 * 60, temperature: 2 },

    ],

    notes: 'Dry hop ფაზაში მინიმალური ჟანგბადის კონტაქტი აუცილებელია.',

    createdAt: new Date('2024-03-10'),

    updatedAt: new Date('2024-12-01'),

    batchCount: 18,

    rating: 4.9,

    isFavorite: true,

  },

  {

    id: '3',

    name: 'Kolkheti Stout',

    style: 'Dry Stout',

    description: 'მდიდარი, კრემისებრი სტაუტი ყავისა და შოკოლადის ტონებით.',

    targetOG: 1.070,

    targetFG: 1.015,

    targetABV: 7.2,

    ibu: 40,

    srm: 35,

    batchSize: 1500,

    boilTime: 90,

    efficiency: 70,

    ingredients: [

      { id: '1', name: 'Pale Ale Malt', type: 'grain', amount: 65, unit: 'kg', percentage: 65 },

      { id: '2', name: 'Roasted Barley', type: 'grain', amount: 15, unit: 'kg', percentage: 15 },

      { id: '3', name: 'Chocolate Malt', type: 'grain', amount: 10, unit: 'kg', percentage: 10 },

      { id: '4', name: 'Flaked Oats', type: 'grain', amount: 10, unit: 'kg', percentage: 10 },

      { id: '5', name: 'East Kent Goldings', type: 'hop', amount: 1.0, unit: 'kg', addTime: '60 წთ' },

      { id: '6', name: 'Fuggle', type: 'hop', amount: 0.5, unit: 'kg', addTime: '15 წთ' },

      { id: '7', name: 'Irish Ale Yeast', type: 'yeast', amount: 5, unit: 'პაკეტი' },

    ],

    steps: [

      { id: '1', order: 1, name: 'მეიშინგი', description: 'დაბალი ტემპერატურის მეიში სხეულისთვის', duration: 75, temperature: 66 },

      { id: '2', order: 2, name: 'ხარშვა', description: 'გახანგრძლივებული ხარშვა', duration: 90, temperature: 100 },

      { id: '3', order: 3, name: 'ფერმენტაცია', description: 'ოთახის ტემპერატურაზე', duration: 10 * 24 * 60, temperature: 20 },

      { id: '4', order: 4, name: 'კონდიციონირება', description: 'მომწიფება ტანკში', duration: 14 * 24 * 60, temperature: 4 },

    ],

    notes: 'ქერის შებოლვა ხდება ადგილობრივად.',

    createdAt: new Date('2024-02-20'),

    updatedAt: new Date('2024-10-15'),

    batchCount: 12,

    rating: 4.7,

    isFavorite: false,

  },

  {

    id: '4',

    name: 'მთის ფშავური',

    style: 'Hefeweizen',

    description: 'ტრადიციული გერმანული ხორბლის ლუდი ბანანისა და მიხაკის არომატით.',

    targetOG: 1.048,

    targetFG: 1.010,

    targetABV: 4.8,

    ibu: 12,

    srm: 4,

    batchSize: 2000,

    boilTime: 60,

    efficiency: 73,

    ingredients: [

      { id: '1', name: 'Wheat Malt', type: 'grain', amount: 55, unit: 'kg', percentage: 50 },

      { id: '2', name: 'Pilsner Malt', type: 'grain', amount: 55, unit: 'kg', percentage: 50 },

      { id: '3', name: 'Hallertauer', type: 'hop', amount: 0.8, unit: 'kg', addTime: '60 წთ' },

      { id: '4', name: 'Weihenstephan Weizen', type: 'yeast', amount: 5, unit: 'პაკეტი' },

    ],

    steps: [

      { id: '1', order: 1, name: 'მეიშინგი', description: 'საფეხურიანი მეიში ხორბლის ლუდისთვის', duration: 90, temperature: 52 },

      { id: '2', order: 2, name: 'ხარშვა', description: 'მსუბუქი ხარშვა', duration: 60, temperature: 100 },

      { id: '3', order: 3, name: 'ფერმენტაცია', description: 'თბილი ფერმენტაცია ესტერებისთვის', duration: 7 * 24 * 60, temperature: 22 },

    ],

    notes: 'არ გავფილტროთ - ტრადიციული მღვრიე იერსახე.',

    createdAt: new Date('2024-05-01'),

    updatedAt: new Date('2024-09-20'),

    batchCount: 15,

    rating: 4.5,

    isFavorite: false,

  },

  {

    id: '5',

    name: 'კახური Pilsner',

    style: 'Czech Pilsner',

    description: 'კლასიკური ჩეხური პილზნერი ღრმა ოქროსფერი და ნობელური სვიით.',

    targetOG: 1.045,

    targetFG: 1.008,

    targetABV: 4.5,

    ibu: 35,

    srm: 4,

    batchSize: 2500,

    boilTime: 90,

    efficiency: 78,

    ingredients: [

      { id: '1', name: 'Bohemian Pilsner Malt', type: 'grain', amount: 115, unit: 'kg', percentage: 100 },

      { id: '2', name: 'Saaz', type: 'hop', amount: 2.0, unit: 'kg', addTime: '60 წთ' },

      { id: '3', name: 'Saaz', type: 'hop', amount: 1.2, unit: 'kg', addTime: '30 წთ' },

      { id: '4', name: 'Saaz', type: 'hop', amount: 0.8, unit: 'kg', addTime: '5 წთ' },

      { id: '5', name: 'Czech Lager Yeast', type: 'yeast', amount: 8, unit: 'პაკეტი' },

    ],

    steps: [

      { id: '1', order: 1, name: 'Decoction მეიში', description: 'ტრადიციული ტროილიანი დეკოქცია', duration: 180, temperature: 35 },

      { id: '2', order: 2, name: 'ხარშვა', description: 'გახანგრძლივებული ხარშვა DMS-ისთვის', duration: 90, temperature: 100 },

      { id: '3', order: 3, name: 'ფერმენტაცია', description: 'ცივი ფერმენტაცია', duration: 14 * 24 * 60, temperature: 10 },

      { id: '4', order: 4, name: 'ლაგერირება', description: 'გრძელი ლაგერირება', duration: 42 * 24 * 60, temperature: 2 },

    ],

    notes: 'რბილი წყალი კრიტიკულია ამ სტილისთვის.',

    createdAt: new Date('2024-04-15'),

    updatedAt: new Date('2024-11-10'),

    batchCount: 20,

    rating: 4.6,

    isFavorite: true,

  },

  {

    id: '6',

    name: 'შავი ზღვის Porter',

    style: 'Baltic Porter',

    description: 'ძლიერი ბალტიური პორტერი კარამელისა და შებოლილი ხილის ნოტებით.',

    targetOG: 1.058,

    targetFG: 1.014,

    targetABV: 5.8,

    ibu: 30,

    srm: 28,

    batchSize: 1500,

    boilTime: 90,

    efficiency: 72,

    ingredients: [

      { id: '1', name: 'Munich Malt', type: 'grain', amount: 50, unit: 'kg', percentage: 50 },

      { id: '2', name: 'Pilsner Malt', type: 'grain', amount: 30, unit: 'kg', percentage: 30 },

      { id: '3', name: 'Crystal 80L', type: 'grain', amount: 10, unit: 'kg', percentage: 10 },

      { id: '4', name: 'Chocolate Malt', type: 'grain', amount: 5, unit: 'kg', percentage: 5 },

      { id: '5', name: 'Black Malt', type: 'grain', amount: 5, unit: 'kg', percentage: 5 },

      { id: '6', name: 'Northern Brewer', type: 'hop', amount: 1.0, unit: 'kg', addTime: '60 წთ' },

      { id: '7', name: 'Lager Yeast', type: 'yeast', amount: 6, unit: 'პაკეტი' },

    ],

    steps: [

      { id: '1', order: 1, name: 'მეიშინგი', description: 'მრავალსაფეხურიანი მეიში', duration: 120, temperature: 50 },

      { id: '2', order: 2, name: 'ხარშვა', description: 'გახანგრძლივებული ხარშვა', duration: 90, temperature: 100 },

      { id: '3', order: 3, name: 'ფერმენტაცია', description: 'ლაგერის ფერმენტაცია', duration: 21 * 24 * 60, temperature: 12 },

      { id: '4', order: 4, name: 'კონდიციონირება', description: 'ცივი მომწიფება', duration: 30 * 24 * 60, temperature: 2 },

    ],

    notes: 'საუკეთესო შედეგი 3 თვიანი მომწიფების შემდეგ.',

    createdAt: new Date('2024-06-01'),

    updatedAt: new Date('2024-08-30'),

    batchCount: 8,

    rating: 4.4,

    isFavorite: false,

  },

]



export default function RecipesPage() {

  const [recipes, setRecipes] = useState(mockRecipes)

  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null)

  const [showNewRecipeModal, setShowNewRecipeModal] = useState(false)

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  const [filterStyle, setFilterStyle] = useState<string>('all')

  const [searchQuery, setSearchQuery] = useState('')

  const [sortBy, setSortBy] = useState<'name' | 'rating' | 'batchCount' | 'updatedAt'>('updatedAt')



  const styles = ['all', ...new Set(recipes.map(r => r.style))]



  const filteredRecipes = recipes

    .filter(recipe => {

      if (filterStyle !== 'all' && recipe.style !== filterStyle) return false

      if (searchQuery && !recipe.name.toLowerCase().includes(searchQuery.toLowerCase())) return false

      return true

    })

    .sort((a, b) => {

      switch (sortBy) {

        case 'name': return a.name.localeCompare(b.name)

        case 'rating': return b.rating - a.rating

        case 'batchCount': return b.batchCount - a.batchCount

        case 'updatedAt': return b.updatedAt.getTime() - a.updatedAt.getTime()

        default: return 0

      }

    })



  const toggleFavorite = (id: string) => {

    setRecipes(prev => prev.map(r => 

      r.id === id ? { ...r, isFavorite: !r.isFavorite } : r

    ))

  }



  const stats = {

    total: recipes.length,

    favorites: recipes.filter(r => r.isFavorite).length,

    totalBatches: recipes.reduce((sum, r) => sum + r.batchCount, 0),

    avgRating: (recipes.reduce((sum, r) => sum + r.rating, 0) / recipes.length).toFixed(1),

  }



  return (

    <DashboardLayout title="რეცეპტები" breadcrumb="მთავარი / რეცეპტები">

      {/* Stats */}

      <div className="grid grid-cols-4 gap-4 mb-6">

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display text-copper-light">{stats.total}</p>

          <p className="text-xs text-text-muted">სულ რეცეპტი</p>

        </div>

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display text-amber-400">{stats.favorites}</p>

          <p className="text-xs text-text-muted">ფავორიტი</p>

        </div>

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display">{stats.totalBatches}</p>

          <p className="text-xs text-text-muted">სულ მოხარშული</p>

        </div>

        <div className="bg-bg-card border border-border rounded-xl p-4">

          <p className="text-2xl font-bold font-display text-green-400">⭐ {stats.avgRating}</p>

          <p className="text-xs text-text-muted">საშუალო შეფასება</p>

        </div>

      </div>



      {/* Filters & Actions */}

      <div className="flex justify-between items-center mb-6 gap-4">

        <div className="flex gap-3 flex-1">

          {/* Search */}

          <div className="relative">

            <input

              type="text"

              placeholder="ძიება..."

              value={searchQuery}

              onChange={(e) => setSearchQuery(e.target.value)}

              className="pl-10 pr-4 py-2 bg-bg-tertiary border border-border rounded-lg text-sm w-64 focus:border-copper focus:outline-none"

            />

            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted">🔍</span>

          </div>



          {/* Style Filter */}

          <select

            value={filterStyle}

            onChange={(e) => setFilterStyle(e.target.value)}

            className="px-4 py-2 bg-bg-tertiary border border-border rounded-lg text-sm focus:border-copper focus:outline-none"

          >

            <option value="all">ყველა სტილი</option>

            {styles.filter(s => s !== 'all').map(style => (

              <option key={style} value={style}>{style}</option>

            ))}

          </select>



          {/* Sort */}

          <select

            value={sortBy}

            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}

            className="px-4 py-2 bg-bg-tertiary border border-border rounded-lg text-sm focus:border-copper focus:outline-none"

          >

            <option value="updatedAt">ბოლოს განახლებული</option>

            <option value="name">სახელით</option>

            <option value="rating">შეფასებით</option>

            <option value="batchCount">პოპულარობით</option>

          </select>

        </div>



        <div className="flex gap-2">

          <button

            onClick={() => setViewMode('grid')}

            className={`p-2 rounded-lg ${viewMode === 'grid' ? 'bg-copper text-white' : 'bg-bg-tertiary'}`}

          >

            ▦

          </button>

          <button

            onClick={() => setViewMode('list')}

            className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-copper text-white' : 'bg-bg-tertiary'}`}

          >

            ☰

          </button>

          <Button variant="primary" onClick={() => setShowNewRecipeModal(true)}>

            + ახალი რეცეპტი

          </Button>

        </div>

      </div>



      {/* Recipes Grid/List */}

      <div className={viewMode === 'grid' ? 'grid grid-cols-3 gap-6' : 'space-y-4'}>

        {filteredRecipes.map(recipe => (

          <RecipeCard

            key={recipe.id}

            recipe={recipe}

            viewMode={viewMode}

            onClick={() => setSelectedRecipe(recipe)}

            onToggleFavorite={() => toggleFavorite(recipe.id)}

          />

        ))}

      </div>



      {filteredRecipes.length === 0 && (

        <div className="text-center py-12 text-text-muted">

          <p className="text-4xl mb-4">📋</p>

          <p>რეცეპტები ვერ მოიძებნა</p>

        </div>

      )}



      {/* Recipe Detail Modal */}

      {selectedRecipe && (

        <RecipeDetailModal

          recipe={selectedRecipe}

          onClose={() => setSelectedRecipe(null)}

          onStartBatch={() => {

            // TODO: Navigate to new batch with recipe

            setSelectedRecipe(null)

          }}

        />

      )}



      {/* New Recipe Modal */}

      {showNewRecipeModal && (

        <NewRecipeModal

          onClose={() => setShowNewRecipeModal(false)}

          onSave={(recipe) => {

            setRecipes(prev => [...prev, { ...recipe, id: Date.now().toString() }])

            setShowNewRecipeModal(false)

          }}

        />

      )}

    </DashboardLayout>

  )

}



