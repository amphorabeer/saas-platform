'use client'



import { useState } from 'react'

import { useRouter } from 'next/navigation'

import { DashboardLayout } from '@/components/layout'

import { Card, CardHeader, CardBody, Button } from '@/components/ui'

import { formatDate, formatCurrency } from '@/lib/utils'

import { NewOrderModal } from '@/components/sales'



interface FinishedProduct {

  id: string

  batchId: string

  batchNumber: string

  productName: string

  style: string

  abv: number

  packageType: 'keg' | 'bottle' | 'can'

  packageSize: number

  quantity: number

  availableQuantity: number

  pricePerUnit: number

  productionDate: Date

  expiryDate: Date

}



interface Order {

  id: string

  orderNumber: string

  customerName: string

  orderDate: Date

  total: number

  status: string

  paymentStatus: string

}



const mockFinishedProducts: FinishedProduct[] = [

  { id: '1', batchId: '1', batchNumber: 'BRW-2024-0156', productName: 'Georgian Amber Lager', style: 'Amber Lager', abv: 5.2, packageType: 'keg', packageSize: 30, quantity: 12, availableQuantity: 10, pricePerUnit: 2400, productionDate: new Date('2024-12-01'), expiryDate: new Date('2025-03-15') },

  { id: '2', batchId: '1', batchNumber: 'BRW-2024-0156', productName: 'Georgian Amber Lager', style: 'Amber Lager', abv: 5.2, packageType: 'bottle', packageSize: 0.5, quantity: 240, availableQuantity: 180, pricePerUnit: 8, productionDate: new Date('2024-12-01'), expiryDate: new Date('2025-06-01') },

  { id: '3', batchId: '2', batchNumber: 'BRW-2024-0155', productName: 'Tbilisi IPA', style: 'IPA', abv: 6.5, packageType: 'keg', packageSize: 30, quantity: 8, availableQuantity: 6, pricePerUnit: 2600, productionDate: new Date('2024-11-25'), expiryDate: new Date('2025-02-25') },

  { id: '4', batchId: '2', batchNumber: 'BRW-2024-0155', productName: 'Tbilisi IPA', style: 'IPA', abv: 6.5, packageType: 'bottle', packageSize: 0.5, quantity: 480, availableQuantity: 320, pricePerUnit: 9, productionDate: new Date('2024-11-25'), expiryDate: new Date('2025-05-25') },

  { id: '5', batchId: '3', batchNumber: 'BRW-2024-0154', productName: 'Kolkheti Wheat', style: 'Wheat', abv: 4.8, packageType: 'keg', packageSize: 30, quantity: 6, availableQuantity: 4, pricePerUnit: 2200, productionDate: new Date('2024-11-20'), expiryDate: new Date('2025-02-20') },

  { id: '6', batchId: '4', batchNumber: 'BRW-2024-0153', productName: 'Caucasus Stout', style: 'Stout', abv: 5.8, packageType: 'bottle', packageSize: 0.33, quantity: 360, availableQuantity: 280, pricePerUnit: 7, productionDate: new Date('2024-11-15'), expiryDate: new Date('2025-05-15') },

  { id: '7', batchId: '5', batchNumber: 'BRW-2024-0152', productName: 'Svaneti Pilsner', style: 'Pilsner', abv: 4.5, packageType: 'keg', packageSize: 50, quantity: 4, availableQuantity: 2, pricePerUnit: 3800, productionDate: new Date('2024-11-10'), expiryDate: new Date('2025-02-10') },

  { id: '8', batchId: '5', batchNumber: 'BRW-2024-0152', productName: 'Svaneti Pilsner', style: 'Pilsner', abv: 4.5, packageType: 'can', packageSize: 0.5, quantity: 600, availableQuantity: 450, pricePerUnit: 6, productionDate: new Date('2024-11-10'), expiryDate: new Date('2025-08-10') },

]



const mockOrders: Order[] = [

  { id: '1', orderNumber: 'ORD-2024-0045', customerName: 'რესტორანი "ფუნიკულიორი"', orderDate: new Date('2024-12-10'), total: 10200, status: 'shipped', paymentStatus: 'paid' },

  { id: '2', orderNumber: 'ORD-2024-0044', customerName: 'Wine Bar "8000"', orderDate: new Date('2024-12-09'), total: 5200, status: 'processing', paymentStatus: 'pending' },

  { id: '3', orderNumber: 'ORD-2024-0043', customerName: 'Craft Corner', orderDate: new Date('2024-12-08'), total: 4800, status: 'confirmed', paymentStatus: 'partial' },

  { id: '4', orderNumber: 'ORD-2024-0042', customerName: 'სუპერმარკეტი "გუდვილი"', orderDate: new Date('2024-12-07'), total: 14400, status: 'delivered', paymentStatus: 'paid' },

  { id: '5', orderNumber: 'ORD-2024-0041', customerName: 'პაბი "London"', orderDate: new Date('2024-12-06'), total: 7200, status: 'draft', paymentStatus: 'pending' },

]



const mockKegsStats = {

  inStock: 28,

  withCustomer: 15,

}



const mockTopCustomers = [

  { name: 'რესტორანი "ფუნიკულიორი"', revenue: 42000 },

  { name: 'დისტრიბუტორი "BeerGe"', revenue: 125000 },

  { name: 'სუპერმარკეტი "გუდვილი"', revenue: 35600 },

]



export default function SalesPage() {

  const router = useRouter()

  const [showNewOrder, setShowNewOrder] = useState(false)



  const stats = {

    monthlyRevenue: 45200,

    monthlyOrders: 32,

    soldLiters: 8500,

    activeCustomers: 24,

    pendingOrders: 5,

    pendingPayment: 12300,

  }



  const getStatusBadge = (status: string) => {

    const config: Record<string, { label: string; color: string; bg: string }> = {

      draft: { label: 'დრაფტი', color: 'text-gray-400', bg: 'bg-gray-400/20' },

      confirmed: { label: 'დადასტურებული', color: 'text-blue-400', bg: 'bg-blue-400/20' },

      processing: { label: 'დამუშავებაში', color: 'text-amber-400', bg: 'bg-amber-400/20' },

      shipped: { label: 'გაგზავნილი', color: 'text-purple-400', bg: 'bg-purple-400/20' },

      delivered: { label: 'მიღებული', color: 'text-green-400', bg: 'bg-green-400/20' },

      cancelled: { label: 'გაუქმებული', color: 'text-red-400', bg: 'bg-red-400/20' },

    }

    const c = config[status] || config.draft

    return <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${c.bg} ${c.color}`}>{c.label}</span>

  }



  return (

    <DashboardLayout title="გაყიდვები" breadcrumb="მთავარი / გაყიდვები">

      {/* Header */}

      <div className="flex justify-between items-center mb-6">

        <h1 className="text-2xl font-display font-bold">გაყიდვები</h1>

        <div className="flex gap-2">

          <Button variant="secondary" onClick={() => router.push('/sales/customers')}>+ ახალი კლიენტი</Button>

          <Button variant="primary" onClick={() => setShowNewOrder(true)}>+ ახალი შეკვეთა</Button>

        </div>

      </div>



      {/* Stats Cards */}

      <div className="grid grid-cols-6 gap-4 mb-6">

        <Card>

          <CardBody className="p-4">

            <p className="text-2xl font-bold font-display text-green-400">{formatCurrency(stats.monthlyRevenue)}</p>

            <p className="text-xs text-text-muted">💰 გაყიდვები (თვე)</p>

            <p className="text-xs text-green-400 mt-1">↑18% წინა თვესთან</p>

          </CardBody>

        </Card>

        <Card>

          <CardBody className="p-4">

            <p className="text-2xl font-bold font-display text-blue-400">{stats.monthlyOrders}</p>

            <p className="text-xs text-text-muted">📦 შეკვეთები (თვე)</p>

            <p className="text-xs text-blue-400 mt-1">↑12%</p>

          </CardBody>

        </Card>

        <Card>

          <CardBody className="p-4">

            <p className="text-2xl font-bold font-display text-copper-light">{stats.soldLiters.toLocaleString()}L</p>

            <p className="text-xs text-text-muted">🍺 გაყიდული</p>

          </CardBody>

        </Card>

        <Card>

          <CardBody className="p-4">

            <p className="text-2xl font-bold font-display text-purple-400">{stats.activeCustomers}</p>

            <p className="text-xs text-text-muted">👥 აქტიური კლიენტები</p>

          </CardBody>

        </Card>

        <Card>

          <CardBody className="p-4">

            <p className="text-2xl font-bold font-display text-amber-400">{stats.pendingOrders}</p>

            <p className="text-xs text-text-muted">📋 მოლოდინში</p>

          </CardBody>

        </Card>

        <Card>

          <CardBody className="p-4">

            <p className="text-2xl font-bold font-display text-red-400">{formatCurrency(stats.pendingPayment)}</p>

            <p className="text-xs text-text-muted">💳 გადასახდელი</p>

          </CardBody>

        </Card>

      </div>



      <div className="grid grid-cols-3 gap-6">

        {/* Main Content */}

        <div className="col-span-2 space-y-6">

          {/* Finished Products Section */}

          <Card>

            <CardHeader>🍺 მზა პროდუქცია</CardHeader>

            <CardBody>

              <div className="flex gap-4 overflow-x-auto pb-2">

                {mockFinishedProducts.map(product => (

                  <div key={product.id} className="min-w-[280px] bg-bg-card border border-border rounded-xl p-4 flex-shrink-0">

                    <div className="flex items-start justify-between mb-2">

                      <div className="flex-1">

                        <h3 className="font-medium text-lg">{product.productName}</h3>

                        <p className="text-xs text-text-muted">

                          {product.packageType === 'keg' ? `კეგი ${product.packageSize}L` : 

                           product.packageType === 'bottle' ? `ბოთლი ${product.packageSize}L` : 

                           `ქილა ${product.packageSize}L`} | {product.quantity} ცალი

                        </p>

                      </div>

                      <span className="text-xs px-2 py-1 bg-green-400/20 text-green-400 rounded-full">Available</span>

                    </div>

                    <div className="mt-3 space-y-1 text-sm">

                      <p className="text-text-muted">ხელმისაწვდომი: {product.availableQuantity} ცალი</p>

                      <p className="font-mono text-copper-light">{formatCurrency(product.pricePerUnit)}/ცალი</p>

                    </div>

                    <Button variant="primary" size="sm" className="w-full mt-3" onClick={() => setShowNewOrder(true)}>

                      + შეკვეთაში

                    </Button>

                  </div>

                ))}

              </div>

            </CardBody>

          </Card>



          {/* Recent Orders */}

          <Card>

            <CardHeader>📋 უახლესი შეკვეთები</CardHeader>

            <CardBody noPadding>

              <table className="w-full">

                <thead>

                  <tr className="bg-bg-tertiary border-b border-border text-left text-xs text-text-muted">

                    <th className="px-4 py-3">#</th>

                    <th className="px-4 py-3">მომხმარებელი</th>

                    <th className="px-4 py-3">თარიღი</th>

                    <th className="px-4 py-3">პროდუქტები</th>

                    <th className="px-4 py-3">თანხა</th>

                    <th className="px-4 py-3">სტატუსი</th>

                  </tr>

                </thead>

                <tbody>

                  {mockOrders.map((order, i) => (

                    <tr 

                      key={order.id} 

                      className="border-b border-border/50 hover:bg-bg-tertiary/50 cursor-pointer transition-colors"

                      onClick={() => router.push(`/sales/orders/${order.id}`)}

                    >

                      <td className="px-4 py-3 font-mono text-sm">{order.orderNumber}</td>

                      <td className="px-4 py-3 text-sm">{order.customerName}</td>

                      <td className="px-4 py-3 text-sm text-text-muted">{formatDate(order.orderDate)}</td>

                      <td className="px-4 py-3 text-sm text-text-muted">-</td>

                      <td className="px-4 py-3 font-mono">{formatCurrency(order.total)}</td>

                      <td className="px-4 py-3">{getStatusBadge(order.status)}</td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </CardBody>

          </Card>

        </div>



        {/* Sidebar */}

        <div className="space-y-6">

          {/* Kegs Status Widget */}

          <Card>

            <CardHeader>🛢️ კეგების სტატუსი</CardHeader>

            <CardBody className="space-y-3">

              <div className="flex justify-between items-center">

                <span className="text-sm text-text-muted">🏠 საწყობში</span>

                <span className="text-lg font-bold text-green-400">{mockKegsStats.inStock}</span>

              </div>

              <div className="flex justify-between items-center">

                <span className="text-sm text-text-muted">👤 კლიენტთან</span>

                <span className="text-lg font-bold text-blue-400">{mockKegsStats.withCustomer}</span>

              </div>

              <Button variant="ghost" size="sm" className="w-full mt-2" onClick={() => router.push('/inventory/kegs')}>

                კეგების მენეჯმენტი →

              </Button>

            </CardBody>

          </Card>



          {/* Top Customers */}

          <Card>

            <CardHeader>👥 ტოპ კლიენტები</CardHeader>

            <CardBody className="space-y-3">

              {mockTopCustomers.map((customer, i) => (

                <div key={i} className="flex justify-between items-center">

                  <div className="flex-1">

                    <p className="text-sm font-medium">{customer.name}</p>

                    <p className="text-xs text-text-muted">{formatCurrency(customer.revenue)}</p>

                  </div>

                  <span className="text-xs text-text-muted">#{i + 1}</span>

                </div>

              ))}

              <Button variant="ghost" size="sm" className="w-full mt-2" onClick={() => router.push('/sales/customers')}>

                ყველა კლიენტი →

              </Button>

            </CardBody>

          </Card>



          {/* Quick Links */}

          <Card>

            <CardHeader>🔗 სწრაფი ლინკები</CardHeader>

            <CardBody className="space-y-2">

              <Button variant="ghost" size="sm" className="w-full justify-start" onClick={() => router.push('/sales/orders')}>

                📋 ყველა შეკვეთა

              </Button>

              <Button variant="ghost" size="sm" className="w-full justify-start" onClick={() => router.push('/sales/products')}>

                🍺 მზა პროდუქცია

              </Button>

              <Button variant="ghost" size="sm" className="w-full justify-start" onClick={() => router.push('/inventory/kegs')}>

                🛢️ კეგების მენეჯმენტი

              </Button>

            </CardBody>

          </Card>

        </div>

      </div>



      {/* New Order Modal */}

      <NewOrderModal

        isOpen={showNewOrder}

        onClose={() => setShowNewOrder(false)}

        onSubmit={(orderData) => {

          console.log('New order created:', orderData)

          setShowNewOrder(false)

          router.push('/sales/orders')

        }}

      />

    </DashboardLayout>

  )

}


