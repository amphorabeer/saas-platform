'use client'



import { useState } from 'react'

import { useRouter } from 'next/navigation'

import { DashboardLayout } from '@/components/layout'

import { Card, CardHeader, CardBody, Button } from '@/components/ui'

import { formatDate, formatCurrency } from '@/lib/utils'



interface Customer {

  id: string

  name: string

  type: 'restaurant' | 'bar' | 'shop' | 'distributor'

  city: string

  address: string

  phone: string

  email: string

  totalOrders: number

  totalRevenue: number

  lastOrderDate: Date

}



const mockCustomers: Customer[] = [

  { id: '1', name: 'რესტორანი "ფუნიკულიორი"', type: 'restaurant', city: 'თბილისი', address: 'რუსთაველის 12', phone: '+995 555 123 456', email: 'info@funikuliori.ge', totalOrders: 15, totalRevenue: 42000, lastOrderDate: new Date('2024-12-10') },

  { id: '2', name: 'Wine Bar "8000"', type: 'bar', city: 'თბილისი', address: 'აღმაშენებლის 45', phone: '+995 555 234 567', email: 'contact@8000.ge', totalOrders: 12, totalRevenue: 28500, lastOrderDate: new Date('2024-12-09') },

  { id: '3', name: 'Craft Corner', type: 'bar', city: 'ბათუმი', address: 'ნინოშვილის 8', phone: '+995 555 345 678', email: 'info@craftcorner.ge', totalOrders: 8, totalRevenue: 19200, lastOrderDate: new Date('2024-12-08') },

  { id: '4', name: 'სუპერმარკეტი "გუდვილი"', type: 'shop', city: 'თბილისი', address: 'წერეთლის 95', phone: '+995 555 456 789', email: 'orders@goodwill.ge', totalOrders: 22, totalRevenue: 35600, lastOrderDate: new Date('2024-12-07') },

  { id: '5', name: 'პაბი "London"', type: 'bar', city: 'თბილისი', address: 'ჭავჭავაძის 32', phone: '+995 555 567 890', email: 'london@pub.ge', totalOrders: 18, totalRevenue: 31400, lastOrderDate: new Date('2024-12-06') },

  { id: '6', name: 'რესტორანი "ხინკლის სახლი"', type: 'restaurant', city: 'თბილისი', address: 'კოტე აფხაზის 5', phone: '+995 555 678 901', email: 'info@khinkli.ge', totalOrders: 10, totalRevenue: 24000, lastOrderDate: new Date('2024-12-05') },

  { id: '7', name: 'Winery Khareba Shop', type: 'shop', city: 'თბილისი', address: 'ლესელიძის 3', phone: '+995 555 789 012', email: 'shop@khareba.ge', totalOrders: 6, totalRevenue: 15800, lastOrderDate: new Date('2024-12-04') },

  { id: '8', name: 'დისტრიბუტორი "BeerGe"', type: 'distributor', city: 'თბილისი', address: 'გლდანი, მე-4 მკრ', phone: '+995 555 890 123', email: 'orders@beerge.ge', totalOrders: 35, totalRevenue: 125000, lastOrderDate: new Date('2024-12-03') },

]



const cities = ['თბილისი', 'ბათუმი', 'ყველა']



export default function CustomersPage() {

  const router = useRouter()

  const [typeFilter, setTypeFilter] = useState<string>('all')

  const [cityFilter, setCityFilter] = useState<string>('all')

  const [searchQuery, setSearchQuery] = useState('')



  const filteredCustomers = mockCustomers.filter(customer => {

    if (typeFilter !== 'all' && customer.type !== typeFilter) return false

    if (cityFilter !== 'all' && customer.city !== cityFilter) return false

    if (searchQuery && !customer.name.toLowerCase().includes(searchQuery.toLowerCase()) &&

        !customer.email.toLowerCase().includes(searchQuery.toLowerCase())) return false

    return true

  })



  const getTypeIcon = (type: string) => {

    const icons: Record<string, string> = {

      restaurant: '🍽️',

      bar: '🍷',

      shop: '🏪',

      distributor: '🏭',

    }

    return icons[type] || '🏢'

  }



  const getTypeLabel = (type: string) => {

    const labels: Record<string, string> = {

      restaurant: 'რესტორანი',

      bar: 'ბარი',

      shop: 'მაღაზია',

      distributor: 'დისტრიბუტორი',

    }

    return labels[type] || type

  }



  return (

    <DashboardLayout title="მომხმარებლები" breadcrumb="მთავარი / გაყიდვები / მომხმარებლები">

      {/* Header */}

      <div className="flex justify-between items-center mb-6">

        <h1 className="text-2xl font-display font-bold">მომხმარებლები</h1>

        <div className="flex gap-2">

          <input

            type="text"

            placeholder="ძიება..."

            value={searchQuery}

            onChange={(e) => setSearchQuery(e.target.value)}

            className="px-4 py-2 bg-bg-tertiary border border-border rounded-lg text-sm w-64 focus:border-copper focus:outline-none"

          />

          <Button variant="primary">+ ახალი კლიენტი</Button>

        </div>

      </div>



      {/* Filters */}

      <Card className="mb-6">

        <CardBody>

          <div className="grid grid-cols-2 gap-4">

            <div>

              <label className="block text-xs text-text-muted mb-2">ტიპი</label>

              <select

                value={typeFilter}

                onChange={(e) => setTypeFilter(e.target.value)}

                className="w-full px-3 py-2 bg-bg-tertiary border border-border rounded-lg text-sm outline-none focus:border-copper"

              >

                <option value="all">ყველა</option>

                <option value="restaurant">რესტორანი</option>

                <option value="bar">ბარი</option>

                <option value="shop">მაღაზია</option>

                <option value="distributor">დისტრიბუტორი</option>

              </select>

            </div>

            <div>

              <label className="block text-xs text-text-muted mb-2">ქალაქი</label>

              <select

                value={cityFilter}

                onChange={(e) => setCityFilter(e.target.value)}

                className="w-full px-3 py-2 bg-bg-tertiary border border-border rounded-lg text-sm outline-none focus:border-copper"

              >

                {cities.map(city => (

                  <option key={city} value={city === 'ყველა' ? 'all' : city}>{city}</option>

                ))}

              </select>

            </div>

          </div>

        </CardBody>

      </Card>



      {/* Customers Table */}

      <Card>

        <CardHeader>👥 მომხმარებლების სია ({filteredCustomers.length})</CardHeader>

        <CardBody noPadding>

          <table className="w-full">

            <thead>

              <tr className="bg-bg-tertiary border-b border-border text-left text-xs text-text-muted">

                <th className="px-4 py-3">სახელი</th>

                <th className="px-4 py-3">ტიპი</th>

                <th className="px-4 py-3">ქალაქი</th>

                <th className="px-4 py-3">შეკვეთები</th>

                <th className="px-4 py-3">სულ გაყიდვა</th>

                <th className="px-4 py-3">ბოლო შეკვეთა</th>

                <th className="px-4 py-3"></th>

              </tr>

            </thead>

            <tbody>

              {filteredCustomers.map(customer => (

                <tr 

                  key={customer.id} 

                  className="border-b border-border/50 hover:bg-bg-tertiary/50 cursor-pointer transition-colors"

                >

                  <td className="px-4 py-3">

                    <p className="font-medium">{customer.name}</p>

                    <p className="text-xs text-text-muted">{customer.email}</p>

                  </td>

                  <td className="px-4 py-3">

                    <span className="inline-flex items-center gap-1 text-sm">

                      {getTypeIcon(customer.type)} {getTypeLabel(customer.type)}

                    </span>

                  </td>

                  <td className="px-4 py-3 text-sm">{customer.city}</td>

                  <td className="px-4 py-3 font-mono">{customer.totalOrders}</td>

                  <td className="px-4 py-3 font-mono">{formatCurrency(customer.totalRevenue)}</td>

                  <td className="px-4 py-3 text-sm text-text-muted">{formatDate(customer.lastOrderDate)}</td>

                  <td className="px-4 py-3">

                    <Button variant="ghost" size="sm">→</Button>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        </CardBody>

      </Card>

    </DashboardLayout>

  )

}


