import { DashboardLayout } from '@/components/layout'
import { Card, CardHeader, CardBody, StatCard, BatchStatusBadge, ProgressBar } from '@/components/ui'
import { formatDate, formatRelativeTime } from '@/utils'

// Mock Data - შემდეგ API-დან მოვა
const stats = {
  activeBatches: 12,
  activeTrend: 8.5,
  monthlyProduction: 24580,
  productionTrend: 12.3,
  fermentingNow: 6,
  readyToPackage: 3,
  lowStockItems: 4,
}

const activeBatches = [
  { id: '1', batchNumber: 'BRW-2024-0156', recipe: 'Georgian Amber Lager', status: 'fermenting' as const, tank: 'FV-01', volume: 2000, progress: 65, daysLeft: 5 },
  { id: '2', batchNumber: 'BRW-2024-0155', recipe: 'Tbilisi IPA', status: 'conditioning' as const, tank: 'BBT-01', volume: 1500, progress: 90, daysLeft: 2 },
  { id: '3', batchNumber: 'BRW-2024-0154', recipe: 'Kolkheti Stout', status: 'ready' as const, tank: 'BBT-02', volume: 1800, progress: 100, daysLeft: 0 },
  { id: '4', batchNumber: 'BRW-2024-0153', recipe: 'მთის ფშავური', status: 'brewing' as const, tank: 'Kettle', volume: 2500, progress: 25, daysLeft: 18 },
]

const tanks = [
  { id: '1', name: 'FV-01', type: 'fermenter', status: 'in_use', batch: 'BRW-2024-0156', fill: 80, temp: 18.5 },
  { id: '2', name: 'FV-02', type: 'fermenter', status: 'in_use', batch: 'BRW-2024-0157', fill: 65, temp: 12.0 },
  { id: '3', name: 'FV-03', type: 'fermenter', status: 'available', batch: null, fill: 0, temp: null },
  { id: '4', name: 'BBT-01', type: 'bbt', status: 'in_use', batch: 'BRW-2024-0155', fill: 75, temp: 4.0 },
  { id: '5', name: 'BBT-02', type: 'bbt', status: 'in_use', batch: 'BRW-2024-0154', fill: 90, temp: 2.0 },
]

const recentActivity = [
  { id: '1', type: 'brew', icon: '🧪', text: 'BRW-2024-0156 ფერმენტაციის დაწყება', time: new Date(Date.now() - 3600000) },
  { id: '2', type: 'qc', icon: '✅', text: 'BRW-2024-0154 QC ტესტი გაიარა', time: new Date(Date.now() - 7200000) },
  { id: '3', type: 'transfer', icon: '🔄', text: 'BRW-2024-0155 გადატანა BBT-01', time: new Date(Date.now() - 86400000) },
  { id: '4', type: 'alert', icon: '⚠️', text: 'დაბალი მარაგი: Cascade Hops', time: new Date(Date.now() - 90000000) },
]

const lowStockItems = [
  { name: 'Pale Malt', category: 'მარცვლეული', current: 150, max: 1000 },
  { name: 'Cascade Hops', category: 'სვია', current: 3.5, max: 10 },
]

export default function DashboardPage() {
  return (
    <DashboardLayout title="დეშბორდი" breadcrumb="მთავარი / დეშბორდი">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-copper/20 to-amber/10 border border-copper/30 rounded-2xl p-6 mb-6 flex justify-between items-center">
        <div>
          <h3 className="font-display text-xl mb-2">
            გამარჯობა, ნიკა! 👋
          </h3>
          <p className="text-text-secondary text-sm">
            დღეს <strong className="text-copper-light">3 პარტია</strong> საჭიროებს ყურადღებას. 
            წარმოება მიდის გეგმის მიხედვით.
          </p>
        </div>
        <div className="text-4xl">🍺</div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-5 mb-6">
        <StatCard
          icon="🍺"
          iconColor="amber"
          value={stats.activeBatches}
          label="აქტიური პარტიები"
          trend={{ value: stats.activeTrend, isUp: true }}
        />
        <StatCard
          icon="📊"
          iconColor="copper"
          value={`${(stats.monthlyProduction / 1000).toFixed(1)}k L`}
          label="თვის წარმოება"
          trend={{ value: stats.productionTrend, isUp: true }}
        />
        <StatCard
          icon="🧪"
          iconColor="green"
          value={stats.fermentingNow}
          label="ფერმენტაციაში"
        />
        <StatCard
          icon="✅"
          iconColor="blue"
          value={stats.readyToPackage}
          label="მზად დასაფასოებლად"
        />
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-3 gap-6 mb-6">
        {/* Active Batches Table - 2 columns */}
        <div className="col-span-2">
          <Card>
            <CardHeader action={<a href="/production" className="text-xs text-copper-light hover:underline">ყველას ნახვა →</a>}>
              <span className="text-lg">🍺</span> აქტიური პარტიები
            </CardHeader>
            <CardBody noPadding>
              <table className="w-full">
                <thead>
                  <tr className="bg-bg-tertiary">
                    <th className="text-left text-[11px] uppercase tracking-wide text-text-muted font-medium px-4 py-3">პარტია</th>
                    <th className="text-left text-[11px] uppercase tracking-wide text-text-muted font-medium px-4 py-3">რეცეპტი</th>
                    <th className="text-left text-[11px] uppercase tracking-wide text-text-muted font-medium px-4 py-3">სტატუსი</th>
                    <th className="text-left text-[11px] uppercase tracking-wide text-text-muted font-medium px-4 py-3">ტანკი</th>
                    <th className="text-left text-[11px] uppercase tracking-wide text-text-muted font-medium px-4 py-3">პროგრესი</th>
                  </tr>
                </thead>
                <tbody>
                  {activeBatches.map((batch) => (
                    <tr key={batch.id} className="border-b border-border last:border-0 hover:bg-copper/5 transition-colors">
                      <td className="px-4 py-3">
                        <span className="font-mono text-sm text-copper-light">{batch.batchNumber}</span>
                      </td>
                      <td className="px-4 py-3 text-sm">{batch.recipe}</td>
                      <td className="px-4 py-3">
                        <BatchStatusBadge status={batch.status} showPulse />
                      </td>
                      <td className="px-4 py-3 text-sm text-text-secondary">{batch.tank}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <ProgressBar value={batch.progress} size="sm" color={batch.progress === 100 ? 'success' : 'copper'} className="w-20" />
                          <span className="text-xs text-text-muted">{batch.progress}%</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardBody>
          </Card>
        </div>

        {/* Tanks Overview - 1 column */}
        <div>
          <Card>
            <CardHeader action={<a href="/fermentation" className="text-xs text-copper-light hover:underline">დეტალები →</a>}>
              <span className="text-lg">🧪</span> ტანკები
            </CardHeader>
            <CardBody>
              <div className="grid grid-cols-3 gap-3">
                {tanks.map((tank) => (
                  <div 
                    key={tank.id}
                    className="relative bg-bg-tertiary rounded-xl p-3 text-center"
                  >
                    {/* Tank Visual */}
                    <div className="relative w-12 h-16 mx-auto mb-2 bg-bg-primary rounded-t-lg rounded-b-[40%] border-2 border-border-light overflow-hidden">
                      <div 
                        className="absolute bottom-0 left-0 right-0 bg-amber/60 transition-all duration-500"
                        style={{ height: `${tank.fill}%` }}
                      />
                      {tank.fill > 0 && (
                        <>
                          <div className="bubble absolute w-1 h-1 bg-amber/80 rounded-full left-2 bottom-2" style={{ animationDelay: '0s' }} />
                          <div className="bubble absolute w-1.5 h-1.5 bg-amber/60 rounded-full right-3 bottom-4" style={{ animationDelay: '1s' }} />
                        </>
                      )}
                    </div>
                    
                    <p className="text-xs font-medium">{tank.name}</p>
                    <p className="text-[10px] text-text-muted">
                      {tank.temp ? `${tank.temp}°C` : 'თავისუფალი'}
                    </p>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>
      </div>

      {/* Bottom Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Production Chart Placeholder */}
        <div className="col-span-2">
          <Card>
            <CardHeader>
              <span className="text-lg">📈</span> წარმოების სტატისტიკა
            </CardHeader>
            <CardBody>
              <div className="h-64 flex items-center justify-center text-text-muted">
                <p>Chart.js გრაფიკი აქ იქნება</p>
              </div>
            </CardBody>
          </Card>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <span className="text-lg">📋</span> ბოლო აქტივობა
            </CardHeader>
            <CardBody className="space-y-3">
              {recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3">
                  <span className="text-lg">{activity.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm truncate">{activity.text}</p>
                    <p className="text-xs text-text-muted">{formatRelativeTime(activity.time)}</p>
                  </div>
                </div>
              ))}
            </CardBody>
          </Card>

          {/* Low Stock Alert */}
          <Card>
            <CardHeader action={<a href="/inventory" className="text-xs text-copper-light hover:underline">შეკვეთა →</a>}>
              <span className="text-lg">⚠️</span> დაბალი მარაგი
            </CardHeader>
            <CardBody className="space-y-3">
              {lowStockItems.map((item, index) => (
                <div key={index}>
                  <div className="flex justify-between text-sm mb-1">
                    <span>{item.name}</span>
                    <span className="text-text-muted text-xs">{item.current}/{item.max}</span>
                  </div>
                  <ProgressBar 
                    value={item.current} 
                    max={item.max} 
                    size="sm" 
                    color={item.current / item.max < 0.2 ? 'danger' : 'warning'} 
                  />
                </div>
              ))}
            </CardBody>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}



